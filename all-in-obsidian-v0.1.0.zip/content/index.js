"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/@mozilla/readability/Readability.js
  var require_Readability = __commonJS({
    "node_modules/@mozilla/readability/Readability.js"(exports, module) {
      function Readability2(doc, options) {
        if (options && options.documentElement) {
          doc = options;
          options = arguments[2];
        } else if (!doc || !doc.documentElement) {
          throw new Error("First argument to Readability constructor should be a document object.");
        }
        options = options || {};
        this._doc = doc;
        this._docJSDOMParser = this._doc.firstChild.__JSDOMParser__;
        this._articleTitle = null;
        this._articleByline = null;
        this._articleDir = null;
        this._articleSiteName = null;
        this._attempts = [];
        this._debug = !!options.debug;
        this._maxElemsToParse = options.maxElemsToParse || this.DEFAULT_MAX_ELEMS_TO_PARSE;
        this._nbTopCandidates = options.nbTopCandidates || this.DEFAULT_N_TOP_CANDIDATES;
        this._charThreshold = options.charThreshold || this.DEFAULT_CHAR_THRESHOLD;
        this._classesToPreserve = this.CLASSES_TO_PRESERVE.concat(options.classesToPreserve || []);
        this._keepClasses = !!options.keepClasses;
        this._serializer = options.serializer || function(el) {
          return el.innerHTML;
        };
        this._disableJSONLD = !!options.disableJSONLD;
        this._allowedVideoRegex = options.allowedVideoRegex || this.REGEXPS.videos;
        this._flags = this.FLAG_STRIP_UNLIKELYS | this.FLAG_WEIGHT_CLASSES | this.FLAG_CLEAN_CONDITIONALLY;
        if (this._debug) {
          let logNode = function(node) {
            if (node.nodeType == node.TEXT_NODE) {
              return `${node.nodeName} ("${node.textContent}")`;
            }
            let attrPairs = Array.from(node.attributes || [], function(attr) {
              return `${attr.name}="${attr.value}"`;
            }).join(" ");
            return `<${node.localName} ${attrPairs}>`;
          };
          this.log = function() {
            if (typeof console !== "undefined") {
              let args = Array.from(arguments, (arg) => {
                if (arg && arg.nodeType == this.ELEMENT_NODE) {
                  return logNode(arg);
                }
                return arg;
              });
              args.unshift("Reader: (Readability)");
              console.log.apply(console, args);
            } else if (typeof dump !== "undefined") {
              var msg = Array.prototype.map.call(arguments, function(x) {
                return x && x.nodeName ? logNode(x) : x;
              }).join(" ");
              dump("Reader: (Readability) " + msg + "\n");
            }
          };
        } else {
          this.log = function() {
          };
        }
      }
      Readability2.prototype = {
        FLAG_STRIP_UNLIKELYS: 1,
        FLAG_WEIGHT_CLASSES: 2,
        FLAG_CLEAN_CONDITIONALLY: 4,
        // https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
        ELEMENT_NODE: 1,
        TEXT_NODE: 3,
        // Max number of nodes supported by this parser. Default: 0 (no limit)
        DEFAULT_MAX_ELEMS_TO_PARSE: 0,
        // The number of top candidates to consider when analysing how
        // tight the competition is among candidates.
        DEFAULT_N_TOP_CANDIDATES: 5,
        // Element tags to score by default.
        DEFAULT_TAGS_TO_SCORE: "section,h2,h3,h4,h5,h6,p,td,pre".toUpperCase().split(","),
        // The default number of chars an article must have in order to return a result
        DEFAULT_CHAR_THRESHOLD: 500,
        // All of the regular expressions in use within readability.
        // Defined up here so we don't instantiate them repeatedly in loops.
        REGEXPS: {
          // NOTE: These two regular expressions are duplicated in
          // Readability-readerable.js. Please keep both copies in sync.
          unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
          okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i,
          positive: /article|body|content|entry|hentry|h-entry|main|page|pagination|post|text|blog|story/i,
          negative: /-ad-|hidden|^hid$| hid$| hid |^hid |banner|combx|comment|com-|contact|foot|footer|footnote|gdpr|masthead|media|meta|outbrain|promo|related|scroll|share|shoutbox|sidebar|skyscraper|sponsor|shopping|tags|tool|widget/i,
          extraneous: /print|archive|comment|discuss|e[\-]?mail|share|reply|all|login|sign|single|utility/i,
          byline: /byline|author|dateline|writtenby|p-author/i,
          replaceFonts: /<(\/?)font[^>]*>/gi,
          normalize: /\s{2,}/g,
          videos: /\/\/(www\.)?((dailymotion|youtube|youtube-nocookie|player\.vimeo|v\.qq)\.com|(archive|upload\.wikimedia)\.org|player\.twitch\.tv)/i,
          shareElements: /(\b|_)(share|sharedaddy)(\b|_)/i,
          nextLink: /(next|weiter|continue|>([^\|]|$)|»([^\|]|$))/i,
          prevLink: /(prev|earl|old|new|<|«)/i,
          tokenize: /\W+/g,
          whitespace: /^\s*$/,
          hasContent: /\S$/,
          hashUrl: /^#.+/,
          srcsetUrl: /(\S+)(\s+[\d.]+[xw])?(\s*(?:,|$))/g,
          b64DataUrl: /^data:\s*([^\s;,]+)\s*;\s*base64\s*,/i,
          // Commas as used in Latin, Sindhi, Chinese and various other scripts.
          // see: https://en.wikipedia.org/wiki/Comma#Comma_variants
          commas: /\u002C|\u060C|\uFE50|\uFE10|\uFE11|\u2E41|\u2E34|\u2E32|\uFF0C/g,
          // See: https://schema.org/Article
          jsonLdArticleTypes: /^Article|AdvertiserContentArticle|NewsArticle|AnalysisNewsArticle|AskPublicNewsArticle|BackgroundNewsArticle|OpinionNewsArticle|ReportageNewsArticle|ReviewNewsArticle|Report|SatiricalArticle|ScholarlyArticle|MedicalScholarlyArticle|SocialMediaPosting|BlogPosting|LiveBlogPosting|DiscussionForumPosting|TechArticle|APIReference$/
        },
        UNLIKELY_ROLES: ["menu", "menubar", "complementary", "navigation", "alert", "alertdialog", "dialog"],
        DIV_TO_P_ELEMS: /* @__PURE__ */ new Set(["BLOCKQUOTE", "DL", "DIV", "IMG", "OL", "P", "PRE", "TABLE", "UL"]),
        ALTER_TO_DIV_EXCEPTIONS: ["DIV", "ARTICLE", "SECTION", "P"],
        PRESENTATIONAL_ATTRIBUTES: ["align", "background", "bgcolor", "border", "cellpadding", "cellspacing", "frame", "hspace", "rules", "style", "valign", "vspace"],
        DEPRECATED_SIZE_ATTRIBUTE_ELEMS: ["TABLE", "TH", "TD", "HR", "PRE"],
        // The commented out elements qualify as phrasing content but tend to be
        // removed by readability when put into paragraphs, so we ignore them here.
        PHRASING_ELEMS: [
          // "CANVAS", "IFRAME", "SVG", "VIDEO",
          "ABBR",
          "AUDIO",
          "B",
          "BDO",
          "BR",
          "BUTTON",
          "CITE",
          "CODE",
          "DATA",
          "DATALIST",
          "DFN",
          "EM",
          "EMBED",
          "I",
          "IMG",
          "INPUT",
          "KBD",
          "LABEL",
          "MARK",
          "MATH",
          "METER",
          "NOSCRIPT",
          "OBJECT",
          "OUTPUT",
          "PROGRESS",
          "Q",
          "RUBY",
          "SAMP",
          "SCRIPT",
          "SELECT",
          "SMALL",
          "SPAN",
          "STRONG",
          "SUB",
          "SUP",
          "TEXTAREA",
          "TIME",
          "VAR",
          "WBR"
        ],
        // These are the classes that readability sets itself.
        CLASSES_TO_PRESERVE: ["page"],
        // These are the list of HTML entities that need to be escaped.
        HTML_ESCAPE_MAP: {
          "lt": "<",
          "gt": ">",
          "amp": "&",
          "quot": '"',
          "apos": "'"
        },
        /**
         * Run any post-process modifications to article content as necessary.
         *
         * @param Element
         * @return void
        **/
        _postProcessContent: function(articleContent) {
          this._fixRelativeUris(articleContent);
          this._simplifyNestedElements(articleContent);
          if (!this._keepClasses) {
            this._cleanClasses(articleContent);
          }
        },
        /**
         * Iterates over a NodeList, calls `filterFn` for each node and removes node
         * if function returned `true`.
         *
         * If function is not passed, removes all the nodes in node list.
         *
         * @param NodeList nodeList The nodes to operate on
         * @param Function filterFn the function to use as a filter
         * @return void
         */
        _removeNodes: function(nodeList, filterFn) {
          if (this._docJSDOMParser && nodeList._isLiveNodeList) {
            throw new Error("Do not pass live node lists to _removeNodes");
          }
          for (var i = nodeList.length - 1; i >= 0; i--) {
            var node = nodeList[i];
            var parentNode = node.parentNode;
            if (parentNode) {
              if (!filterFn || filterFn.call(this, node, i, nodeList)) {
                parentNode.removeChild(node);
              }
            }
          }
        },
        /**
         * Iterates over a NodeList, and calls _setNodeTag for each node.
         *
         * @param NodeList nodeList The nodes to operate on
         * @param String newTagName the new tag name to use
         * @return void
         */
        _replaceNodeTags: function(nodeList, newTagName) {
          if (this._docJSDOMParser && nodeList._isLiveNodeList) {
            throw new Error("Do not pass live node lists to _replaceNodeTags");
          }
          for (const node of nodeList) {
            this._setNodeTag(node, newTagName);
          }
        },
        /**
         * Iterate over a NodeList, which doesn't natively fully implement the Array
         * interface.
         *
         * For convenience, the current object context is applied to the provided
         * iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return void
         */
        _forEachNode: function(nodeList, fn) {
          Array.prototype.forEach.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, and return the first node that passes
         * the supplied test function
         *
         * For convenience, the current object context is applied to the provided
         * test function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The test function.
         * @return void
         */
        _findNode: function(nodeList, fn) {
          return Array.prototype.find.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, return true if any of the provided iterate
         * function calls returns true, false otherwise.
         *
         * For convenience, the current object context is applied to the
         * provided iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return Boolean
         */
        _someNode: function(nodeList, fn) {
          return Array.prototype.some.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, return true if all of the provided iterate
         * function calls return true, false otherwise.
         *
         * For convenience, the current object context is applied to the
         * provided iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return Boolean
         */
        _everyNode: function(nodeList, fn) {
          return Array.prototype.every.call(nodeList, fn, this);
        },
        /**
         * Concat all nodelists passed as arguments.
         *
         * @return ...NodeList
         * @return Array
         */
        _concatNodeLists: function() {
          var slice = Array.prototype.slice;
          var args = slice.call(arguments);
          var nodeLists = args.map(function(list) {
            return slice.call(list);
          });
          return Array.prototype.concat.apply([], nodeLists);
        },
        _getAllNodesWithTag: function(node, tagNames) {
          if (node.querySelectorAll) {
            return node.querySelectorAll(tagNames.join(","));
          }
          return [].concat.apply([], tagNames.map(function(tag) {
            var collection = node.getElementsByTagName(tag);
            return Array.isArray(collection) ? collection : Array.from(collection);
          }));
        },
        /**
         * Removes the class="" attribute from every element in the given
         * subtree, except those that match CLASSES_TO_PRESERVE and
         * the classesToPreserve array from the options object.
         *
         * @param Element
         * @return void
         */
        _cleanClasses: function(node) {
          var classesToPreserve = this._classesToPreserve;
          var className = (node.getAttribute("class") || "").split(/\s+/).filter(function(cls) {
            return classesToPreserve.indexOf(cls) != -1;
          }).join(" ");
          if (className) {
            node.setAttribute("class", className);
          } else {
            node.removeAttribute("class");
          }
          for (node = node.firstElementChild; node; node = node.nextElementSibling) {
            this._cleanClasses(node);
          }
        },
        /**
         * Converts each <a> and <img> uri in the given element to an absolute URI,
         * ignoring #ref URIs.
         *
         * @param Element
         * @return void
         */
        _fixRelativeUris: function(articleContent) {
          var baseURI = this._doc.baseURI;
          var documentURI = this._doc.documentURI;
          function toAbsoluteURI(uri) {
            if (baseURI == documentURI && uri.charAt(0) == "#") {
              return uri;
            }
            try {
              return new URL(uri, baseURI).href;
            } catch (ex) {
            }
            return uri;
          }
          var links = this._getAllNodesWithTag(articleContent, ["a"]);
          this._forEachNode(links, function(link) {
            var href = link.getAttribute("href");
            if (href) {
              if (href.indexOf("javascript:") === 0) {
                if (link.childNodes.length === 1 && link.childNodes[0].nodeType === this.TEXT_NODE) {
                  var text = this._doc.createTextNode(link.textContent);
                  link.parentNode.replaceChild(text, link);
                } else {
                  var container = this._doc.createElement("span");
                  while (link.firstChild) {
                    container.appendChild(link.firstChild);
                  }
                  link.parentNode.replaceChild(container, link);
                }
              } else {
                link.setAttribute("href", toAbsoluteURI(href));
              }
            }
          });
          var medias = this._getAllNodesWithTag(articleContent, [
            "img",
            "picture",
            "figure",
            "video",
            "audio",
            "source"
          ]);
          this._forEachNode(medias, function(media) {
            var src = media.getAttribute("src");
            var poster = media.getAttribute("poster");
            var srcset = media.getAttribute("srcset");
            if (src) {
              media.setAttribute("src", toAbsoluteURI(src));
            }
            if (poster) {
              media.setAttribute("poster", toAbsoluteURI(poster));
            }
            if (srcset) {
              var newSrcset = srcset.replace(this.REGEXPS.srcsetUrl, function(_, p1, p2, p3) {
                return toAbsoluteURI(p1) + (p2 || "") + p3;
              });
              media.setAttribute("srcset", newSrcset);
            }
          });
        },
        _simplifyNestedElements: function(articleContent) {
          var node = articleContent;
          while (node) {
            if (node.parentNode && ["DIV", "SECTION"].includes(node.tagName) && !(node.id && node.id.startsWith("readability"))) {
              if (this._isElementWithoutContent(node)) {
                node = this._removeAndGetNext(node);
                continue;
              } else if (this._hasSingleTagInsideElement(node, "DIV") || this._hasSingleTagInsideElement(node, "SECTION")) {
                var child = node.children[0];
                for (var i = 0; i < node.attributes.length; i++) {
                  child.setAttribute(node.attributes[i].name, node.attributes[i].value);
                }
                node.parentNode.replaceChild(child, node);
                node = child;
                continue;
              }
            }
            node = this._getNextNode(node);
          }
        },
        /**
         * Get the article title as an H1.
         *
         * @return string
         **/
        _getArticleTitle: function() {
          var doc = this._doc;
          var curTitle = "";
          var origTitle = "";
          try {
            curTitle = origTitle = doc.title.trim();
            if (typeof curTitle !== "string")
              curTitle = origTitle = this._getInnerText(doc.getElementsByTagName("title")[0]);
          } catch (e) {
          }
          var titleHadHierarchicalSeparators = false;
          function wordCount(str) {
            return str.split(/\s+/).length;
          }
          if (/ [\|\-\\\/>»] /.test(curTitle)) {
            titleHadHierarchicalSeparators = / [\\\/>»] /.test(curTitle);
            curTitle = origTitle.replace(/(.*)[\|\-\\\/>»] .*/gi, "$1");
            if (wordCount(curTitle) < 3)
              curTitle = origTitle.replace(/[^\|\-\\\/>»]*[\|\-\\\/>»](.*)/gi, "$1");
          } else if (curTitle.indexOf(": ") !== -1) {
            var headings = this._concatNodeLists(
              doc.getElementsByTagName("h1"),
              doc.getElementsByTagName("h2")
            );
            var trimmedTitle = curTitle.trim();
            var match = this._someNode(headings, function(heading) {
              return heading.textContent.trim() === trimmedTitle;
            });
            if (!match) {
              curTitle = origTitle.substring(origTitle.lastIndexOf(":") + 1);
              if (wordCount(curTitle) < 3) {
                curTitle = origTitle.substring(origTitle.indexOf(":") + 1);
              } else if (wordCount(origTitle.substr(0, origTitle.indexOf(":"))) > 5) {
                curTitle = origTitle;
              }
            }
          } else if (curTitle.length > 150 || curTitle.length < 15) {
            var hOnes = doc.getElementsByTagName("h1");
            if (hOnes.length === 1)
              curTitle = this._getInnerText(hOnes[0]);
          }
          curTitle = curTitle.trim().replace(this.REGEXPS.normalize, " ");
          var curTitleWordCount = wordCount(curTitle);
          if (curTitleWordCount <= 4 && (!titleHadHierarchicalSeparators || curTitleWordCount != wordCount(origTitle.replace(/[\|\-\\\/>»]+/g, "")) - 1)) {
            curTitle = origTitle;
          }
          return curTitle;
        },
        /**
         * Prepare the HTML document for readability to scrape it.
         * This includes things like stripping javascript, CSS, and handling terrible markup.
         *
         * @return void
         **/
        _prepDocument: function() {
          var doc = this._doc;
          this._removeNodes(this._getAllNodesWithTag(doc, ["style"]));
          if (doc.body) {
            this._replaceBrs(doc.body);
          }
          this._replaceNodeTags(this._getAllNodesWithTag(doc, ["font"]), "SPAN");
        },
        /**
         * Finds the next node, starting from the given node, and ignoring
         * whitespace in between. If the given node is an element, the same node is
         * returned.
         */
        _nextNode: function(node) {
          var next2 = node;
          while (next2 && next2.nodeType != this.ELEMENT_NODE && this.REGEXPS.whitespace.test(next2.textContent)) {
            next2 = next2.nextSibling;
          }
          return next2;
        },
        /**
         * Replaces 2 or more successive <br> elements with a single <p>.
         * Whitespace between <br> elements are ignored. For example:
         *   <div>foo<br>bar<br> <br><br>abc</div>
         * will become:
         *   <div>foo<br>bar<p>abc</p></div>
         */
        _replaceBrs: function(elem) {
          this._forEachNode(this._getAllNodesWithTag(elem, ["br"]), function(br) {
            var next2 = br.nextSibling;
            var replaced = false;
            while ((next2 = this._nextNode(next2)) && next2.tagName == "BR") {
              replaced = true;
              var brSibling = next2.nextSibling;
              next2.parentNode.removeChild(next2);
              next2 = brSibling;
            }
            if (replaced) {
              var p = this._doc.createElement("p");
              br.parentNode.replaceChild(p, br);
              next2 = p.nextSibling;
              while (next2) {
                if (next2.tagName == "BR") {
                  var nextElem = this._nextNode(next2.nextSibling);
                  if (nextElem && nextElem.tagName == "BR")
                    break;
                }
                if (!this._isPhrasingContent(next2))
                  break;
                var sibling = next2.nextSibling;
                p.appendChild(next2);
                next2 = sibling;
              }
              while (p.lastChild && this._isWhitespace(p.lastChild)) {
                p.removeChild(p.lastChild);
              }
              if (p.parentNode.tagName === "P")
                this._setNodeTag(p.parentNode, "DIV");
            }
          });
        },
        _setNodeTag: function(node, tag) {
          this.log("_setNodeTag", node, tag);
          if (this._docJSDOMParser) {
            node.localName = tag.toLowerCase();
            node.tagName = tag.toUpperCase();
            return node;
          }
          var replacement = node.ownerDocument.createElement(tag);
          while (node.firstChild) {
            replacement.appendChild(node.firstChild);
          }
          node.parentNode.replaceChild(replacement, node);
          if (node.readability)
            replacement.readability = node.readability;
          for (var i = 0; i < node.attributes.length; i++) {
            try {
              replacement.setAttribute(node.attributes[i].name, node.attributes[i].value);
            } catch (ex) {
            }
          }
          return replacement;
        },
        /**
         * Prepare the article node for display. Clean out any inline styles,
         * iframes, forms, strip extraneous <p> tags, etc.
         *
         * @param Element
         * @return void
         **/
        _prepArticle: function(articleContent) {
          this._cleanStyles(articleContent);
          this._markDataTables(articleContent);
          this._fixLazyImages(articleContent);
          this._cleanConditionally(articleContent, "form");
          this._cleanConditionally(articleContent, "fieldset");
          this._clean(articleContent, "object");
          this._clean(articleContent, "embed");
          this._clean(articleContent, "footer");
          this._clean(articleContent, "link");
          this._clean(articleContent, "aside");
          var shareElementThreshold = this.DEFAULT_CHAR_THRESHOLD;
          this._forEachNode(articleContent.children, function(topCandidate) {
            this._cleanMatchedNodes(topCandidate, function(node, matchString) {
              return this.REGEXPS.shareElements.test(matchString) && node.textContent.length < shareElementThreshold;
            });
          });
          this._clean(articleContent, "iframe");
          this._clean(articleContent, "input");
          this._clean(articleContent, "textarea");
          this._clean(articleContent, "select");
          this._clean(articleContent, "button");
          this._cleanHeaders(articleContent);
          this._cleanConditionally(articleContent, "table");
          this._cleanConditionally(articleContent, "ul");
          this._cleanConditionally(articleContent, "div");
          this._replaceNodeTags(this._getAllNodesWithTag(articleContent, ["h1"]), "h2");
          this._removeNodes(this._getAllNodesWithTag(articleContent, ["p"]), function(paragraph) {
            var imgCount = paragraph.getElementsByTagName("img").length;
            var embedCount = paragraph.getElementsByTagName("embed").length;
            var objectCount = paragraph.getElementsByTagName("object").length;
            var iframeCount = paragraph.getElementsByTagName("iframe").length;
            var totalCount = imgCount + embedCount + objectCount + iframeCount;
            return totalCount === 0 && !this._getInnerText(paragraph, false);
          });
          this._forEachNode(this._getAllNodesWithTag(articleContent, ["br"]), function(br) {
            var next2 = this._nextNode(br.nextSibling);
            if (next2 && next2.tagName == "P")
              br.parentNode.removeChild(br);
          });
          this._forEachNode(this._getAllNodesWithTag(articleContent, ["table"]), function(table) {
            var tbody = this._hasSingleTagInsideElement(table, "TBODY") ? table.firstElementChild : table;
            if (this._hasSingleTagInsideElement(tbody, "TR")) {
              var row = tbody.firstElementChild;
              if (this._hasSingleTagInsideElement(row, "TD")) {
                var cell = row.firstElementChild;
                cell = this._setNodeTag(cell, this._everyNode(cell.childNodes, this._isPhrasingContent) ? "P" : "DIV");
                table.parentNode.replaceChild(cell, table);
              }
            }
          });
        },
        /**
         * Initialize a node with the readability object. Also checks the
         * className/id for special names to add to its score.
         *
         * @param Element
         * @return void
        **/
        _initializeNode: function(node) {
          node.readability = { "contentScore": 0 };
          switch (node.tagName) {
            case "DIV":
              node.readability.contentScore += 5;
              break;
            case "PRE":
            case "TD":
            case "BLOCKQUOTE":
              node.readability.contentScore += 3;
              break;
            case "ADDRESS":
            case "OL":
            case "UL":
            case "DL":
            case "DD":
            case "DT":
            case "LI":
            case "FORM":
              node.readability.contentScore -= 3;
              break;
            case "H1":
            case "H2":
            case "H3":
            case "H4":
            case "H5":
            case "H6":
            case "TH":
              node.readability.contentScore -= 5;
              break;
          }
          node.readability.contentScore += this._getClassWeight(node);
        },
        _removeAndGetNext: function(node) {
          var nextNode = this._getNextNode(node, true);
          node.parentNode.removeChild(node);
          return nextNode;
        },
        /**
         * Traverse the DOM from node to node, starting at the node passed in.
         * Pass true for the second parameter to indicate this node itself
         * (and its kids) are going away, and we want the next node over.
         *
         * Calling this in a loop will traverse the DOM depth-first.
         */
        _getNextNode: function(node, ignoreSelfAndKids) {
          if (!ignoreSelfAndKids && node.firstElementChild) {
            return node.firstElementChild;
          }
          if (node.nextElementSibling) {
            return node.nextElementSibling;
          }
          do {
            node = node.parentNode;
          } while (node && !node.nextElementSibling);
          return node && node.nextElementSibling;
        },
        // compares second text to first one
        // 1 = same text, 0 = completely different text
        // works the way that it splits both texts into words and then finds words that are unique in second text
        // the result is given by the lower length of unique parts
        _textSimilarity: function(textA, textB) {
          var tokensA = textA.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
          var tokensB = textB.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
          if (!tokensA.length || !tokensB.length) {
            return 0;
          }
          var uniqTokensB = tokensB.filter((token) => !tokensA.includes(token));
          var distanceB = uniqTokensB.join(" ").length / tokensB.join(" ").length;
          return 1 - distanceB;
        },
        _checkByline: function(node, matchString) {
          if (this._articleByline) {
            return false;
          }
          if (node.getAttribute !== void 0) {
            var rel = node.getAttribute("rel");
            var itemprop = node.getAttribute("itemprop");
          }
          if ((rel === "author" || itemprop && itemprop.indexOf("author") !== -1 || this.REGEXPS.byline.test(matchString)) && this._isValidByline(node.textContent)) {
            this._articleByline = node.textContent.trim();
            return true;
          }
          return false;
        },
        _getNodeAncestors: function(node, maxDepth) {
          maxDepth = maxDepth || 0;
          var i = 0, ancestors = [];
          while (node.parentNode) {
            ancestors.push(node.parentNode);
            if (maxDepth && ++i === maxDepth)
              break;
            node = node.parentNode;
          }
          return ancestors;
        },
        /***
         * grabArticle - Using a variety of metrics (content score, classname, element types), find the content that is
         *         most likely to be the stuff a user wants to read. Then return it wrapped up in a div.
         *
         * @param page a document to run upon. Needs to be a full document, complete with body.
         * @return Element
        **/
        _grabArticle: function(page) {
          this.log("**** grabArticle ****");
          var doc = this._doc;
          var isPaging = page !== null;
          page = page ? page : this._doc.body;
          if (!page) {
            this.log("No body found in document. Abort.");
            return null;
          }
          var pageCacheHtml = page.innerHTML;
          while (true) {
            this.log("Starting grabArticle loop");
            var stripUnlikelyCandidates = this._flagIsActive(this.FLAG_STRIP_UNLIKELYS);
            var elementsToScore = [];
            var node = this._doc.documentElement;
            let shouldRemoveTitleHeader = true;
            while (node) {
              if (node.tagName === "HTML") {
                this._articleLang = node.getAttribute("lang");
              }
              var matchString = node.className + " " + node.id;
              if (!this._isProbablyVisible(node)) {
                this.log("Removing hidden node - " + matchString);
                node = this._removeAndGetNext(node);
                continue;
              }
              if (node.getAttribute("aria-modal") == "true" && node.getAttribute("role") == "dialog") {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (this._checkByline(node, matchString)) {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (shouldRemoveTitleHeader && this._headerDuplicatesTitle(node)) {
                this.log("Removing header: ", node.textContent.trim(), this._articleTitle.trim());
                shouldRemoveTitleHeader = false;
                node = this._removeAndGetNext(node);
                continue;
              }
              if (stripUnlikelyCandidates) {
                if (this.REGEXPS.unlikelyCandidates.test(matchString) && !this.REGEXPS.okMaybeItsACandidate.test(matchString) && !this._hasAncestorTag(node, "table") && !this._hasAncestorTag(node, "code") && node.tagName !== "BODY" && node.tagName !== "A") {
                  this.log("Removing unlikely candidate - " + matchString);
                  node = this._removeAndGetNext(node);
                  continue;
                }
                if (this.UNLIKELY_ROLES.includes(node.getAttribute("role"))) {
                  this.log("Removing content with role " + node.getAttribute("role") + " - " + matchString);
                  node = this._removeAndGetNext(node);
                  continue;
                }
              }
              if ((node.tagName === "DIV" || node.tagName === "SECTION" || node.tagName === "HEADER" || node.tagName === "H1" || node.tagName === "H2" || node.tagName === "H3" || node.tagName === "H4" || node.tagName === "H5" || node.tagName === "H6") && this._isElementWithoutContent(node)) {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (this.DEFAULT_TAGS_TO_SCORE.indexOf(node.tagName) !== -1) {
                elementsToScore.push(node);
              }
              if (node.tagName === "DIV") {
                var p = null;
                var childNode = node.firstChild;
                while (childNode) {
                  var nextSibling = childNode.nextSibling;
                  if (this._isPhrasingContent(childNode)) {
                    if (p !== null) {
                      p.appendChild(childNode);
                    } else if (!this._isWhitespace(childNode)) {
                      p = doc.createElement("p");
                      node.replaceChild(p, childNode);
                      p.appendChild(childNode);
                    }
                  } else if (p !== null) {
                    while (p.lastChild && this._isWhitespace(p.lastChild)) {
                      p.removeChild(p.lastChild);
                    }
                    p = null;
                  }
                  childNode = nextSibling;
                }
                if (this._hasSingleTagInsideElement(node, "P") && this._getLinkDensity(node) < 0.25) {
                  var newNode = node.children[0];
                  node.parentNode.replaceChild(newNode, node);
                  node = newNode;
                  elementsToScore.push(node);
                } else if (!this._hasChildBlockElement(node)) {
                  node = this._setNodeTag(node, "P");
                  elementsToScore.push(node);
                }
              }
              node = this._getNextNode(node);
            }
            var candidates = [];
            this._forEachNode(elementsToScore, function(elementToScore) {
              if (!elementToScore.parentNode || typeof elementToScore.parentNode.tagName === "undefined")
                return;
              var innerText = this._getInnerText(elementToScore);
              if (innerText.length < 25)
                return;
              var ancestors2 = this._getNodeAncestors(elementToScore, 5);
              if (ancestors2.length === 0)
                return;
              var contentScore = 0;
              contentScore += 1;
              contentScore += innerText.split(this.REGEXPS.commas).length;
              contentScore += Math.min(Math.floor(innerText.length / 100), 3);
              this._forEachNode(ancestors2, function(ancestor, level) {
                if (!ancestor.tagName || !ancestor.parentNode || typeof ancestor.parentNode.tagName === "undefined")
                  return;
                if (typeof ancestor.readability === "undefined") {
                  this._initializeNode(ancestor);
                  candidates.push(ancestor);
                }
                if (level === 0)
                  var scoreDivider = 1;
                else if (level === 1)
                  scoreDivider = 2;
                else
                  scoreDivider = level * 3;
                ancestor.readability.contentScore += contentScore / scoreDivider;
              });
            });
            var topCandidates = [];
            for (var c = 0, cl = candidates.length; c < cl; c += 1) {
              var candidate = candidates[c];
              var candidateScore = candidate.readability.contentScore * (1 - this._getLinkDensity(candidate));
              candidate.readability.contentScore = candidateScore;
              this.log("Candidate:", candidate, "with score " + candidateScore);
              for (var t = 0; t < this._nbTopCandidates; t++) {
                var aTopCandidate = topCandidates[t];
                if (!aTopCandidate || candidateScore > aTopCandidate.readability.contentScore) {
                  topCandidates.splice(t, 0, candidate);
                  if (topCandidates.length > this._nbTopCandidates)
                    topCandidates.pop();
                  break;
                }
              }
            }
            var topCandidate = topCandidates[0] || null;
            var neededToCreateTopCandidate = false;
            var parentOfTopCandidate;
            if (topCandidate === null || topCandidate.tagName === "BODY") {
              topCandidate = doc.createElement("DIV");
              neededToCreateTopCandidate = true;
              while (page.firstChild) {
                this.log("Moving child out:", page.firstChild);
                topCandidate.appendChild(page.firstChild);
              }
              page.appendChild(topCandidate);
              this._initializeNode(topCandidate);
            } else if (topCandidate) {
              var alternativeCandidateAncestors = [];
              for (var i = 1; i < topCandidates.length; i++) {
                if (topCandidates[i].readability.contentScore / topCandidate.readability.contentScore >= 0.75) {
                  alternativeCandidateAncestors.push(this._getNodeAncestors(topCandidates[i]));
                }
              }
              var MINIMUM_TOPCANDIDATES = 3;
              if (alternativeCandidateAncestors.length >= MINIMUM_TOPCANDIDATES) {
                parentOfTopCandidate = topCandidate.parentNode;
                while (parentOfTopCandidate.tagName !== "BODY") {
                  var listsContainingThisAncestor = 0;
                  for (var ancestorIndex = 0; ancestorIndex < alternativeCandidateAncestors.length && listsContainingThisAncestor < MINIMUM_TOPCANDIDATES; ancestorIndex++) {
                    listsContainingThisAncestor += Number(alternativeCandidateAncestors[ancestorIndex].includes(parentOfTopCandidate));
                  }
                  if (listsContainingThisAncestor >= MINIMUM_TOPCANDIDATES) {
                    topCandidate = parentOfTopCandidate;
                    break;
                  }
                  parentOfTopCandidate = parentOfTopCandidate.parentNode;
                }
              }
              if (!topCandidate.readability) {
                this._initializeNode(topCandidate);
              }
              parentOfTopCandidate = topCandidate.parentNode;
              var lastScore = topCandidate.readability.contentScore;
              var scoreThreshold = lastScore / 3;
              while (parentOfTopCandidate.tagName !== "BODY") {
                if (!parentOfTopCandidate.readability) {
                  parentOfTopCandidate = parentOfTopCandidate.parentNode;
                  continue;
                }
                var parentScore = parentOfTopCandidate.readability.contentScore;
                if (parentScore < scoreThreshold)
                  break;
                if (parentScore > lastScore) {
                  topCandidate = parentOfTopCandidate;
                  break;
                }
                lastScore = parentOfTopCandidate.readability.contentScore;
                parentOfTopCandidate = parentOfTopCandidate.parentNode;
              }
              parentOfTopCandidate = topCandidate.parentNode;
              while (parentOfTopCandidate.tagName != "BODY" && parentOfTopCandidate.children.length == 1) {
                topCandidate = parentOfTopCandidate;
                parentOfTopCandidate = topCandidate.parentNode;
              }
              if (!topCandidate.readability) {
                this._initializeNode(topCandidate);
              }
            }
            var articleContent = doc.createElement("DIV");
            if (isPaging)
              articleContent.id = "readability-content";
            var siblingScoreThreshold = Math.max(10, topCandidate.readability.contentScore * 0.2);
            parentOfTopCandidate = topCandidate.parentNode;
            var siblings = parentOfTopCandidate.children;
            for (var s = 0, sl = siblings.length; s < sl; s++) {
              var sibling = siblings[s];
              var append = false;
              this.log("Looking at sibling node:", sibling, sibling.readability ? "with score " + sibling.readability.contentScore : "");
              this.log("Sibling has score", sibling.readability ? sibling.readability.contentScore : "Unknown");
              if (sibling === topCandidate) {
                append = true;
              } else {
                var contentBonus = 0;
                if (sibling.className === topCandidate.className && topCandidate.className !== "")
                  contentBonus += topCandidate.readability.contentScore * 0.2;
                if (sibling.readability && sibling.readability.contentScore + contentBonus >= siblingScoreThreshold) {
                  append = true;
                } else if (sibling.nodeName === "P") {
                  var linkDensity = this._getLinkDensity(sibling);
                  var nodeContent = this._getInnerText(sibling);
                  var nodeLength = nodeContent.length;
                  if (nodeLength > 80 && linkDensity < 0.25) {
                    append = true;
                  } else if (nodeLength < 80 && nodeLength > 0 && linkDensity === 0 && nodeContent.search(/\.( |$)/) !== -1) {
                    append = true;
                  }
                }
              }
              if (append) {
                this.log("Appending node:", sibling);
                if (this.ALTER_TO_DIV_EXCEPTIONS.indexOf(sibling.nodeName) === -1) {
                  this.log("Altering sibling:", sibling, "to div.");
                  sibling = this._setNodeTag(sibling, "DIV");
                }
                articleContent.appendChild(sibling);
                siblings = parentOfTopCandidate.children;
                s -= 1;
                sl -= 1;
              }
            }
            if (this._debug)
              this.log("Article content pre-prep: " + articleContent.innerHTML);
            this._prepArticle(articleContent);
            if (this._debug)
              this.log("Article content post-prep: " + articleContent.innerHTML);
            if (neededToCreateTopCandidate) {
              topCandidate.id = "readability-page-1";
              topCandidate.className = "page";
            } else {
              var div = doc.createElement("DIV");
              div.id = "readability-page-1";
              div.className = "page";
              while (articleContent.firstChild) {
                div.appendChild(articleContent.firstChild);
              }
              articleContent.appendChild(div);
            }
            if (this._debug)
              this.log("Article content after paging: " + articleContent.innerHTML);
            var parseSuccessful = true;
            var textLength = this._getInnerText(articleContent, true).length;
            if (textLength < this._charThreshold) {
              parseSuccessful = false;
              page.innerHTML = pageCacheHtml;
              if (this._flagIsActive(this.FLAG_STRIP_UNLIKELYS)) {
                this._removeFlag(this.FLAG_STRIP_UNLIKELYS);
                this._attempts.push({ articleContent, textLength });
              } else if (this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) {
                this._removeFlag(this.FLAG_WEIGHT_CLASSES);
                this._attempts.push({ articleContent, textLength });
              } else if (this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) {
                this._removeFlag(this.FLAG_CLEAN_CONDITIONALLY);
                this._attempts.push({ articleContent, textLength });
              } else {
                this._attempts.push({ articleContent, textLength });
                this._attempts.sort(function(a, b) {
                  return b.textLength - a.textLength;
                });
                if (!this._attempts[0].textLength) {
                  return null;
                }
                articleContent = this._attempts[0].articleContent;
                parseSuccessful = true;
              }
            }
            if (parseSuccessful) {
              var ancestors = [parentOfTopCandidate, topCandidate].concat(this._getNodeAncestors(parentOfTopCandidate));
              this._someNode(ancestors, function(ancestor) {
                if (!ancestor.tagName)
                  return false;
                var articleDir = ancestor.getAttribute("dir");
                if (articleDir) {
                  this._articleDir = articleDir;
                  return true;
                }
                return false;
              });
              return articleContent;
            }
          }
        },
        /**
         * Check whether the input string could be a byline.
         * This verifies that the input is a string, and that the length
         * is less than 100 chars.
         *
         * @param possibleByline {string} - a string to check whether its a byline.
         * @return Boolean - whether the input string is a byline.
         */
        _isValidByline: function(byline) {
          if (typeof byline == "string" || byline instanceof String) {
            byline = byline.trim();
            return byline.length > 0 && byline.length < 100;
          }
          return false;
        },
        /**
         * Converts some of the common HTML entities in string to their corresponding characters.
         *
         * @param str {string} - a string to unescape.
         * @return string without HTML entity.
         */
        _unescapeHtmlEntities: function(str) {
          if (!str) {
            return str;
          }
          var htmlEscapeMap = this.HTML_ESCAPE_MAP;
          return str.replace(/&(quot|amp|apos|lt|gt);/g, function(_, tag) {
            return htmlEscapeMap[tag];
          }).replace(/&#(?:x([0-9a-z]{1,4})|([0-9]{1,4}));/gi, function(_, hex, numStr) {
            var num = parseInt(hex || numStr, hex ? 16 : 10);
            return String.fromCharCode(num);
          });
        },
        /**
         * Try to extract metadata from JSON-LD object.
         * For now, only Schema.org objects of type Article or its subtypes are supported.
         * @return Object with any metadata that could be extracted (possibly none)
         */
        _getJSONLD: function(doc) {
          var scripts = this._getAllNodesWithTag(doc, ["script"]);
          var metadata;
          this._forEachNode(scripts, function(jsonLdElement) {
            if (!metadata && jsonLdElement.getAttribute("type") === "application/ld+json") {
              try {
                var content = jsonLdElement.textContent.replace(/^\s*<!\[CDATA\[|\]\]>\s*$/g, "");
                var parsed = JSON.parse(content);
                if (!parsed["@context"] || !parsed["@context"].match(/^https?\:\/\/schema\.org$/)) {
                  return;
                }
                if (!parsed["@type"] && Array.isArray(parsed["@graph"])) {
                  parsed = parsed["@graph"].find(function(it) {
                    return (it["@type"] || "").match(
                      this.REGEXPS.jsonLdArticleTypes
                    );
                  });
                }
                if (!parsed || !parsed["@type"] || !parsed["@type"].match(this.REGEXPS.jsonLdArticleTypes)) {
                  return;
                }
                metadata = {};
                if (typeof parsed.name === "string" && typeof parsed.headline === "string" && parsed.name !== parsed.headline) {
                  var title = this._getArticleTitle();
                  var nameMatches = this._textSimilarity(parsed.name, title) > 0.75;
                  var headlineMatches = this._textSimilarity(parsed.headline, title) > 0.75;
                  if (headlineMatches && !nameMatches) {
                    metadata.title = parsed.headline;
                  } else {
                    metadata.title = parsed.name;
                  }
                } else if (typeof parsed.name === "string") {
                  metadata.title = parsed.name.trim();
                } else if (typeof parsed.headline === "string") {
                  metadata.title = parsed.headline.trim();
                }
                if (parsed.author) {
                  if (typeof parsed.author.name === "string") {
                    metadata.byline = parsed.author.name.trim();
                  } else if (Array.isArray(parsed.author) && parsed.author[0] && typeof parsed.author[0].name === "string") {
                    metadata.byline = parsed.author.filter(function(author) {
                      return author && typeof author.name === "string";
                    }).map(function(author) {
                      return author.name.trim();
                    }).join(", ");
                  }
                }
                if (typeof parsed.description === "string") {
                  metadata.excerpt = parsed.description.trim();
                }
                if (parsed.publisher && typeof parsed.publisher.name === "string") {
                  metadata.siteName = parsed.publisher.name.trim();
                }
                if (typeof parsed.datePublished === "string") {
                  metadata.datePublished = parsed.datePublished.trim();
                }
                return;
              } catch (err) {
                this.log(err.message);
              }
            }
          });
          return metadata ? metadata : {};
        },
        /**
         * Attempts to get excerpt and byline metadata for the article.
         *
         * @param {Object} jsonld — object containing any metadata that
         * could be extracted from JSON-LD object.
         *
         * @return Object with optional "excerpt" and "byline" properties
         */
        _getArticleMetadata: function(jsonld) {
          var metadata = {};
          var values = {};
          var metaElements = this._doc.getElementsByTagName("meta");
          var propertyPattern = /\s*(article|dc|dcterm|og|twitter)\s*:\s*(author|creator|description|published_time|title|site_name)\s*/gi;
          var namePattern = /^\s*(?:(dc|dcterm|og|twitter|weibo:(article|webpage))\s*[\.:]\s*)?(author|creator|description|title|site_name)\s*$/i;
          this._forEachNode(metaElements, function(element) {
            var elementName = element.getAttribute("name");
            var elementProperty = element.getAttribute("property");
            var content = element.getAttribute("content");
            if (!content) {
              return;
            }
            var matches = null;
            var name = null;
            if (elementProperty) {
              matches = elementProperty.match(propertyPattern);
              if (matches) {
                name = matches[0].toLowerCase().replace(/\s/g, "");
                values[name] = content.trim();
              }
            }
            if (!matches && elementName && namePattern.test(elementName)) {
              name = elementName;
              if (content) {
                name = name.toLowerCase().replace(/\s/g, "").replace(/\./g, ":");
                values[name] = content.trim();
              }
            }
          });
          metadata.title = jsonld.title || values["dc:title"] || values["dcterm:title"] || values["og:title"] || values["weibo:article:title"] || values["weibo:webpage:title"] || values["title"] || values["twitter:title"];
          if (!metadata.title) {
            metadata.title = this._getArticleTitle();
          }
          metadata.byline = jsonld.byline || values["dc:creator"] || values["dcterm:creator"] || values["author"];
          metadata.excerpt = jsonld.excerpt || values["dc:description"] || values["dcterm:description"] || values["og:description"] || values["weibo:article:description"] || values["weibo:webpage:description"] || values["description"] || values["twitter:description"];
          metadata.siteName = jsonld.siteName || values["og:site_name"];
          metadata.publishedTime = jsonld.datePublished || values["article:published_time"] || null;
          metadata.title = this._unescapeHtmlEntities(metadata.title);
          metadata.byline = this._unescapeHtmlEntities(metadata.byline);
          metadata.excerpt = this._unescapeHtmlEntities(metadata.excerpt);
          metadata.siteName = this._unescapeHtmlEntities(metadata.siteName);
          metadata.publishedTime = this._unescapeHtmlEntities(metadata.publishedTime);
          return metadata;
        },
        /**
         * Check if node is image, or if node contains exactly only one image
         * whether as a direct child or as its descendants.
         *
         * @param Element
        **/
        _isSingleImage: function(node) {
          if (node.tagName === "IMG") {
            return true;
          }
          if (node.children.length !== 1 || node.textContent.trim() !== "") {
            return false;
          }
          return this._isSingleImage(node.children[0]);
        },
        /**
         * Find all <noscript> that are located after <img> nodes, and which contain only one
         * <img> element. Replace the first image with the image from inside the <noscript> tag,
         * and remove the <noscript> tag. This improves the quality of the images we use on
         * some sites (e.g. Medium).
         *
         * @param Element
        **/
        _unwrapNoscriptImages: function(doc) {
          var imgs = Array.from(doc.getElementsByTagName("img"));
          this._forEachNode(imgs, function(img) {
            for (var i = 0; i < img.attributes.length; i++) {
              var attr = img.attributes[i];
              switch (attr.name) {
                case "src":
                case "srcset":
                case "data-src":
                case "data-srcset":
                  return;
              }
              if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                return;
              }
            }
            img.parentNode.removeChild(img);
          });
          var noscripts = Array.from(doc.getElementsByTagName("noscript"));
          this._forEachNode(noscripts, function(noscript) {
            var tmp = doc.createElement("div");
            tmp.innerHTML = noscript.innerHTML;
            if (!this._isSingleImage(tmp)) {
              return;
            }
            var prevElement = noscript.previousElementSibling;
            if (prevElement && this._isSingleImage(prevElement)) {
              var prevImg = prevElement;
              if (prevImg.tagName !== "IMG") {
                prevImg = prevElement.getElementsByTagName("img")[0];
              }
              var newImg = tmp.getElementsByTagName("img")[0];
              for (var i = 0; i < prevImg.attributes.length; i++) {
                var attr = prevImg.attributes[i];
                if (attr.value === "") {
                  continue;
                }
                if (attr.name === "src" || attr.name === "srcset" || /\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                  if (newImg.getAttribute(attr.name) === attr.value) {
                    continue;
                  }
                  var attrName = attr.name;
                  if (newImg.hasAttribute(attrName)) {
                    attrName = "data-old-" + attrName;
                  }
                  newImg.setAttribute(attrName, attr.value);
                }
              }
              noscript.parentNode.replaceChild(tmp.firstElementChild, prevElement);
            }
          });
        },
        /**
         * Removes script tags from the document.
         *
         * @param Element
        **/
        _removeScripts: function(doc) {
          this._removeNodes(this._getAllNodesWithTag(doc, ["script", "noscript"]));
        },
        /**
         * Check if this node has only whitespace and a single element with given tag
         * Returns false if the DIV node contains non-empty text nodes
         * or if it contains no element with given tag or more than 1 element.
         *
         * @param Element
         * @param string tag of child element
        **/
        _hasSingleTagInsideElement: function(element, tag) {
          if (element.children.length != 1 || element.children[0].tagName !== tag) {
            return false;
          }
          return !this._someNode(element.childNodes, function(node) {
            return node.nodeType === this.TEXT_NODE && this.REGEXPS.hasContent.test(node.textContent);
          });
        },
        _isElementWithoutContent: function(node) {
          return node.nodeType === this.ELEMENT_NODE && node.textContent.trim().length == 0 && (node.children.length == 0 || node.children.length == node.getElementsByTagName("br").length + node.getElementsByTagName("hr").length);
        },
        /**
         * Determine whether element has any children block level elements.
         *
         * @param Element
         */
        _hasChildBlockElement: function(element) {
          return this._someNode(element.childNodes, function(node) {
            return this.DIV_TO_P_ELEMS.has(node.tagName) || this._hasChildBlockElement(node);
          });
        },
        /***
         * Determine if a node qualifies as phrasing content.
         * https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Content_categories#Phrasing_content
        **/
        _isPhrasingContent: function(node) {
          return node.nodeType === this.TEXT_NODE || this.PHRASING_ELEMS.indexOf(node.tagName) !== -1 || (node.tagName === "A" || node.tagName === "DEL" || node.tagName === "INS") && this._everyNode(node.childNodes, this._isPhrasingContent);
        },
        _isWhitespace: function(node) {
          return node.nodeType === this.TEXT_NODE && node.textContent.trim().length === 0 || node.nodeType === this.ELEMENT_NODE && node.tagName === "BR";
        },
        /**
         * Get the inner text of a node - cross browser compatibly.
         * This also strips out any excess whitespace to be found.
         *
         * @param Element
         * @param Boolean normalizeSpaces (default: true)
         * @return string
        **/
        _getInnerText: function(e, normalizeSpaces) {
          normalizeSpaces = typeof normalizeSpaces === "undefined" ? true : normalizeSpaces;
          var textContent = e.textContent.trim();
          if (normalizeSpaces) {
            return textContent.replace(this.REGEXPS.normalize, " ");
          }
          return textContent;
        },
        /**
         * Get the number of times a string s appears in the node e.
         *
         * @param Element
         * @param string - what to split on. Default is ","
         * @return number (integer)
        **/
        _getCharCount: function(e, s) {
          s = s || ",";
          return this._getInnerText(e).split(s).length - 1;
        },
        /**
         * Remove the style attribute on every e and under.
         * TODO: Test if getElementsByTagName(*) is faster.
         *
         * @param Element
         * @return void
        **/
        _cleanStyles: function(e) {
          if (!e || e.tagName.toLowerCase() === "svg")
            return;
          for (var i = 0; i < this.PRESENTATIONAL_ATTRIBUTES.length; i++) {
            e.removeAttribute(this.PRESENTATIONAL_ATTRIBUTES[i]);
          }
          if (this.DEPRECATED_SIZE_ATTRIBUTE_ELEMS.indexOf(e.tagName) !== -1) {
            e.removeAttribute("width");
            e.removeAttribute("height");
          }
          var cur = e.firstElementChild;
          while (cur !== null) {
            this._cleanStyles(cur);
            cur = cur.nextElementSibling;
          }
        },
        /**
         * Get the density of links as a percentage of the content
         * This is the amount of text that is inside a link divided by the total text in the node.
         *
         * @param Element
         * @return number (float)
        **/
        _getLinkDensity: function(element) {
          var textLength = this._getInnerText(element).length;
          if (textLength === 0)
            return 0;
          var linkLength = 0;
          this._forEachNode(element.getElementsByTagName("a"), function(linkNode) {
            var href = linkNode.getAttribute("href");
            var coefficient = href && this.REGEXPS.hashUrl.test(href) ? 0.3 : 1;
            linkLength += this._getInnerText(linkNode).length * coefficient;
          });
          return linkLength / textLength;
        },
        /**
         * Get an elements class/id weight. Uses regular expressions to tell if this
         * element looks good or bad.
         *
         * @param Element
         * @return number (Integer)
        **/
        _getClassWeight: function(e) {
          if (!this._flagIsActive(this.FLAG_WEIGHT_CLASSES))
            return 0;
          var weight = 0;
          if (typeof e.className === "string" && e.className !== "") {
            if (this.REGEXPS.negative.test(e.className))
              weight -= 25;
            if (this.REGEXPS.positive.test(e.className))
              weight += 25;
          }
          if (typeof e.id === "string" && e.id !== "") {
            if (this.REGEXPS.negative.test(e.id))
              weight -= 25;
            if (this.REGEXPS.positive.test(e.id))
              weight += 25;
          }
          return weight;
        },
        /**
         * Clean a node of all elements of type "tag".
         * (Unless it's a youtube/vimeo video. People love movies.)
         *
         * @param Element
         * @param string tag to clean
         * @return void
         **/
        _clean: function(e, tag) {
          var isEmbed = ["object", "embed", "iframe"].indexOf(tag) !== -1;
          this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(element) {
            if (isEmbed) {
              for (var i = 0; i < element.attributes.length; i++) {
                if (this._allowedVideoRegex.test(element.attributes[i].value)) {
                  return false;
                }
              }
              if (element.tagName === "object" && this._allowedVideoRegex.test(element.innerHTML)) {
                return false;
              }
            }
            return true;
          });
        },
        /**
         * Check if a given node has one of its ancestor tag name matching the
         * provided one.
         * @param  HTMLElement node
         * @param  String      tagName
         * @param  Number      maxDepth
         * @param  Function    filterFn a filter to invoke to determine whether this node 'counts'
         * @return Boolean
         */
        _hasAncestorTag: function(node, tagName, maxDepth, filterFn) {
          maxDepth = maxDepth || 3;
          tagName = tagName.toUpperCase();
          var depth = 0;
          while (node.parentNode) {
            if (maxDepth > 0 && depth > maxDepth)
              return false;
            if (node.parentNode.tagName === tagName && (!filterFn || filterFn(node.parentNode)))
              return true;
            node = node.parentNode;
            depth++;
          }
          return false;
        },
        /**
         * Return an object indicating how many rows and columns this table has.
         */
        _getRowAndColumnCount: function(table) {
          var rows = 0;
          var columns = 0;
          var trs = table.getElementsByTagName("tr");
          for (var i = 0; i < trs.length; i++) {
            var rowspan = trs[i].getAttribute("rowspan") || 0;
            if (rowspan) {
              rowspan = parseInt(rowspan, 10);
            }
            rows += rowspan || 1;
            var columnsInThisRow = 0;
            var cells = trs[i].getElementsByTagName("td");
            for (var j = 0; j < cells.length; j++) {
              var colspan = cells[j].getAttribute("colspan") || 0;
              if (colspan) {
                colspan = parseInt(colspan, 10);
              }
              columnsInThisRow += colspan || 1;
            }
            columns = Math.max(columns, columnsInThisRow);
          }
          return { rows, columns };
        },
        /**
         * Look for 'data' (as opposed to 'layout') tables, for which we use
         * similar checks as
         * https://searchfox.org/mozilla-central/rev/f82d5c549f046cb64ce5602bfd894b7ae807c8f8/accessible/generic/TableAccessible.cpp#19
         */
        _markDataTables: function(root2) {
          var tables = root2.getElementsByTagName("table");
          for (var i = 0; i < tables.length; i++) {
            var table = tables[i];
            var role = table.getAttribute("role");
            if (role == "presentation") {
              table._readabilityDataTable = false;
              continue;
            }
            var datatable = table.getAttribute("datatable");
            if (datatable == "0") {
              table._readabilityDataTable = false;
              continue;
            }
            var summary = table.getAttribute("summary");
            if (summary) {
              table._readabilityDataTable = true;
              continue;
            }
            var caption = table.getElementsByTagName("caption")[0];
            if (caption && caption.childNodes.length > 0) {
              table._readabilityDataTable = true;
              continue;
            }
            var dataTableDescendants = ["col", "colgroup", "tfoot", "thead", "th"];
            var descendantExists = function(tag) {
              return !!table.getElementsByTagName(tag)[0];
            };
            if (dataTableDescendants.some(descendantExists)) {
              this.log("Data table because found data-y descendant");
              table._readabilityDataTable = true;
              continue;
            }
            if (table.getElementsByTagName("table")[0]) {
              table._readabilityDataTable = false;
              continue;
            }
            var sizeInfo = this._getRowAndColumnCount(table);
            if (sizeInfo.rows >= 10 || sizeInfo.columns > 4) {
              table._readabilityDataTable = true;
              continue;
            }
            table._readabilityDataTable = sizeInfo.rows * sizeInfo.columns > 10;
          }
        },
        /* convert images and figures that have properties like data-src into images that can be loaded without JS */
        _fixLazyImages: function(root2) {
          this._forEachNode(this._getAllNodesWithTag(root2, ["img", "picture", "figure"]), function(elem) {
            if (elem.src && this.REGEXPS.b64DataUrl.test(elem.src)) {
              var parts = this.REGEXPS.b64DataUrl.exec(elem.src);
              if (parts[1] === "image/svg+xml") {
                return;
              }
              var srcCouldBeRemoved = false;
              for (var i = 0; i < elem.attributes.length; i++) {
                var attr = elem.attributes[i];
                if (attr.name === "src") {
                  continue;
                }
                if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                  srcCouldBeRemoved = true;
                  break;
                }
              }
              if (srcCouldBeRemoved) {
                var b64starts = elem.src.search(/base64\s*/i) + 7;
                var b64length = elem.src.length - b64starts;
                if (b64length < 133) {
                  elem.removeAttribute("src");
                }
              }
            }
            if ((elem.src || elem.srcset && elem.srcset != "null") && elem.className.toLowerCase().indexOf("lazy") === -1) {
              return;
            }
            for (var j = 0; j < elem.attributes.length; j++) {
              attr = elem.attributes[j];
              if (attr.name === "src" || attr.name === "srcset" || attr.name === "alt") {
                continue;
              }
              var copyTo = null;
              if (/\.(jpg|jpeg|png|webp)\s+\d/.test(attr.value)) {
                copyTo = "srcset";
              } else if (/^\s*\S+\.(jpg|jpeg|png|webp)\S*\s*$/.test(attr.value)) {
                copyTo = "src";
              }
              if (copyTo) {
                if (elem.tagName === "IMG" || elem.tagName === "PICTURE") {
                  elem.setAttribute(copyTo, attr.value);
                } else if (elem.tagName === "FIGURE" && !this._getAllNodesWithTag(elem, ["img", "picture"]).length) {
                  var img = this._doc.createElement("img");
                  img.setAttribute(copyTo, attr.value);
                  elem.appendChild(img);
                }
              }
            }
          });
        },
        _getTextDensity: function(e, tags) {
          var textLength = this._getInnerText(e, true).length;
          if (textLength === 0) {
            return 0;
          }
          var childrenLength = 0;
          var children = this._getAllNodesWithTag(e, tags);
          this._forEachNode(children, (child) => childrenLength += this._getInnerText(child, true).length);
          return childrenLength / textLength;
        },
        /**
         * Clean an element of all tags of type "tag" if they look fishy.
         * "Fishy" is an algorithm based on content length, classnames, link density, number of images & embeds, etc.
         *
         * @return void
         **/
        _cleanConditionally: function(e, tag) {
          if (!this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY))
            return;
          this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(node) {
            var isDataTable = function(t) {
              return t._readabilityDataTable;
            };
            var isList = tag === "ul" || tag === "ol";
            if (!isList) {
              var listLength = 0;
              var listNodes = this._getAllNodesWithTag(node, ["ul", "ol"]);
              this._forEachNode(listNodes, (list) => listLength += this._getInnerText(list).length);
              isList = listLength / this._getInnerText(node).length > 0.9;
            }
            if (tag === "table" && isDataTable(node)) {
              return false;
            }
            if (this._hasAncestorTag(node, "table", -1, isDataTable)) {
              return false;
            }
            if (this._hasAncestorTag(node, "code")) {
              return false;
            }
            var weight = this._getClassWeight(node);
            this.log("Cleaning Conditionally", node);
            var contentScore = 0;
            if (weight + contentScore < 0) {
              return true;
            }
            if (this._getCharCount(node, ",") < 10) {
              var p = node.getElementsByTagName("p").length;
              var img = node.getElementsByTagName("img").length;
              var li = node.getElementsByTagName("li").length - 100;
              var input = node.getElementsByTagName("input").length;
              var headingDensity = this._getTextDensity(node, ["h1", "h2", "h3", "h4", "h5", "h6"]);
              var embedCount = 0;
              var embeds = this._getAllNodesWithTag(node, ["object", "embed", "iframe"]);
              for (var i = 0; i < embeds.length; i++) {
                for (var j = 0; j < embeds[i].attributes.length; j++) {
                  if (this._allowedVideoRegex.test(embeds[i].attributes[j].value)) {
                    return false;
                  }
                }
                if (embeds[i].tagName === "object" && this._allowedVideoRegex.test(embeds[i].innerHTML)) {
                  return false;
                }
                embedCount++;
              }
              var linkDensity = this._getLinkDensity(node);
              var contentLength = this._getInnerText(node).length;
              var haveToRemove = img > 1 && p / img < 0.5 && !this._hasAncestorTag(node, "figure") || !isList && li > p || input > Math.floor(p / 3) || !isList && headingDensity < 0.9 && contentLength < 25 && (img === 0 || img > 2) && !this._hasAncestorTag(node, "figure") || !isList && weight < 25 && linkDensity > 0.2 || weight >= 25 && linkDensity > 0.5 || (embedCount === 1 && contentLength < 75 || embedCount > 1);
              if (isList && haveToRemove) {
                for (var x = 0; x < node.children.length; x++) {
                  let child = node.children[x];
                  if (child.children.length > 1) {
                    return haveToRemove;
                  }
                }
                let li_count = node.getElementsByTagName("li").length;
                if (img == li_count) {
                  return false;
                }
              }
              return haveToRemove;
            }
            return false;
          });
        },
        /**
         * Clean out elements that match the specified conditions
         *
         * @param Element
         * @param Function determines whether a node should be removed
         * @return void
         **/
        _cleanMatchedNodes: function(e, filter) {
          var endOfSearchMarkerNode = this._getNextNode(e, true);
          var next2 = this._getNextNode(e);
          while (next2 && next2 != endOfSearchMarkerNode) {
            if (filter.call(this, next2, next2.className + " " + next2.id)) {
              next2 = this._removeAndGetNext(next2);
            } else {
              next2 = this._getNextNode(next2);
            }
          }
        },
        /**
         * Clean out spurious headers from an Element.
         *
         * @param Element
         * @return void
        **/
        _cleanHeaders: function(e) {
          let headingNodes = this._getAllNodesWithTag(e, ["h1", "h2"]);
          this._removeNodes(headingNodes, function(node) {
            let shouldRemove = this._getClassWeight(node) < 0;
            if (shouldRemove) {
              this.log("Removing header with low class weight:", node);
            }
            return shouldRemove;
          });
        },
        /**
         * Check if this node is an H1 or H2 element whose content is mostly
         * the same as the article title.
         *
         * @param Element  the node to check.
         * @return boolean indicating whether this is a title-like header.
         */
        _headerDuplicatesTitle: function(node) {
          if (node.tagName != "H1" && node.tagName != "H2") {
            return false;
          }
          var heading = this._getInnerText(node, false);
          this.log("Evaluating similarity of header:", heading, this._articleTitle);
          return this._textSimilarity(this._articleTitle, heading) > 0.75;
        },
        _flagIsActive: function(flag) {
          return (this._flags & flag) > 0;
        },
        _removeFlag: function(flag) {
          this._flags = this._flags & ~flag;
        },
        _isProbablyVisible: function(node) {
          return (!node.style || node.style.display != "none") && (!node.style || node.style.visibility != "hidden") && !node.hasAttribute("hidden") && (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.indexOf && node.className.indexOf("fallback-image") !== -1);
        },
        /**
         * Runs readability.
         *
         * Workflow:
         *  1. Prep the document by removing script tags, css, etc.
         *  2. Build readability's DOM tree.
         *  3. Grab the article content from the current dom tree.
         *  4. Replace the current DOM tree with the new one.
         *  5. Read peacefully.
         *
         * @return void
         **/
        parse: function() {
          if (this._maxElemsToParse > 0) {
            var numTags = this._doc.getElementsByTagName("*").length;
            if (numTags > this._maxElemsToParse) {
              throw new Error("Aborting parsing document; " + numTags + " elements found");
            }
          }
          this._unwrapNoscriptImages(this._doc);
          var jsonLd = this._disableJSONLD ? {} : this._getJSONLD(this._doc);
          this._removeScripts(this._doc);
          this._prepDocument();
          var metadata = this._getArticleMetadata(jsonLd);
          this._articleTitle = metadata.title;
          var articleContent = this._grabArticle();
          if (!articleContent)
            return null;
          this.log("Grabbed: " + articleContent.innerHTML);
          this._postProcessContent(articleContent);
          if (!metadata.excerpt) {
            var paragraphs = articleContent.getElementsByTagName("p");
            if (paragraphs.length > 0) {
              metadata.excerpt = paragraphs[0].textContent.trim();
            }
          }
          var textContent = articleContent.textContent;
          return {
            title: this._articleTitle,
            byline: metadata.byline || this._articleByline,
            dir: this._articleDir,
            lang: this._articleLang,
            content: this._serializer(articleContent),
            textContent,
            length: textContent.length,
            excerpt: metadata.excerpt,
            siteName: metadata.siteName || this._articleSiteName,
            publishedTime: metadata.publishedTime
          };
        }
      };
      if (typeof module === "object") {
        module.exports = Readability2;
      }
    }
  });

  // node_modules/@mozilla/readability/Readability-readerable.js
  var require_Readability_readerable = __commonJS({
    "node_modules/@mozilla/readability/Readability-readerable.js"(exports, module) {
      var REGEXPS = {
        // NOTE: These two regular expressions are duplicated in
        // Readability.js. Please keep both copies in sync.
        unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
        okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i
      };
      function isNodeVisible(node) {
        return (!node.style || node.style.display != "none") && !node.hasAttribute("hidden") && (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.indexOf && node.className.indexOf("fallback-image") !== -1);
      }
      function isProbablyReaderable(doc, options = {}) {
        if (typeof options == "function") {
          options = { visibilityChecker: options };
        }
        var defaultOptions = { minScore: 20, minContentLength: 140, visibilityChecker: isNodeVisible };
        options = Object.assign(defaultOptions, options);
        var nodes = doc.querySelectorAll("p, pre, article");
        var brNodes = doc.querySelectorAll("div > br");
        if (brNodes.length) {
          var set = new Set(nodes);
          [].forEach.call(brNodes, function(node) {
            set.add(node.parentNode);
          });
          nodes = Array.from(set);
        }
        var score = 0;
        return [].some.call(nodes, function(node) {
          if (!options.visibilityChecker(node)) {
            return false;
          }
          var matchString = node.className + " " + node.id;
          if (REGEXPS.unlikelyCandidates.test(matchString) && !REGEXPS.okMaybeItsACandidate.test(matchString)) {
            return false;
          }
          if (node.matches("li p")) {
            return false;
          }
          var textContentLength = node.textContent.trim().length;
          if (textContentLength < options.minContentLength) {
            return false;
          }
          score += Math.sqrt(textContentLength - options.minContentLength);
          if (score > options.minScore) {
            return true;
          }
          return false;
        });
      }
      if (typeof module === "object") {
        module.exports = isProbablyReaderable;
      }
    }
  });

  // node_modules/@mozilla/readability/index.js
  var require_readability = __commonJS({
    "node_modules/@mozilla/readability/index.js"(exports, module) {
      var Readability2 = require_Readability();
      var isProbablyReaderable = require_Readability_readerable();
      module.exports = {
        Readability: Readability2,
        isProbablyReaderable
      };
    }
  });

  // src/content/detect.ts
  var isAIChat = (url, doc) => {
    if (/(chatgpt\.com|chat\.openai\.com|claude\.ai|gemini\.google\.com|copilot\.microsoft\.com|perplexity\.ai|poe\.com)/i.test(url)) return true;
    if (/(tongyi\.com|tongyi\.aliyun\.com|chat\.deepseek\.com|deepseek\.com|kimi\.moonshot\.cn)/i.test(url)) return true;
    const hasQA = doc.querySelector("article, [data-message-author], [class*=prose] pre code");
    return !!hasQA;
  };

  // src/content/formatters/markdown.ts
  function formatLocalDateTime(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  }
  function buildChatMarkdown({
    title,
    platform,
    url,
    messages: messages2,
    model,
    createdAt,
    options
  }) {
    const includeTimestamps = options?.includeTimestamps ?? false;
    const userName = options?.userName || "USER";
    const clippedAtFormatted = formatLocalDateTime(/* @__PURE__ */ new Date());
    const createdAtFormatted = createdAt ? formatLocalDateTime(new Date(createdAt)) : null;
    const fm = [
      "---",
      "type: ai_chat",
      `platform: ${platform}`,
      model ? `model: ${model}` : null,
      `url: "${url}"`,
      `message_count: ${messages2.length}`,
      createdAtFormatted ? `created_at: "${createdAtFormatted}"` : null,
      `clipped_at: "${clippedAtFormatted}"`,
      "tags: [ai, chat, " + platform + "]",
      "---",
      ""
    ].filter((line) => line !== null).join("\n");
    const body = messages2.map((m, i) => {
      let heading = "";
      if (m.role === "user") {
        heading = `# ${i + 1} ${userName}`;
      } else {
        const modelName = model || "ASSISTANT";
        heading = `# ${i + 1} ${modelName}`;
      }
      if (includeTimestamps && m.timestamp) {
        const date = new Date(m.timestamp);
        const timeStr = formatLocalDateTime(date);
        heading += ` _[${timeStr}]_`;
      }
      const content = m.role === "user" ? m.text.split("\n").map((l) => `> ${l}`).join("\n") : m.text;
      return `${heading}

${content}
`;
    }).join("\n");
    return `${fm}
${body}
`;
  }

  // src/third_party/ai-chat-exporter/parse.ts
  var CHATGPT_ARTICLE_SELECTOR = "article";
  var CHATGPT_HEADER_SELECTOR = "h5";
  var CHATGPT_TITLE_REPLACE_TEXT = " - ChatGPT";
  var CLAUDE_MAIN_CONTAINER_SELECTOR = ".flex-1.flex.flex-col.gap-3.px-4.max-w-3xl.mx-auto.w-full.pt-1";
  var CLAUDE_USER_MESSAGE_SELECTOR = '[data-testid="user-message"]';
  var CLAUDE_ASSISTANT_MESSAGE_SELECTOR = ".font-claude-response";
  var COPILOT_MESSAGE_SELECTOR = '[data-content="user-message"], [data-content="ai-message"]';
  var COPILOT_USER_MESSAGE_SELECTOR = '[data-content="user-message"]';
  var GEMINI_MESSAGE_ITEM_SELECTOR = "user-query, model-response";
  var GEMINI_SIDEBAR_ACTIVE_CHAT_SELECTOR = 'div[data-test-id="conversation"].selected .conversation-title';
  var GEMINI_TITLE_REPLACE_TEXT = "Gemini - ";
  var TONGYI_TITLE_REPLACE_TEXT = " - \u901A\u4E49";
  var DEEPSEEK_TITLE_REPLACE_TEXT = " - DeepSeek";
  var KIMI_USER_MESSAGE_SELECTOR = '[class*="user"], [class*="User"]';
  var KIMI_ASSISTANT_MESSAGE_SELECTOR = '[class*="assistant"], [class*="Assistant"], [class*="kimi"]';
  var KIMI_TITLE_REPLACE_TEXT = " - Kimi";
  var DEFAULT_CHAT_TITLE = "Conversation";
  function parseChatDOM(platform, doc, config) {
    switch (platform.toLowerCase()) {
      case "chatgpt":
        return extractChatGPTChatData(doc);
      case "claude":
        return extractClaudeChatData(doc);
      case "copilot":
        return extractCopilotChatData(doc);
      case "gemini":
        return extractGeminiChatData(doc, config);
      case "tongyi":
        return extractTongyiChatData(doc);
      case "deepseek":
        return extractDeepSeekChatData(doc);
      case "kimi":
        return extractKimiChatData(doc);
      default:
        return { title: DEFAULT_CHAT_TITLE, messages: [], assets: [] };
    }
  }
  function extractChatGPTChatData(doc) {
    const articles = [...doc.querySelectorAll(CHATGPT_ARTICLE_SELECTOR)];
    if (articles.length === 0) {
      return { title: DEFAULT_CHAT_TITLE, messages: [], assets: [] };
    }
    let title = doc.title.replace(CHATGPT_TITLE_REPLACE_TEXT, "").trim() || DEFAULT_CHAT_TITLE;
    const messages2 = [];
    let chatIndex = 1;
    let model = "";
    const modelButtons = doc.querySelectorAll('button, [role="button"]');
    for (const btn of modelButtons) {
      const text = btn.textContent?.trim() || "";
      const match = text.match(/^(GPT-[0-9.]+[a-z]*|o1(?:-mini|-preview)?|ChatGPT\s*[0-9.]*[a-z]*)$/i);
      if (match) {
        model = match[1];
        break;
      }
    }
    if (!model) {
      const selectors = [
        '[class*="model"]',
        '[class*="Model"]',
        '[data-testid*="model"]',
        ".text-token-text-secondary",
        "select option[selected]"
      ];
      for (const selector of selectors) {
        const elements = doc.querySelectorAll(selector);
        for (const el of elements) {
          const text = el.textContent?.trim() || "";
          const match = text.match(/(GPT-[0-9.]+[a-z]*|o1(?:-mini|-preview)?|ChatGPT\s*[0-9.]*[a-z]*)/i);
          if (match) {
            model = match[1];
            break;
          }
        }
        if (model) break;
      }
    }
    if (!model) {
      const bodyText = doc.body.textContent || "";
      const modelMatch = bodyText.match(/(?:Model|模型)[:\s]*(GPT-[0-9.]+[a-z]*|o1(?:-mini|-preview)?|ChatGPT\s*[0-9.]*[a-z]*)/i);
      if (modelMatch) {
        model = modelMatch[1];
      }
    }
    if (model) {
      model = model.trim();
    }
    for (const article of articles) {
      const header = article.querySelector(CHATGPT_HEADER_SELECTOR)?.textContent?.trim() || "";
      const html = article.innerHTML;
      let markdown = chatHtmlToMarkdown(html);
      if (!markdown.trim()) continue;
      const headerLower = header.toLowerCase();
      const isUser = headerLower.includes("you said") || headerLower.includes("you") || headerLower.includes("\u60A8\u8BF4") || headerLower.includes("\u60A8") || // Also check if the article has user-specific classes or attributes
      article.classList.contains("user") || article.getAttribute("data-message-author-role") === "user" || article.querySelector('[data-message-author-role="user"]') !== null;
      const role = isUser ? "user" : "assistant";
      markdown = markdown.replace(/^您说[：:]\s*/gm, "").replace(/^ChatGPT\s*说[：:]\s*/gm, "").replace(/^You\s+said[：:]\s*/gmi, "").replace(/^ChatGPT\s+said[：:]\s*/gmi, "").replace(/您说[：:]\s*/g, "").replace(/ChatGPT\s*说[：:]\s*/g, "").replace(/You\s+said[：:]\s*/gi, "").replace(/ChatGPT\s+said[：:]\s*/gi, "").trim();
      messages2.push({
        id: `msg-${chatIndex++}`,
        role,
        html,
        md: markdown,
        text: markdown
        // fallback
      });
    }
    return { title, messages: messages2, assets: [], model: model || void 0 };
  }
  function extractClaudeChatData(doc) {
    const mainContainer = doc.querySelector(CLAUDE_MAIN_CONTAINER_SELECTOR);
    if (!mainContainer) {
      return { title: DEFAULT_CHAT_TITLE, messages: [], assets: [] };
    }
    const messages2 = [];
    let chatIndex = 1;
    let title = doc.title.replace(/ - Claude$/, "").trim() || DEFAULT_CHAT_TITLE;
    let model = "";
    const buttons = doc.querySelectorAll("button");
    for (const btn of buttons) {
      const text = btn.textContent?.trim() || "";
      if (text.match(/^(Sonnet|Opus|Haiku)\s+[\d.]+$/i)) {
        model = "Claude " + text;
        break;
      }
    }
    Array.from(mainContainer.children).forEach((child) => {
      const element = child;
      const userMessage = element.querySelector(CLAUDE_USER_MESSAGE_SELECTOR);
      if (userMessage) {
        const html = userMessage.innerHTML;
        const markdown = chatHtmlToMarkdown(html);
        if (markdown.trim()) {
          messages2.push({
            id: `msg-${chatIndex++}`,
            role: "user",
            html,
            md: markdown,
            text: markdown
          });
        }
        return;
      }
      const assistantMessage = element.querySelector(CLAUDE_ASSISTANT_MESSAGE_SELECTOR);
      if (assistantMessage) {
        const markdownContainer = assistantMessage.querySelector(".standard-markdown, .progressive-markdown");
        if (markdownContainer) {
          const html = markdownContainer.innerHTML;
          const markdown = chatHtmlToMarkdown(html);
          if (markdown.trim()) {
            messages2.push({
              id: `msg-${chatIndex++}`,
              role: "assistant",
              html,
              md: markdown,
              text: markdown
            });
          }
        }
        return;
      }
    });
    return { title, messages: messages2, assets: [], model };
  }
  function extractCopilotChatData(doc) {
    const messageItems = [...doc.querySelectorAll(COPILOT_MESSAGE_SELECTOR)];
    if (messageItems.length === 0) {
      return { title: DEFAULT_CHAT_TITLE, messages: [], assets: [] };
    }
    const messages2 = [];
    let chatIndex = 1;
    let rawTitle = "";
    const selected = doc.querySelector('[role="option"][aria-selected="true"]');
    if (selected) {
      rawTitle = selected.querySelector("p")?.textContent?.trim() || (selected.getAttribute("aria-label") || "").split(",").slice(1).join(",").trim();
    }
    if (!rawTitle) {
      rawTitle = (doc.title || "").replace(/^\s*Microsoft[_\s-]*Copilot.*$/i, "").replace(/\s*[-–|]\s*Copilot.*$/i, "").trim();
    }
    if (!rawTitle) rawTitle = "Copilot Conversation";
    for (const item of messageItems) {
      const isUser = item.matches(COPILOT_USER_MESSAGE_SELECTOR);
      const role = isUser ? "user" : "assistant";
      const html = item.innerHTML;
      const markdown = chatHtmlToMarkdown(html);
      if (markdown.trim()) {
        messages2.push({
          id: `msg-${chatIndex++}`,
          role,
          html,
          md: markdown,
          text: markdown
          // fallback
        });
      }
    }
    return { title: rawTitle, messages: messages2, assets: [] };
  }
  function extractCanvasContent(doc) {
    const immersivePanel = doc.querySelector("immersive-panel");
    if (!immersivePanel) return null;
    const extendedPanel = immersivePanel.querySelector("extended-response-panel");
    if (!extendedPanel) return null;
    const immersiveEditor = extendedPanel.querySelector("immersive-editor");
    if (!immersiveEditor) return null;
    const proseMirror = immersiveEditor.querySelector('.ProseMirror[contenteditable="true"]');
    if (!proseMirror) return null;
    let canvasTitle = "";
    const titleElem = extendedPanel.querySelector('h2.title-text, [class*="title-text"]');
    if (titleElem) {
      canvasTitle = titleElem.textContent?.trim() || "";
    }
    const canvasHtml = proseMirror.innerHTML;
    const canvasMarkdown = chatHtmlToMarkdown(canvasHtml);
    if (canvasMarkdown.trim()) {
      let result = "\n\n---\n**[Canvas Content]**\n\n";
      if (canvasTitle) {
        result += `# ${canvasTitle}

`;
      }
      result += canvasMarkdown + "\n\n---\n";
      return result;
    }
    return null;
  }
  function normalizeDeepResearchSpacing(markdown) {
    markdown = markdown.replace(/\n{3,}/g, "\n\n");
    markdown = markdown.replace(/(^|\n)(#{1,6}\s+.+?)\n{3,}/g, "$1$2\n\n");
    markdown = markdown.replace(/\n{3,}(#{1,6}\s+.+?)(\n|$)/g, "\n\n$1$2");
    const lines = markdown.split("\n");
    const result = [];
    let prevLineWasContent = false;
    let blankLineCount = 0;
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmedLine = line.trim();
      if (trimmedLine === "") {
        blankLineCount++;
        continue;
      }
      const isHeading = /^#{1,6}\s/.test(trimmedLine);
      const isListItem = /^[\-\*\+]\s/.test(trimmedLine) || /^\d+\.\s/.test(trimmedLine);
      const isCodeFence = /^```/.test(trimmedLine);
      const isBlockquote = /^>/.test(trimmedLine);
      const isHorizontalRule = /^[\-\*_]{3,}$/.test(trimmedLine);
      const isTableRow = /^\|/.test(trimmedLine);
      let neededBlankLines = 0;
      if (prevLineWasContent) {
        if (isHeading || isCodeFence || isHorizontalRule) {
          neededBlankLines = 1;
        } else if (isListItem || isBlockquote || isTableRow) {
          neededBlankLines = 1;
        } else {
          neededBlankLines = 1;
        }
      }
      for (let j = 0; j < neededBlankLines; j++) {
        result.push("");
      }
      result.push(line);
      prevLineWasContent = true;
      blankLineCount = 0;
    }
    let normalized = result.join("\n");
    normalized = normalized.replace(/^\n+/, "");
    normalized = normalized.replace(/\n*$/, "\n");
    normalized = normalized.replace(/(#{1,6}\s+.+?)\n(#{1,6}\s+)/g, "$1\n\n$2");
    normalized = normalized.replace(/([^\n])\n([^\n#\-\*\+\d>`|])/g, (match, p1, p2) => {
      if (/^[A-Z\u4e00-\u9fa5]/.test(p2)) {
        return p1 + "\n\n" + p2;
      }
      return match;
    });
    return normalized;
  }
  function extractDeepResearchContent(doc, messageElem) {
    const deepResearchWidget = messageElem.querySelector("deep-research-confirmation-widget");
    if (!deepResearchWidget) return null;
    let reportMarkdown = "\n\n---\n**[Deep Research Report]**\n\n";
    const titleElem = messageElem.querySelector('[data-test-id="title"]');
    if (titleElem) {
      const titleText = titleElem.textContent?.trim();
      if (titleText) {
        reportMarkdown += `# ${titleText}

`;
      }
    }
    const researchSteps = messageElem.querySelectorAll(".research-step");
    if (researchSteps.length > 0) {
      reportMarkdown += "## Research Plan\n\n";
      researchSteps.forEach((step, index) => {
        const stepTitle = step.querySelector(".research-step-title")?.textContent?.trim();
        const stepDesc = step.querySelector(".research-step-description")?.textContent?.trim();
        if (stepTitle) {
          reportMarkdown += `### ${index + 1}. ${stepTitle}

`;
        }
        if (stepDesc) {
          reportMarkdown += `${stepDesc}

`;
        }
      });
    }
    const deepResearchPanel = doc.querySelector("deep-research-immersive-panel");
    const citationNumbers = /* @__PURE__ */ new Set();
    if (deepResearchPanel) {
      const reportContent = deepResearchPanel.querySelector("message-content");
      if (reportContent) {
        const allFootnotes = reportContent.querySelectorAll("source-footnote");
        allFootnotes.forEach((footnote) => {
          const sup = footnote.querySelector("sup");
          if (sup) {
            const sourceIndex = sup.getAttribute("data-turn-source-index");
            if (sourceIndex) {
              citationNumbers.add(sourceIndex);
            }
          }
        });
        let contentMarkdown = "";
        for (const child of Array.from(reportContent.childNodes)) {
          contentMarkdown += nodeToMarkdown(child, "");
        }
        contentMarkdown = normalizeDeepResearchSpacing(contentMarkdown);
        if (contentMarkdown.trim().length > 500) {
          reportMarkdown += "## Full Report\n\n" + contentMarkdown + "\n\n";
        }
      }
    }
    if (citationNumbers.size > 0) {
      const sortedCitations = Array.from(citationNumbers).sort((a, b) => Number(a) - Number(b));
      reportMarkdown += "\n---\n\n";
      reportMarkdown += "## \u{1F4DA} Citations\n\n";
      reportMarkdown += `This report references **${sortedCitations.length} sources**: ${sortedCitations.map((n) => `[${n}]`).join(", ")}

`;
      reportMarkdown += "> **Note**: Citation URLs are not available in the exported version. To view the full source details:\n";
      reportMarkdown += "> 1. Visit the [original Deep Research page in Gemini](https://gemini.google.com)\n";
      reportMarkdown += "> 2. Click on the citation numbers in the report\n";
      reportMarkdown += "> 3. Copy the URLs and add them to this document if needed\n\n";
    }
    reportMarkdown += "---\n";
    return reportMarkdown;
  }
  function extractGeminiChatData(doc, config) {
    const deepResearchConfig = config?.deepResearch || {};
    const pureMode = deepResearchConfig.pureMode || false;
    if (pureMode) {
      const deepResearchPanel = doc.querySelector("deep-research-immersive-panel");
      if (deepResearchPanel) {
        const modelResponses = doc.querySelectorAll("model-response");
        for (const modelResponse of modelResponses) {
          const widget = modelResponse.querySelector("deep-research-confirmation-widget");
          if (widget) {
            const report = extractDeepResearchContent(doc, modelResponse);
            if (report) {
              return {
                title: "Deep Research Report",
                messages: [{
                  id: "deep-research-report",
                  role: "assistant",
                  md: report,
                  text: report
                }],
                assets: []
              };
            }
          }
        }
      }
      return { title: DEFAULT_CHAT_TITLE, messages: [], assets: [] };
    }
    const messageItems = [...doc.querySelectorAll(GEMINI_MESSAGE_ITEM_SELECTOR)];
    if (messageItems.length === 0) {
      return { title: DEFAULT_CHAT_TITLE, messages: [], assets: [] };
    }
    let title = DEFAULT_CHAT_TITLE;
    const sidebarActiveChatItem = doc.querySelector(GEMINI_SIDEBAR_ACTIVE_CHAT_SELECTOR);
    if (sidebarActiveChatItem && sidebarActiveChatItem.textContent?.trim()) {
      title = sidebarActiveChatItem.textContent.trim();
    } else {
      title = doc.title;
    }
    if (title.startsWith(GEMINI_TITLE_REPLACE_TEXT)) {
      title = title.replace(GEMINI_TITLE_REPLACE_TEXT, "").trim();
    }
    let model = "";
    const modeSwitcher = doc.querySelector("bard-mode-switcher");
    if (modeSwitcher) {
      model = modeSwitcher.textContent?.trim() || "";
    }
    if (!model) {
      const buttons = doc.querySelectorAll("button");
      for (const btn of buttons) {
        const text = btn.textContent?.trim() || "";
        if (text.match(/^(Gemini )?(2\.5|2\.0|1\.5)\s*(Pro|Flash|Advanced)/i)) {
          model = text;
          break;
        }
      }
    }
    const messages2 = [];
    let chatIndex = 1;
    const allImages = doc.querySelectorAll("img");
    console.log(`[Gemini] Found ${allImages.length} img elements in light DOM`);
    allImages.forEach((img, index) => {
      const src = img.getAttribute("src") || "";
      const dataSrc = img.getAttribute("data-src") || "";
      const alt = img.getAttribute("alt") || "";
      const isBlobUrl = src.startsWith("blob:");
      console.log(`[Gemini] Image ${index + 1}: src="${src.substring(0, 100)}" ${isBlobUrl ? "(BLOB URL - will be skipped)" : ""}, data-src="${dataSrc.substring(0, 100)}", alt="${alt}"`);
    });
    let shadowImageCount = 0;
    const allElements = doc.querySelectorAll("*");
    allElements.forEach((elem) => {
      if (elem.shadowRoot) {
        const shadowImages = elem.shadowRoot.querySelectorAll("img");
        if (shadowImages.length > 0) {
          console.log(`[Gemini] Found ${shadowImages.length} images in Shadow DOM of <${elem.tagName.toLowerCase()}>`);
          shadowImages.forEach((img, index) => {
            const src = img.getAttribute("src") || "";
            console.log(`[Gemini] Shadow Image ${index + 1}: src="${src.substring(0, 100)}"`);
            shadowImageCount++;
          });
        }
      }
    });
    if (shadowImageCount > 0) {
      console.log(`[Gemini] Total images in Shadow DOM: ${shadowImageCount}`);
      console.log(`[Gemini] Note: Shadow DOM images may not be captured by the current implementation`);
    }
    const customImageElements = doc.querySelectorAll('image-query, uploaded-image, [class*="image-container"], [class*="uploaded-image"]');
    console.log(`[Gemini] Found ${customImageElements.length} custom image elements`);
    customImageElements.forEach((elem, index) => {
      console.log(`[Gemini] Custom image ${index + 1}: tagName="${elem.tagName}", classes="${elem.className}"`);
      if (elem.shadowRoot) {
        console.log(`[Gemini]   -> Has Shadow DOM`);
      }
    });
    const canvasContent = extractCanvasContent(doc);
    for (const item of messageItems) {
      let role = "assistant";
      let messageContentElem = null;
      const tagName = item.tagName.toLowerCase();
      if (tagName === "user-query") {
        role = "user";
        messageContentElem = item;
      } else if (tagName === "model-response") {
        role = "assistant";
        messageContentElem = item;
      }
      if (messageContentElem) {
        const blobImages = messageContentElem.querySelectorAll('img[src^="blob:"]');
        if (blobImages.length > 0) {
          console.log(`[Gemini] Found ${blobImages.length} blob URL images, converting to base64...`);
          blobImages.forEach((img, index) => {
            const imgElement = img;
            const base64 = convertBlobImageToBase64(imgElement);
            if (base64) {
              console.log(`[Gemini] Converted blob image ${index + 1} to base64 (${Math.round(base64.length * 0.75 / 1024)} KB)`);
              imgElement.src = base64;
              if (imgElement.hasAttribute("srcset")) {
                imgElement.removeAttribute("srcset");
              }
            } else {
              console.log(`[Gemini] Failed to convert blob image ${index + 1}`);
            }
          });
        }
        const html = messageContentElem.innerHTML;
        let markdown = chatHtmlToMarkdown(html);
        const hasCanvasChip = messageContentElem.querySelector("immersive-entry-chip");
        if (hasCanvasChip && canvasContent) {
          markdown += canvasContent;
        }
        const deepResearchContent = extractDeepResearchContent(doc, messageContentElem);
        if (deepResearchContent) {
          markdown += deepResearchContent;
        }
        if (markdown.trim()) {
          messages2.push({
            id: `msg-${chatIndex++}`,
            role,
            html,
            md: markdown,
            text: markdown
            // fallback
          });
        }
      }
    }
    return { title, messages: messages2, assets: [], model };
  }
  function extractTongyiChatData(doc) {
    const questionItems = doc.querySelectorAll('[class*="questionItem"]');
    const answerItems = doc.querySelectorAll('[class*="answerItem"]');
    console.log(`[Tongyi] Found ${questionItems.length} questions and ${answerItems.length} answers`);
    if (questionItems.length === 0 && answerItems.length === 0) {
      return { title: DEFAULT_CHAT_TITLE, messages: [], assets: [] };
    }
    let title = doc.title.replace(TONGYI_TITLE_REPLACE_TEXT, "").replace(" - \u4F60\u7684\u8D85\u7EA7\u4E2A\u4EBA\u52A9\u7406", "").replace(" - \u901A\u4E49\u5343\u95EE", "").trim();
    if (!title || title === "\u901A\u4E49") {
      if (questionItems.length > 0) {
        const firstQuestion = questionItems[0].textContent?.trim() || "";
        title = firstQuestion.substring(0, 50) + (firstQuestion.length > 50 ? "..." : "");
      } else {
        title = "\u901A\u4E49\u5343\u95EE\u5BF9\u8BDD";
      }
    }
    let model = "";
    try {
      const selectedModel = localStorage.getItem("selectedQwenModel");
      if (selectedModel) {
        const match = selectedModel.match(/qwen(\d+)[\s-]*(max|plus|turbo|pro)?/i);
        if (match) {
          const version = match[1];
          const variant = match[2] ? match[2].charAt(0).toUpperCase() + match[2].slice(1).toLowerCase() : "";
          model = `Qwen${version}${variant ? "-" + variant : ""}`;
        }
      }
    } catch (e) {
    }
    if (!model) {
      const bodyText = doc.body.textContent || "";
      const qwenMatch = bodyText.match(/Qwen[\s-]?(\d+)[\s-]*(max|plus|turbo|pro)?/i);
      if (qwenMatch) {
        const version = qwenMatch[1];
        const variant = qwenMatch[2] ? qwenMatch[2].charAt(0).toUpperCase() + qwenMatch[2].slice(1).toLowerCase() : "";
        model = `Qwen${version}${variant ? "-" + variant : ""}`;
      }
    }
    if (!model) {
      const buttons = doc.querySelectorAll('button, [role="button"]');
      for (const btn of buttons) {
        const text = btn.textContent?.trim() || "";
        if (text.match(/^(通义千问|Qwen|qwen)[\s-]*(\d+)?[\s-]*(max|plus|turbo)?$/i)) {
          model = text;
          break;
        }
      }
    }
    if (!model) {
      const modelElements = doc.querySelectorAll('[class*="model"], [class*="Model"]');
      for (const el of modelElements) {
        const text = el.textContent?.trim() || "";
        if (text.match(/(通义千问|Qwen|qwen)[\s-]*(\d+)?[\s-]*(max|plus|turbo)?/i)) {
          model = text;
          break;
        }
      }
    }
    if (!model) {
      model = "\u901A\u4E49\u5343\u95EE";
    }
    const messages2 = [];
    const allMessages = [];
    questionItems.forEach((item, index) => {
      allMessages.push({
        element: item,
        role: "user",
        index: index * 2
        // Even indices for questions
      });
    });
    answerItems.forEach((item, index) => {
      allMessages.push({
        element: item,
        role: "assistant",
        index: index * 2 + 1
        // Odd indices for answers
      });
    });
    allMessages.sort((a, b) => a.index - b.index);
    console.log(`[Tongyi] Processing ${allMessages.length} messages`);
    let chatIndex = 1;
    for (const { element, role } of allMessages) {
      const html = element.innerHTML;
      let markdown = chatHtmlToMarkdown(html);
      if (role === "assistant") {
        markdown = markdown.replace(/^ASSISTANT\s*/i, "").trim();
      }
      markdown = markdown.replace(/!\[\]\(https:\/\/img\.alicdn\.com\/imgextra\/[^)]+\)\s*/g, "").trim();
      const text = element.textContent?.trim() || "";
      if (text && markdown) {
        messages2.push({
          id: `msg-${chatIndex++}`,
          role,
          html,
          md: markdown,
          text: markdown
        });
        console.log(`[Tongyi] Added ${role} message: ${text.substring(0, 50)}...`);
      }
    }
    console.log(`[Tongyi] Total messages extracted: ${messages2.length}`);
    return { title, messages: messages2, assets: [], model };
  }
  function extractDeepSeekChatData(doc) {
    const messageItems = doc.querySelectorAll('.ds-message, [class*="ds-message"]');
    console.log(`[DeepSeek] Found ${messageItems.length} messages`);
    if (messageItems.length === 0) {
      return { title: DEFAULT_CHAT_TITLE, messages: [], assets: [] };
    }
    const messages2 = [];
    let title = doc.title.replace(DEEPSEEK_TITLE_REPLACE_TEXT, "").replace(" - DeepSeek Chat", "").replace("DeepSeek - ", "").trim() || DEFAULT_CHAT_TITLE;
    let model = "";
    try {
      const keys = Object.keys(localStorage);
      for (const key of keys) {
        if (key.includes("model") || key.includes("deepseek")) {
          const value = localStorage.getItem(key);
          if (value) {
            const modelMatch = value.match(/deepseek[\s-]*(chat|coder|v[0-9]+|r1)?/i);
            if (modelMatch) {
              model = "DeepSeek-" + (modelMatch[1] || "Chat");
              break;
            }
          }
        }
      }
    } catch (e) {
    }
    if (!model) {
      const bodyText = doc.body.textContent || "";
      const deepseekMatch = bodyText.match(/DeepSeek[\s-]*(Chat|Coder|V[0-9]+|R1)?/i);
      if (deepseekMatch) {
        model = deepseekMatch[0];
      }
    }
    if (!model) {
      const buttons = doc.querySelectorAll('button, [role="button"]');
      for (const btn of buttons) {
        const text = btn.textContent?.trim() || "";
        if (text.match(/^(DeepSeek|deepseek)[\s-]*(chat|coder|v[0-9]+|r1)?$/i)) {
          model = text;
          break;
        }
      }
    }
    if (!model) {
      model = "DeepSeek";
    }
    let chatIndex = 1;
    messageItems.forEach((item, index) => {
      const element = item;
      const role = index % 2 === 0 ? "user" : "assistant";
      const html = element.innerHTML;
      let markdown = chatHtmlToMarkdown(html);
      if (role === "assistant") {
        markdown = markdown.replace(/^(DeepSeek|ASSISTANT)\s*/i, "").trim();
      }
      const text = element.textContent?.trim() || "";
      if (text && markdown) {
        messages2.push({
          id: `msg-${chatIndex++}`,
          role,
          html,
          md: markdown,
          text: markdown
        });
        console.log(`[DeepSeek] Added ${role} message: ${text.substring(0, 50)}...`);
      }
    });
    console.log(`[DeepSeek] Total messages extracted: ${messages2.length}`);
    return { title, messages: messages2, assets: [], model };
  }
  function extractKimiChatData(doc) {
    let messageItems = [];
    const possibleSelectors = [
      '[class*="message-item"]',
      '[class*="messageItem"]',
      '[class*="chat-message"]',
      '[class*="chatMessage"]',
      '[class*="Message"]',
      '[data-role="user"], [data-role="assistant"]',
      '[data-type="user"], [data-type="assistant"]',
      "article"
    ];
    for (const selector of possibleSelectors) {
      messageItems = [...doc.querySelectorAll(selector)];
      if (messageItems.length > 0) break;
    }
    if (messageItems.length === 0) {
      return { title: DEFAULT_CHAT_TITLE, messages: [], assets: [] };
    }
    const messages2 = [];
    let chatIndex = 1;
    let title = doc.title.replace(KIMI_TITLE_REPLACE_TEXT, "").replace(" - Kimi Chat", "").replace("Kimi - ", "").trim() || DEFAULT_CHAT_TITLE;
    let model = "";
    const buttons = doc.querySelectorAll('button, [role="button"]');
    for (const btn of buttons) {
      const text = btn.textContent?.trim() || "";
      if (text.match(/^(Kimi|moonshot|kimi)[\s-]*(k2|k1|plus)?$/i)) {
        model = text;
        break;
      }
    }
    if (!model) {
      const modelElements = doc.querySelectorAll('[class*="model"], [class*="Model"]');
      for (const el of modelElements) {
        const text = el.textContent?.trim() || "";
        if (text.match(/(Kimi|moonshot|kimi)[\s-]*(k2|k1|plus)?/i)) {
          model = text;
          break;
        }
      }
    }
    for (const item of messageItems) {
      const element = item;
      let role = "assistant";
      const dataRole = element.getAttribute("data-role");
      const dataType = element.getAttribute("data-type");
      const className = element.className || "";
      if (dataRole === "user" || dataType === "user" || className.includes("user") || className.includes("User")) {
        role = "user";
      } else if (dataRole === "assistant" || dataType === "assistant" || className.includes("assistant") || className.includes("Assistant") || className.includes("kimi") || className.includes("Kimi")) {
        role = "assistant";
      } else {
        const userIndicator = element.querySelector(KIMI_USER_MESSAGE_SELECTOR);
        const assistantIndicator = element.querySelector(KIMI_ASSISTANT_MESSAGE_SELECTOR);
        if (userIndicator) {
          role = "user";
        } else if (assistantIndicator) {
          role = "assistant";
        }
      }
      const html = element.innerHTML;
      const markdown = chatHtmlToMarkdown(html);
      if (markdown.trim()) {
        messages2.push({
          id: `msg-${chatIndex++}`,
          role,
          html,
          md: markdown,
          text: markdown
        });
      }
    }
    return { title, messages: messages2, assets: [], model };
  }
  var headingLevelOffset = 0;
  function convertBlobImageToBase64(imgElement) {
    try {
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      if (!ctx) return null;
      canvas.width = imgElement.naturalWidth || imgElement.width;
      canvas.height = imgElement.naturalHeight || imgElement.height;
      if (canvas.width === 0 || canvas.height === 0) {
        console.log("[Image] Image has no dimensions, skipping blob conversion");
        return null;
      }
      ctx.drawImage(imgElement, 0, 0);
      const base64 = canvas.toDataURL("image/jpeg", 0.8);
      const sizeKB = Math.round(base64.length * 0.75 / 1024);
      console.log(`[Image] Converted blob URL to base64 (${sizeKB} KB)`);
      return base64;
    } catch (e) {
      console.error("[Image] Failed to convert blob URL to base64:", e);
      return null;
    }
  }
  function nodeToMarkdown(node, indent = "") {
    if (node.nodeType === Node.TEXT_NODE) {
      return node.textContent || "";
    }
    if (node.nodeType === Node.ELEMENT_NODE) {
      const elem = node;
      const tagName = elem.tagName.toLowerCase();
      if (tagName === "source-footnote") {
        const sup = elem.querySelector("sup");
        if (sup) {
          let number = sup.textContent?.trim();
          if (!number) {
            const sourceIndex = sup.getAttribute("data-turn-source-index");
            if (sourceIndex) {
              number = sourceIndex;
            }
          }
          if (number) {
            return `[${number}]`;
          }
        }
        return "";
      }
      if (elem.classList.contains("katex") || elem.classList.contains("math-inline")) {
        const annotation = elem.querySelector('annotation[encoding="application/x-tex"]');
        if (annotation && annotation.textContent) {
          return `$${annotation.textContent}$`;
        }
        const mathml = elem.querySelector("math");
        if (mathml && mathml.textContent) {
          return mathml.textContent.trim();
        }
        const katexHtml = elem.querySelector(".katex-html");
        if (katexHtml) {
          let result = "";
          const bases = katexHtml.querySelectorAll(".base");
          bases.forEach((base) => {
            for (const child of Array.from(base.children)) {
              const childElem = child;
              const className = childElem.className || "";
              if (className.includes("strut")) continue;
              if (className.includes("mord") || className.includes("mbin")) {
                const msupsub = childElem.querySelector(".msupsub");
                if (msupsub) {
                  const baseText = Array.from(childElem.childNodes).filter((n) => n.nodeType === Node.TEXT_NODE || n.nodeType === Node.ELEMENT_NODE && !n.classList.contains("msupsub")).map((n) => n.textContent).join("");
                  const mtight = msupsub.querySelector(".mtight");
                  const supText = mtight?.textContent || "";
                  const superscriptMap = {
                    "0": "\u2070",
                    "1": "\xB9",
                    "2": "\xB2",
                    "3": "\xB3",
                    "4": "\u2074",
                    "5": "\u2075",
                    "6": "\u2076",
                    "7": "\u2077",
                    "8": "\u2078",
                    "9": "\u2079",
                    "-": "\u207B",
                    "+": "\u207A"
                  };
                  const unicodeSup = supText.split("").map((c) => superscriptMap[c] || c).join("");
                  result += baseText + unicodeSup;
                } else {
                  result += childElem.textContent || "";
                }
              } else if (className.includes("mspace")) {
                result += " ";
              }
            }
          });
          return result.trim();
        }
        const text = elem.textContent?.trim();
        if (text) {
          return text;
        }
      }
      if (tagName === "pre") {
        const table = elem.querySelector("table");
        if (table) {
          return nodeToMarkdown(table, indent);
        }
        const code = elem.querySelector("code");
        if (code) {
          const cleanCode = code.textContent || "";
          return "\n```\n" + cleanCode + "\n```\n";
        }
        return "\n```\n" + (elem.textContent || "") + "\n```\n";
      }
      if (tagName === "code") {
        return "`" + (elem.textContent || "") + "`";
      }
      if (tagName === "strong" || tagName === "b") {
        const content = processChildren(elem, indent);
        const prevSibling = elem.previousSibling;
        const nextSibling = elem.nextSibling;
        const needSpaceBefore = prevSibling && prevSibling.nodeType === Node.TEXT_NODE && prevSibling.textContent && /\S$/.test(prevSibling.textContent);
        const needSpaceAfter = nextSibling && nextSibling.nodeType === Node.TEXT_NODE && nextSibling.textContent && /^\S/.test(nextSibling.textContent);
        return (needSpaceBefore ? " " : "") + "**" + content + "**" + (needSpaceAfter ? " " : "");
      }
      if (tagName === "em" || tagName === "i") {
        const content = processChildren(elem, indent);
        const prevSibling = elem.previousSibling;
        const nextSibling = elem.nextSibling;
        const needSpaceBefore = prevSibling && prevSibling.nodeType === Node.TEXT_NODE && prevSibling.textContent && /\S$/.test(prevSibling.textContent);
        const needSpaceAfter = nextSibling && nextSibling.nodeType === Node.TEXT_NODE && nextSibling.textContent && /^\S/.test(nextSibling.textContent);
        return (needSpaceBefore ? " " : "") + "*" + content + "*" + (needSpaceAfter ? " " : "");
      }
      if (tagName === "a") {
        const href = elem.getAttribute("href") || "";
        const text = processChildren(elem, indent);
        return `[${text}](${href})`;
      }
      if (tagName === "img") {
        let src = elem.getAttribute("src") || "";
        const alt = elem.getAttribute("alt") || "";
        if (src.startsWith("blob:")) {
          console.log("[Image] Warning: Found unconverted blob URL during markdown conversion");
          console.log("[Image] This should have been converted earlier. Adding placeholder.");
          return `
> \u26A0\uFE0F **[User uploaded image - not available]**
> Gemini uses temporary blob URLs for uploaded images. The image could not be converted.

`;
        }
        if (!src) {
          src = elem.getAttribute("data-src") || elem.getAttribute("data-original-src") || elem.getAttribute("data-image-url") || elem.getAttribute("data-url") || "";
          if (!src) {
            console.log("[Image] Skipping image with empty URL");
            return "";
          }
        }
        if (src.startsWith("data:image/")) {
          console.log("[Image] Including base64 image in markdown");
        }
        return `![${alt}](${src})`;
      }
      if (tagName === "image-query" || tagName === "uploaded-image" || elem.classList.contains("uploaded-image") || elem.classList.contains("image-container")) {
        const imgElement = elem.querySelector("img");
        if (imgElement) {
          let src = imgElement.getAttribute("src") || imgElement.getAttribute("data-src") || imgElement.getAttribute("data-original-src") || "";
          const alt = imgElement.getAttribute("alt") || "Image";
          if (src && !src.startsWith("blob:")) {
            return `![${alt}](${src})`;
          }
        }
        let imageUrl = elem.getAttribute("data-image-url") || elem.getAttribute("data-src") || elem.getAttribute("data-url") || elem.getAttribute("src") || "";
        if (imageUrl && !imageUrl.startsWith("blob:")) {
          return `![Image](${imageUrl})`;
        }
        console.log("[Image] Skipping custom image element with no valid URL");
        return "";
      }
      if (tagName.match(/^h[1-6]$/)) {
        const level = parseInt(tagName[1]);
        const adjustedLevel = Math.max(2, Math.min(level + headingLevelOffset, 6));
        return "\n" + "#".repeat(adjustedLevel) + " " + processChildren(elem, indent) + "\n\n";
      }
      if (tagName === "p") {
        const content = processChildren(elem, indent);
        return content + "\n\n";
      }
      if (tagName === "br") {
        return "\n";
      }
      if (tagName === "blockquote") {
        const content = processChildren(elem, indent);
        const lines = content.split("\n");
        while (lines.length > 0 && lines[lines.length - 1].trim() === "") {
          lines.pop();
        }
        return lines.map((line) => "> " + line).join("\n") + "\n\n";
      }
      if (tagName === "table") {
        return processTable(elem);
      }
      if (tagName === "ol") {
        const startAttr = elem.getAttribute("start");
        const startNum = startAttr ? parseInt(startAttr, 10) : 1;
        const items = Array.from(elem.children).filter((child) => child.tagName.toLowerCase() === "li");
        const hasNestedLists = items.some(
          (li) => li.querySelector("ul, ol") !== null
        );
        const isTopLevel = indent === "";
        let result = "\n";
        items.forEach((li, index) => {
          const itemNumber = startNum + index;
          const itemContent = processListItem(li, indent + "   ", itemNumber);
          result += itemContent;
          if ((isTopLevel || hasNestedLists) && index < items.length - 1) {
            result += "\n";
          }
        });
        return result;
      }
      if (tagName === "ul") {
        const items = Array.from(elem.children).filter((child) => child.tagName.toLowerCase() === "li");
        const hasNestedLists = items.some(
          (li) => li.querySelector("ul, ol") !== null
        );
        const isTopLevel = indent === "";
        let result = "\n";
        items.forEach((li, index) => {
          const itemContent = processListItem(li, indent + "  ");
          result += itemContent;
          if ((isTopLevel || hasNestedLists) && index < items.length - 1) {
            result += "\n";
          }
        });
        return result;
      }
      if (tagName === "li") {
        return processChildren(elem, indent);
      }
      if (tagName === "div" || tagName === "span") {
        return processChildren(elem, indent);
      }
      return processChildren(elem, indent);
    }
    return "";
  }
  function processChildren(elem, indent = "") {
    let result = "";
    for (const child of Array.from(elem.childNodes)) {
      result += nodeToMarkdown(child, indent);
    }
    return result;
  }
  function processTable(table) {
    const rows = [];
    let hasHeader = false;
    const thead = table.querySelector("thead");
    if (thead) {
      hasHeader = true;
      const headerRows = thead.querySelectorAll("tr");
      headerRows.forEach((tr) => {
        const cells = [];
        tr.querySelectorAll("th, td").forEach((cell) => {
          const cellContent = getCellContent(cell);
          cells.push(cellContent);
        });
        if (cells.length > 0) {
          rows.push(cells);
        }
      });
    }
    const tbody = table.querySelector("tbody");
    if (tbody) {
      const bodyRows = tbody.querySelectorAll("tr");
      bodyRows.forEach((tr) => {
        const cells = [];
        tr.querySelectorAll("td, th").forEach((cell) => {
          const cellContent = getCellContent(cell);
          cells.push(cellContent);
        });
        if (cells.length > 0) {
          rows.push(cells);
        }
      });
    }
    if (!hasHeader && rows.length > 0) {
      hasHeader = true;
    }
    if (rows.length === 0) {
      return "";
    }
    let result = "\n";
    if (hasHeader && rows.length > 0) {
      const headerRow = rows[0];
      result += "| " + headerRow.join(" | ") + " |\n";
      result += "| " + headerRow.map(() => "---").join(" | ") + " |\n";
      for (let i = 1; i < rows.length; i++) {
        result += "| " + rows[i].join(" | ") + " |\n";
      }
    } else {
      rows.forEach((row) => {
        result += "| " + row.join(" | ") + " |\n";
      });
    }
    result += "\n";
    return result;
  }
  function getCellContent(cell) {
    let content = "";
    for (const child of Array.from(cell.childNodes)) {
      if (child.nodeType === Node.TEXT_NODE) {
        content += child.textContent || "";
      } else if (child.nodeType === Node.ELEMENT_NODE) {
        const elem = child;
        const tagName = elem.tagName.toLowerCase();
        if (elem.classList.contains("katex") || elem.classList.contains("math-inline")) {
          content += nodeToMarkdown(elem, "");
        } else if (tagName === "strong" || tagName === "b") {
          const hasKatex = elem.querySelector(".katex, .math-inline");
          if (hasKatex) {
            content += "**";
            for (const grandChild of Array.from(elem.childNodes)) {
              if (grandChild.nodeType === Node.TEXT_NODE) {
                content += grandChild.textContent || "";
              } else if (grandChild.nodeType === Node.ELEMENT_NODE) {
                const grandElem = grandChild;
                if (grandElem.classList.contains("katex") || grandElem.classList.contains("math-inline")) {
                  content += nodeToMarkdown(grandElem, "");
                } else {
                  content += grandElem.textContent || "";
                }
              }
            }
            content += "**";
          } else {
            content += "**" + (elem.textContent || "") + "**";
          }
        } else if (tagName === "em" || tagName === "i") {
          content += "*" + (elem.textContent || "") + "*";
        } else if (tagName === "code") {
          content += "`" + (elem.textContent || "") + "`";
        } else if (tagName === "a") {
          const href = elem.getAttribute("href") || "";
          const text = elem.textContent || "";
          content += `[${text}](${href})`;
        } else if (tagName === "br") {
          content += " ";
        } else {
          content += elem.textContent || "";
        }
      }
    }
    content = content.trim();
    content = content.replace(/\n+/g, " ");
    content = content.replace(/\s+/g, " ");
    return content;
  }
  function processListItem(li, indent, itemNumber) {
    let result = "";
    const children = Array.from(li.childNodes);
    let inlineContent = "";
    let blockElements2 = [];
    for (const child of children) {
      if (child.nodeType === Node.TEXT_NODE) {
        inlineContent += child.textContent || "";
      } else if (child.nodeType === Node.ELEMENT_NODE) {
        const elem = child;
        const tagName = elem.tagName.toLowerCase();
        if (tagName === "ul" || tagName === "ol") {
          blockElements2.push(child);
        } else if (tagName === "p") {
          const boldChild = elem.querySelector("b, strong");
          if (boldChild && boldChild.textContent?.trim() === elem.textContent?.trim()) {
            inlineContent += processChildren(elem, indent).trim();
          } else {
            inlineContent += processChildren(elem, indent).trim();
          }
        } else {
          inlineContent += nodeToMarkdown(child, indent);
        }
      }
    }
    const trimmedInline = inlineContent.trim();
    if (trimmedInline) {
      const marker = itemNumber !== void 0 ? `${itemNumber}. ` : "- ";
      const baseIndent = itemNumber !== void 0 ? indent.slice(0, -3) : indent.slice(0, -2);
      result += baseIndent + marker + trimmedInline + "\n";
    }
    for (const blockElem of blockElements2) {
      if (trimmedInline) {
        result += "\n";
      }
      const blockContent = nodeToMarkdown(blockElem, indent);
      result += blockContent;
    }
    return result;
  }
  function cleanupUIElements(container) {
    const selectorsToRemove = [
      // Thinking/reasoning UI elements (Claude, etc.)
      ".thoughts-header-button-content",
      '[class*="thoughts-header-button"]',
      '[class*="thinking-header-button"]',
      ".mat-mdc-button-ripple",
      '[class*="button-ripple"]',
      // Generic UI elements
      "button",
      ".button",
      '[role="button"]',
      // Navigation and controls
      "nav",
      ".navigation",
      ".controls",
      // Tooltips and overlays
      ".tooltip",
      ".overlay",
      ".popup",
      // Hidden elements
      "[hidden]",
      '[style*="display: none"]',
      '[style*="display:none"]',
      // Aria-hidden elements (usually decorative)
      '[aria-hidden="true"]',
      // ChatGPT retry indicators (e.g., "2/2")
      ".tabular-nums",
      '[class*="tabular-nums"]',
      // Gemini Deep Research: source icons and carousel elements
      "sources-carousel",
      "sources-carousel-inline",
      "card-renderer",
      "default-source-card",
      "url-source-card"
    ];
    selectorsToRemove.forEach((selector) => {
      try {
        const elements = container.querySelectorAll(selector);
        elements.forEach((el) => el.remove());
      } catch (e) {
      }
    });
    const textPatternsToRemove = [
      /^导出到\s*Google\s*表格$/i,
      /^Export to\s*Google\s*Sheets$/i,
      /^复制$/i,
      /^Copy$/i,
      /^下载$/i,
      /^Download$/i,
      /^显示思路$/i,
      /^Show\s*thinking$/i,
      /^隐藏思路$/i,
      /^Hide\s*thinking$/i,
      /^思考过程$/i,
      /^Thinking$/i,
      // ChatGPT specific headers
      /^您说[：:]\s*$/i,
      /^ChatGPT\s*说[：:]\s*$/i,
      /^You\s+said[：:]\s*$/i,
      /^ChatGPT\s+said[：:]\s*$/i,
      // Retry indicators (e.g., "2/2", "1/3", etc.)
      /^\d+\/\d+$/
    ];
    const allElements = Array.from(container.querySelectorAll("*"));
    allElements.forEach((el) => {
      if (el.tagName.toLowerCase() === "table" || el.querySelector("table")) {
        return;
      }
      const text = el.textContent?.trim() || "";
      if (textPatternsToRemove.some((pattern) => pattern.test(text))) {
        if (el.children.length === 0 || text.length < 50) {
          el.remove();
        }
      }
    });
    const tables = container.querySelectorAll("table");
    tables.forEach((table) => {
      let nextSibling = table.nextElementSibling;
      while (nextSibling) {
        const text = nextSibling.textContent?.trim() || "";
        const isFooter = nextSibling.classList.contains("table-footer") || /导出|export|复制|copy|下载|download/i.test(text);
        if (isFooter && text.length < 100) {
          const toRemove = nextSibling;
          nextSibling = nextSibling.nextElementSibling;
          toRemove.remove();
        } else {
          break;
        }
      }
    });
  }
  function chatHtmlToMarkdown(html) {
    if (!html) return "";
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = html;
    cleanupUIElements(tempDiv);
    const headings = tempDiv.querySelectorAll("h1, h2, h3, h4, h5, h6");
    let minHeadingLevel = 7;
    headings.forEach((h) => {
      const level = parseInt(h.tagName[1]);
      if (level < minHeadingLevel) {
        minHeadingLevel = level;
      }
    });
    if (minHeadingLevel <= 6) {
      headingLevelOffset = 2 - minHeadingLevel;
    } else {
      headingLevelOffset = 0;
    }
    let markdown = processChildren(tempDiv);
    markdown = markdown.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, " ");
    markdown = markdown.replace(/\n\s*\n\s*\n/g, "\n\n").replace(/^\s+|\s+$/g, "");
    return markdown;
  }

  // src/content/adapters/chat.ts
  function detectPlatform(url) {
    if (/chatgpt/.test(url)) return "chatgpt";
    if (/claude/.test(url)) return "claude";
    if (/gemini/.test(url)) return "gemini";
    if (/copilot/.test(url)) return "copilot";
    if (/tongyi/.test(url)) return "tongyi";
    if (/deepseek/.test(url)) return "deepseek";
    if (/kimi|moonshot/.test(url)) return "kimi";
    if (/perplexity/.test(url)) return "perplexity";
    return "chat";
  }
  async function extractAIChat(doc, url) {
    const platform = detectPlatform(url);
    const { options } = await chrome.storage.sync.get("options");
    const parseConfig = {
      deepResearch: {
        pureMode: options?.deepResearch?.pureMode || false
      }
    };
    const { title, messages: messages2, assets, model, createdAt } = parseChatDOM(platform, doc, parseConfig);
    const aiChatOptions = {
      includeTimestamps: options?.aiChat?.includeTimestamps ?? false,
      userName: options?.aiChat?.userName || "USER"
    };
    const normalizedMessages = messages2.map((m, i) => ({
      id: m.id || `m${i}`,
      role: m.role,
      text: m.md || (m.html ? chatHtmlToMarkdown(m.html) : m.text || ""),
      timestamp: m.timestamp
    }));
    const markdown = buildChatMarkdown({
      title,
      platform,
      url,
      messages: normalizedMessages,
      model,
      createdAt,
      options: aiChatOptions
    });
    return {
      type: "ai_chat",
      title,
      markdown,
      assets,
      meta: {
        url,
        platform,
        model,
        messageCount: normalizedMessages.length,
        ...createdAt ? { createdAt } : {},
        // Only include if actually captured
        clippedAtISO: (/* @__PURE__ */ new Date()).toISOString()
      }
    };
  }

  // node_modules/turndown/lib/turndown.browser.es.js
  function extend(destination) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (source.hasOwnProperty(key)) destination[key] = source[key];
      }
    }
    return destination;
  }
  function repeat(character, count) {
    return Array(count + 1).join(character);
  }
  function trimLeadingNewlines(string) {
    return string.replace(/^\n*/, "");
  }
  function trimTrailingNewlines(string) {
    var indexEnd = string.length;
    while (indexEnd > 0 && string[indexEnd - 1] === "\n") indexEnd--;
    return string.substring(0, indexEnd);
  }
  var blockElements = [
    "ADDRESS",
    "ARTICLE",
    "ASIDE",
    "AUDIO",
    "BLOCKQUOTE",
    "BODY",
    "CANVAS",
    "CENTER",
    "DD",
    "DIR",
    "DIV",
    "DL",
    "DT",
    "FIELDSET",
    "FIGCAPTION",
    "FIGURE",
    "FOOTER",
    "FORM",
    "FRAMESET",
    "H1",
    "H2",
    "H3",
    "H4",
    "H5",
    "H6",
    "HEADER",
    "HGROUP",
    "HR",
    "HTML",
    "ISINDEX",
    "LI",
    "MAIN",
    "MENU",
    "NAV",
    "NOFRAMES",
    "NOSCRIPT",
    "OL",
    "OUTPUT",
    "P",
    "PRE",
    "SECTION",
    "TABLE",
    "TBODY",
    "TD",
    "TFOOT",
    "TH",
    "THEAD",
    "TR",
    "UL"
  ];
  function isBlock(node) {
    return is(node, blockElements);
  }
  var voidElements = [
    "AREA",
    "BASE",
    "BR",
    "COL",
    "COMMAND",
    "EMBED",
    "HR",
    "IMG",
    "INPUT",
    "KEYGEN",
    "LINK",
    "META",
    "PARAM",
    "SOURCE",
    "TRACK",
    "WBR"
  ];
  function isVoid(node) {
    return is(node, voidElements);
  }
  function hasVoid(node) {
    return has(node, voidElements);
  }
  var meaningfulWhenBlankElements = [
    "A",
    "TABLE",
    "THEAD",
    "TBODY",
    "TFOOT",
    "TH",
    "TD",
    "IFRAME",
    "SCRIPT",
    "AUDIO",
    "VIDEO"
  ];
  function isMeaningfulWhenBlank(node) {
    return is(node, meaningfulWhenBlankElements);
  }
  function hasMeaningfulWhenBlank(node) {
    return has(node, meaningfulWhenBlankElements);
  }
  function is(node, tagNames) {
    return tagNames.indexOf(node.nodeName) >= 0;
  }
  function has(node, tagNames) {
    return node.getElementsByTagName && tagNames.some(function(tagName) {
      return node.getElementsByTagName(tagName).length;
    });
  }
  var rules = {};
  rules.paragraph = {
    filter: "p",
    replacement: function(content) {
      return "\n\n" + content + "\n\n";
    }
  };
  rules.lineBreak = {
    filter: "br",
    replacement: function(content, node, options) {
      return options.br + "\n";
    }
  };
  rules.heading = {
    filter: ["h1", "h2", "h3", "h4", "h5", "h6"],
    replacement: function(content, node, options) {
      var hLevel = Number(node.nodeName.charAt(1));
      if (options.headingStyle === "setext" && hLevel < 3) {
        var underline = repeat(hLevel === 1 ? "=" : "-", content.length);
        return "\n\n" + content + "\n" + underline + "\n\n";
      } else {
        return "\n\n" + repeat("#", hLevel) + " " + content + "\n\n";
      }
    }
  };
  rules.blockquote = {
    filter: "blockquote",
    replacement: function(content) {
      content = content.replace(/^\n+|\n+$/g, "");
      content = content.replace(/^/gm, "> ");
      return "\n\n" + content + "\n\n";
    }
  };
  rules.list = {
    filter: ["ul", "ol"],
    replacement: function(content, node) {
      var parent = node.parentNode;
      if (parent.nodeName === "LI" && parent.lastElementChild === node) {
        return "\n" + content;
      } else {
        return "\n\n" + content + "\n\n";
      }
    }
  };
  rules.listItem = {
    filter: "li",
    replacement: function(content, node, options) {
      var prefix = options.bulletListMarker + "   ";
      var parent = node.parentNode;
      if (parent.nodeName === "OL") {
        var start = parent.getAttribute("start");
        var index = Array.prototype.indexOf.call(parent.children, node);
        prefix = (start ? Number(start) + index : index + 1) + ".  ";
      }
      content = content.replace(/^\n+/, "").replace(/\n+$/, "\n").replace(/\n/gm, "\n" + " ".repeat(prefix.length));
      return prefix + content + (node.nextSibling && !/\n$/.test(content) ? "\n" : "");
    }
  };
  rules.indentedCodeBlock = {
    filter: function(node, options) {
      return options.codeBlockStyle === "indented" && node.nodeName === "PRE" && node.firstChild && node.firstChild.nodeName === "CODE";
    },
    replacement: function(content, node, options) {
      return "\n\n    " + node.firstChild.textContent.replace(/\n/g, "\n    ") + "\n\n";
    }
  };
  rules.fencedCodeBlock = {
    filter: function(node, options) {
      return options.codeBlockStyle === "fenced" && node.nodeName === "PRE" && node.firstChild && node.firstChild.nodeName === "CODE";
    },
    replacement: function(content, node, options) {
      var className = node.firstChild.getAttribute("class") || "";
      var language = (className.match(/language-(\S+)/) || [null, ""])[1];
      var code = node.firstChild.textContent;
      var fenceChar = options.fence.charAt(0);
      var fenceSize = 3;
      var fenceInCodeRegex = new RegExp("^" + fenceChar + "{3,}", "gm");
      var match;
      while (match = fenceInCodeRegex.exec(code)) {
        if (match[0].length >= fenceSize) {
          fenceSize = match[0].length + 1;
        }
      }
      var fence = repeat(fenceChar, fenceSize);
      return "\n\n" + fence + language + "\n" + code.replace(/\n$/, "") + "\n" + fence + "\n\n";
    }
  };
  rules.horizontalRule = {
    filter: "hr",
    replacement: function(content, node, options) {
      return "\n\n" + options.hr + "\n\n";
    }
  };
  rules.inlineLink = {
    filter: function(node, options) {
      return options.linkStyle === "inlined" && node.nodeName === "A" && node.getAttribute("href");
    },
    replacement: function(content, node) {
      var href = node.getAttribute("href");
      if (href) href = href.replace(/([()])/g, "\\$1");
      var title = cleanAttribute(node.getAttribute("title"));
      if (title) title = ' "' + title.replace(/"/g, '\\"') + '"';
      return "[" + content + "](" + href + title + ")";
    }
  };
  rules.referenceLink = {
    filter: function(node, options) {
      return options.linkStyle === "referenced" && node.nodeName === "A" && node.getAttribute("href");
    },
    replacement: function(content, node, options) {
      var href = node.getAttribute("href");
      var title = cleanAttribute(node.getAttribute("title"));
      if (title) title = ' "' + title + '"';
      var replacement;
      var reference;
      switch (options.linkReferenceStyle) {
        case "collapsed":
          replacement = "[" + content + "][]";
          reference = "[" + content + "]: " + href + title;
          break;
        case "shortcut":
          replacement = "[" + content + "]";
          reference = "[" + content + "]: " + href + title;
          break;
        default:
          var id = this.references.length + 1;
          replacement = "[" + content + "][" + id + "]";
          reference = "[" + id + "]: " + href + title;
      }
      this.references.push(reference);
      return replacement;
    },
    references: [],
    append: function(options) {
      var references = "";
      if (this.references.length) {
        references = "\n\n" + this.references.join("\n") + "\n\n";
        this.references = [];
      }
      return references;
    }
  };
  rules.emphasis = {
    filter: ["em", "i"],
    replacement: function(content, node, options) {
      if (!content.trim()) return "";
      return options.emDelimiter + content + options.emDelimiter;
    }
  };
  rules.strong = {
    filter: ["strong", "b"],
    replacement: function(content, node, options) {
      if (!content.trim()) return "";
      return options.strongDelimiter + content + options.strongDelimiter;
    }
  };
  rules.code = {
    filter: function(node) {
      var hasSiblings = node.previousSibling || node.nextSibling;
      var isCodeBlock = node.parentNode.nodeName === "PRE" && !hasSiblings;
      return node.nodeName === "CODE" && !isCodeBlock;
    },
    replacement: function(content) {
      if (!content) return "";
      content = content.replace(/\r?\n|\r/g, " ");
      var extraSpace = /^`|^ .*?[^ ].* $|`$/.test(content) ? " " : "";
      var delimiter = "`";
      var matches = content.match(/`+/gm) || [];
      while (matches.indexOf(delimiter) !== -1) delimiter = delimiter + "`";
      return delimiter + extraSpace + content + extraSpace + delimiter;
    }
  };
  rules.image = {
    filter: "img",
    replacement: function(content, node) {
      var alt = cleanAttribute(node.getAttribute("alt"));
      var src = node.getAttribute("src") || "";
      var title = cleanAttribute(node.getAttribute("title"));
      var titlePart = title ? ' "' + title + '"' : "";
      return src ? "![" + alt + "](" + src + titlePart + ")" : "";
    }
  };
  function cleanAttribute(attribute) {
    return attribute ? attribute.replace(/(\n+\s*)+/g, "\n") : "";
  }
  function Rules(options) {
    this.options = options;
    this._keep = [];
    this._remove = [];
    this.blankRule = {
      replacement: options.blankReplacement
    };
    this.keepReplacement = options.keepReplacement;
    this.defaultRule = {
      replacement: options.defaultReplacement
    };
    this.array = [];
    for (var key in options.rules) this.array.push(options.rules[key]);
  }
  Rules.prototype = {
    add: function(key, rule) {
      this.array.unshift(rule);
    },
    keep: function(filter) {
      this._keep.unshift({
        filter,
        replacement: this.keepReplacement
      });
    },
    remove: function(filter) {
      this._remove.unshift({
        filter,
        replacement: function() {
          return "";
        }
      });
    },
    forNode: function(node) {
      if (node.isBlank) return this.blankRule;
      var rule;
      if (rule = findRule(this.array, node, this.options)) return rule;
      if (rule = findRule(this._keep, node, this.options)) return rule;
      if (rule = findRule(this._remove, node, this.options)) return rule;
      return this.defaultRule;
    },
    forEach: function(fn) {
      for (var i = 0; i < this.array.length; i++) fn(this.array[i], i);
    }
  };
  function findRule(rules2, node, options) {
    for (var i = 0; i < rules2.length; i++) {
      var rule = rules2[i];
      if (filterValue(rule, node, options)) return rule;
    }
    return void 0;
  }
  function filterValue(rule, node, options) {
    var filter = rule.filter;
    if (typeof filter === "string") {
      if (filter === node.nodeName.toLowerCase()) return true;
    } else if (Array.isArray(filter)) {
      if (filter.indexOf(node.nodeName.toLowerCase()) > -1) return true;
    } else if (typeof filter === "function") {
      if (filter.call(rule, node, options)) return true;
    } else {
      throw new TypeError("`filter` needs to be a string, array, or function");
    }
  }
  function collapseWhitespace(options) {
    var element = options.element;
    var isBlock2 = options.isBlock;
    var isVoid2 = options.isVoid;
    var isPre = options.isPre || function(node2) {
      return node2.nodeName === "PRE";
    };
    if (!element.firstChild || isPre(element)) return;
    var prevText = null;
    var keepLeadingWs = false;
    var prev = null;
    var node = next(prev, element, isPre);
    while (node !== element) {
      if (node.nodeType === 3 || node.nodeType === 4) {
        var text = node.data.replace(/[ \r\n\t]+/g, " ");
        if ((!prevText || / $/.test(prevText.data)) && !keepLeadingWs && text[0] === " ") {
          text = text.substr(1);
        }
        if (!text) {
          node = remove(node);
          continue;
        }
        node.data = text;
        prevText = node;
      } else if (node.nodeType === 1) {
        if (isBlock2(node) || node.nodeName === "BR") {
          if (prevText) {
            prevText.data = prevText.data.replace(/ $/, "");
          }
          prevText = null;
          keepLeadingWs = false;
        } else if (isVoid2(node) || isPre(node)) {
          prevText = null;
          keepLeadingWs = true;
        } else if (prevText) {
          keepLeadingWs = false;
        }
      } else {
        node = remove(node);
        continue;
      }
      var nextNode = next(prev, node, isPre);
      prev = node;
      node = nextNode;
    }
    if (prevText) {
      prevText.data = prevText.data.replace(/ $/, "");
      if (!prevText.data) {
        remove(prevText);
      }
    }
  }
  function remove(node) {
    var next2 = node.nextSibling || node.parentNode;
    node.parentNode.removeChild(node);
    return next2;
  }
  function next(prev, current, isPre) {
    if (prev && prev.parentNode === current || isPre(current)) {
      return current.nextSibling || current.parentNode;
    }
    return current.firstChild || current.nextSibling || current.parentNode;
  }
  var root = typeof window !== "undefined" ? window : {};
  function canParseHTMLNatively() {
    var Parser = root.DOMParser;
    var canParse = false;
    try {
      if (new Parser().parseFromString("", "text/html")) {
        canParse = true;
      }
    } catch (e) {
    }
    return canParse;
  }
  function createHTMLParser() {
    var Parser = function() {
    };
    {
      if (shouldUseActiveX()) {
        Parser.prototype.parseFromString = function(string) {
          var doc = new window.ActiveXObject("htmlfile");
          doc.designMode = "on";
          doc.open();
          doc.write(string);
          doc.close();
          return doc;
        };
      } else {
        Parser.prototype.parseFromString = function(string) {
          var doc = document.implementation.createHTMLDocument("");
          doc.open();
          doc.write(string);
          doc.close();
          return doc;
        };
      }
    }
    return Parser;
  }
  function shouldUseActiveX() {
    var useActiveX = false;
    try {
      document.implementation.createHTMLDocument("").open();
    } catch (e) {
      if (root.ActiveXObject) useActiveX = true;
    }
    return useActiveX;
  }
  var HTMLParser = canParseHTMLNatively() ? root.DOMParser : createHTMLParser();
  function RootNode(input, options) {
    var root2;
    if (typeof input === "string") {
      var doc = htmlParser().parseFromString(
        // DOM parsers arrange elements in the <head> and <body>.
        // Wrapping in a custom element ensures elements are reliably arranged in
        // a single element.
        '<x-turndown id="turndown-root">' + input + "</x-turndown>",
        "text/html"
      );
      root2 = doc.getElementById("turndown-root");
    } else {
      root2 = input.cloneNode(true);
    }
    collapseWhitespace({
      element: root2,
      isBlock,
      isVoid,
      isPre: options.preformattedCode ? isPreOrCode : null
    });
    return root2;
  }
  var _htmlParser;
  function htmlParser() {
    _htmlParser = _htmlParser || new HTMLParser();
    return _htmlParser;
  }
  function isPreOrCode(node) {
    return node.nodeName === "PRE" || node.nodeName === "CODE";
  }
  function Node2(node, options) {
    node.isBlock = isBlock(node);
    node.isCode = node.nodeName === "CODE" || node.parentNode.isCode;
    node.isBlank = isBlank(node);
    node.flankingWhitespace = flankingWhitespace(node, options);
    return node;
  }
  function isBlank(node) {
    return !isVoid(node) && !isMeaningfulWhenBlank(node) && /^\s*$/i.test(node.textContent) && !hasVoid(node) && !hasMeaningfulWhenBlank(node);
  }
  function flankingWhitespace(node, options) {
    if (node.isBlock || options.preformattedCode && node.isCode) {
      return { leading: "", trailing: "" };
    }
    var edges = edgeWhitespace(node.textContent);
    if (edges.leadingAscii && isFlankedByWhitespace("left", node, options)) {
      edges.leading = edges.leadingNonAscii;
    }
    if (edges.trailingAscii && isFlankedByWhitespace("right", node, options)) {
      edges.trailing = edges.trailingNonAscii;
    }
    return { leading: edges.leading, trailing: edges.trailing };
  }
  function edgeWhitespace(string) {
    var m = string.match(/^(([ \t\r\n]*)(\s*))(?:(?=\S)[\s\S]*\S)?((\s*?)([ \t\r\n]*))$/);
    return {
      leading: m[1],
      // whole string for whitespace-only strings
      leadingAscii: m[2],
      leadingNonAscii: m[3],
      trailing: m[4],
      // empty for whitespace-only strings
      trailingNonAscii: m[5],
      trailingAscii: m[6]
    };
  }
  function isFlankedByWhitespace(side, node, options) {
    var sibling;
    var regExp;
    var isFlanked;
    if (side === "left") {
      sibling = node.previousSibling;
      regExp = / $/;
    } else {
      sibling = node.nextSibling;
      regExp = /^ /;
    }
    if (sibling) {
      if (sibling.nodeType === 3) {
        isFlanked = regExp.test(sibling.nodeValue);
      } else if (options.preformattedCode && sibling.nodeName === "CODE") {
        isFlanked = false;
      } else if (sibling.nodeType === 1 && !isBlock(sibling)) {
        isFlanked = regExp.test(sibling.textContent);
      }
    }
    return isFlanked;
  }
  var reduce = Array.prototype.reduce;
  var escapes = [
    [/\\/g, "\\\\"],
    [/\*/g, "\\*"],
    [/^-/g, "\\-"],
    [/^\+ /g, "\\+ "],
    [/^(=+)/g, "\\$1"],
    [/^(#{1,6}) /g, "\\$1 "],
    [/`/g, "\\`"],
    [/^~~~/g, "\\~~~"],
    [/\[/g, "\\["],
    [/\]/g, "\\]"],
    [/^>/g, "\\>"],
    [/_/g, "\\_"],
    [/^(\d+)\. /g, "$1\\. "]
  ];
  function TurndownService(options) {
    if (!(this instanceof TurndownService)) return new TurndownService(options);
    var defaults = {
      rules,
      headingStyle: "setext",
      hr: "* * *",
      bulletListMarker: "*",
      codeBlockStyle: "indented",
      fence: "```",
      emDelimiter: "_",
      strongDelimiter: "**",
      linkStyle: "inlined",
      linkReferenceStyle: "full",
      br: "  ",
      preformattedCode: false,
      blankReplacement: function(content, node) {
        return node.isBlock ? "\n\n" : "";
      },
      keepReplacement: function(content, node) {
        return node.isBlock ? "\n\n" + node.outerHTML + "\n\n" : node.outerHTML;
      },
      defaultReplacement: function(content, node) {
        return node.isBlock ? "\n\n" + content + "\n\n" : content;
      }
    };
    this.options = extend({}, defaults, options);
    this.rules = new Rules(this.options);
  }
  TurndownService.prototype = {
    /**
     * The entry point for converting a string or DOM node to Markdown
     * @public
     * @param {String|HTMLElement} input The string or DOM node to convert
     * @returns A Markdown representation of the input
     * @type String
     */
    turndown: function(input) {
      if (!canConvert(input)) {
        throw new TypeError(
          input + " is not a string, or an element/document/fragment node."
        );
      }
      if (input === "") return "";
      var output = process.call(this, new RootNode(input, this.options));
      return postProcess.call(this, output);
    },
    /**
     * Add one or more plugins
     * @public
     * @param {Function|Array} plugin The plugin or array of plugins to add
     * @returns The Turndown instance for chaining
     * @type Object
     */
    use: function(plugin) {
      if (Array.isArray(plugin)) {
        for (var i = 0; i < plugin.length; i++) this.use(plugin[i]);
      } else if (typeof plugin === "function") {
        plugin(this);
      } else {
        throw new TypeError("plugin must be a Function or an Array of Functions");
      }
      return this;
    },
    /**
     * Adds a rule
     * @public
     * @param {String} key The unique key of the rule
     * @param {Object} rule The rule
     * @returns The Turndown instance for chaining
     * @type Object
     */
    addRule: function(key, rule) {
      this.rules.add(key, rule);
      return this;
    },
    /**
     * Keep a node (as HTML) that matches the filter
     * @public
     * @param {String|Array|Function} filter The unique key of the rule
     * @returns The Turndown instance for chaining
     * @type Object
     */
    keep: function(filter) {
      this.rules.keep(filter);
      return this;
    },
    /**
     * Remove a node that matches the filter
     * @public
     * @param {String|Array|Function} filter The unique key of the rule
     * @returns The Turndown instance for chaining
     * @type Object
     */
    remove: function(filter) {
      this.rules.remove(filter);
      return this;
    },
    /**
     * Escapes Markdown syntax
     * @public
     * @param {String} string The string to escape
     * @returns A string with Markdown syntax escaped
     * @type String
     */
    escape: function(string) {
      return escapes.reduce(function(accumulator, escape) {
        return accumulator.replace(escape[0], escape[1]);
      }, string);
    }
  };
  function process(parentNode) {
    var self = this;
    return reduce.call(parentNode.childNodes, function(output, node) {
      node = new Node2(node, self.options);
      var replacement = "";
      if (node.nodeType === 3) {
        replacement = node.isCode ? node.nodeValue : self.escape(node.nodeValue);
      } else if (node.nodeType === 1) {
        replacement = replacementForNode.call(self, node);
      }
      return join(output, replacement);
    }, "");
  }
  function postProcess(output) {
    var self = this;
    this.rules.forEach(function(rule) {
      if (typeof rule.append === "function") {
        output = join(output, rule.append(self.options));
      }
    });
    return output.replace(/^[\t\r\n]+/, "").replace(/[\t\r\n\s]+$/, "");
  }
  function replacementForNode(node) {
    var rule = this.rules.forNode(node);
    var content = process.call(this, node);
    var whitespace = node.flankingWhitespace;
    if (whitespace.leading || whitespace.trailing) content = content.trim();
    return whitespace.leading + rule.replacement(content, node, this.options) + whitespace.trailing;
  }
  function join(output, replacement) {
    var s1 = trimTrailingNewlines(output);
    var s2 = trimLeadingNewlines(replacement);
    var nls = Math.max(output.length - s1.length, replacement.length - s2.length);
    var separator = "\n\n".substring(0, nls);
    return s1 + separator + s2;
  }
  function canConvert(input) {
    return input != null && (typeof input === "string" || input.nodeType && (input.nodeType === 1 || input.nodeType === 9 || input.nodeType === 11));
  }
  var turndown_browser_es_default = TurndownService;

  // src/content/adapters/article.ts
  var import_readability = __toESM(require_readability(), 1);

  // src/third_party/obsidian-clipper/markdownRules.ts
  function applyObsidianRules(turndownService) {
    turndownService.addRule("highlight", {
      filter: "mark",
      replacement: function(content) {
        return "==" + content + "==";
      }
    });
    turndownService.addRule("strikethrough", {
      filter: (node) => node.nodeName === "DEL" || node.nodeName === "S" || node.nodeName === "STRIKE",
      replacement: function(content) {
        return "~~" + content + "~~";
      }
    });
    turndownService.addRule("taskListItem", {
      filter: "li",
      replacement: function(content, node, options) {
        if (!(node instanceof HTMLElement)) return content;
        const isTaskListItem = node.classList.contains("task-list-item");
        const checkbox = node.querySelector('input[type="checkbox"]');
        let taskListMarker = "";
        if (isTaskListItem && checkbox) {
          content = content.replace(/<input[^>]*>/, "");
          taskListMarker = checkbox.checked ? "[x] " : "[ ] ";
        }
        content = content.replace(/\n+$/, "").split("\n").filter((line) => line.length > 0).join("\n	");
        let prefix = options.bulletListMarker + " ";
        let parent = node.parentNode;
        let level = 0;
        let currentParent = node.parentNode;
        while (currentParent && (currentParent.nodeName === "UL" || currentParent.nodeName === "OL")) {
          level++;
          currentParent = currentParent.parentNode;
        }
        const indentLevel = Math.max(0, level - 1);
        prefix = "	".repeat(indentLevel) + prefix;
        if (parent instanceof HTMLOListElement) {
          let start = parent.getAttribute("start");
          let index = Array.from(parent.children).indexOf(node) + 1;
          prefix = "	".repeat(level - 1) + (start ? Number(start) + index - 1 : index) + ". ";
        }
        return prefix + taskListMarker + content.trim() + (node.nextSibling && !/\n$/.test(content) ? "\n" : "");
      }
    });
    turndownService.addRule("table", {
      filter: "table",
      replacement: function(content, node) {
        if (!(node instanceof HTMLTableElement)) return content;
        const hasComplexStructure = Array.from(node.querySelectorAll("td, th")).some(
          (cell) => cell.hasAttribute("colspan") || cell.hasAttribute("rowspan")
        );
        if (hasComplexStructure) {
          return "\n\n" + cleanupTableHTML(node) + "\n\n";
        }
        const rows = Array.from(node.rows).map((row) => {
          const cells = Array.from(row.cells).map((cell) => {
            let cellContent = turndownService.turndown(cell.innerHTML).replace(/\n/g, " ").trim();
            cellContent = cellContent.replace(/\|/g, "\\|");
            return cellContent;
          });
          return `| ${cells.join(" | ")} |`;
        });
        const separatorRow = `| ${Array(rows[0].split("|").length - 2).fill("---").join(" | ")} |`;
        const tableContent = [rows[0], separatorRow, ...rows.slice(1)].join("\n");
        return `

${tableContent}

`;
      }
    });
    turndownService.addRule("math", {
      filter: (node) => {
        return node.nodeName.toLowerCase() === "math" || node instanceof Element && node.classList && (node.classList.contains("mwe-math-element") || node.classList.contains("mwe-math-fallback-image-inline") || node.classList.contains("mwe-math-fallback-image-display"));
      },
      replacement: (content, node) => {
        if (!(node instanceof Element)) return content;
        let latex = extractLatex(node);
        latex = latex.trim();
        if (!latex) return content;
        const isDisplayMath = node.classList.contains("mwe-math-fallback-image-display") || node instanceof HTMLElement && node.style.display === "block";
        if (isDisplayMath) {
          return `

$$
${latex}
$$

`;
        } else {
          const prevNode = node.previousSibling;
          const nextNode = node.nextSibling;
          const prevChar = prevNode?.textContent?.slice(-1) || "";
          const nextChar = nextNode?.textContent?.[0] || "";
          const isStartOfLine = !prevNode || prevNode.nodeType === Node.TEXT_NODE && prevNode.textContent?.trim() === "";
          const isEndOfLine = !nextNode || nextNode.nodeType === Node.TEXT_NODE && nextNode.textContent?.trim() === "";
          const leftSpace = !isStartOfLine && prevChar && !/[\s$]/.test(prevChar) ? " " : "";
          const rightSpace = !isEndOfLine && nextChar && !/[\s$]/.test(nextChar) ? " " : "";
          return `${leftSpace}$${latex}$${rightSpace}`;
        }
      }
    });
    turndownService.addRule("callout", {
      filter: (node) => {
        return node.nodeName.toLowerCase() === "div" && node.classList.contains("markdown-alert");
      },
      replacement: (content, node) => {
        const element = node;
        const alertClasses = Array.from(element.classList);
        const typeClass = alertClasses.find((c) => c.startsWith("markdown-alert-") && c !== "markdown-alert");
        const type = typeClass ? typeClass.replace("markdown-alert-", "").toUpperCase() : "NOTE";
        const titleElement = element.querySelector(".markdown-alert-title");
        const contentElement = element.querySelector("p:not(.markdown-alert-title)");
        let alertContent = content;
        if (titleElement && titleElement.textContent) {
          alertContent = contentElement?.textContent || content.replace(titleElement.textContent, "");
        }
        return `
> [!${type}]
> ${alertContent.trim().replace(/\n/g, "\n> ")}
`;
      }
    });
    turndownService.addRule("embedToMarkdown", {
      filter: function(node) {
        if (node instanceof HTMLIFrameElement) {
          const src = node.getAttribute("src");
          return !!src && (!!src.match(/(?:youtube\.com|youtu\.be)/) || !!src.match(/(?:twitter\.com|x\.com)/));
        }
        return false;
      },
      replacement: function(content, node) {
        if (node instanceof HTMLIFrameElement) {
          const src = node.getAttribute("src");
          if (src) {
            const youtubeMatch = src.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com|youtu\.be)\/(?:embed\/|watch\?v=)?([a-zA-Z0-9_-]+)/);
            if (youtubeMatch) {
              return `[YouTube Video](https://www.youtube.com/watch?v=${youtubeMatch[1]})`;
            }
            const twitterMatch = src.match(/(?:twitter\.com|x\.com)/);
            if (twitterMatch) {
              return `[Twitter/X Embed](${src})`;
            }
          }
        }
        return content;
      }
    });
    turndownService.remove(["style", "script", "button"]);
    turndownService.keep(["iframe", "video", "audio", "sup", "sub", "svg"]);
  }
  function cleanupTableHTML(table) {
    const allowedAttributes = ["src", "href", "style", "align", "width", "height", "rowspan", "colspan", "bgcolor", "scope", "valign", "headers"];
    const cleanElement = (element) => {
      Array.from(element.attributes).forEach((attr) => {
        if (!allowedAttributes.includes(attr.name)) {
          element.removeAttribute(attr.name);
        }
      });
      element.childNodes.forEach((child) => {
        if (child instanceof Element) {
          cleanElement(child);
        }
      });
    };
    const tableClone = table.cloneNode(true);
    cleanElement(tableClone);
    return tableClone.outerHTML;
  }
  function extractLatex(element) {
    if (element.nodeName.toLowerCase() === "math") {
      let latex = element.getAttribute("data-latex");
      let alttext = element.getAttribute("alttext");
      if (latex) {
        return latex.trim();
      } else if (alttext) {
        return alttext.trim();
      }
    }
    const mathElement = element.querySelector("math[alttext]");
    if (mathElement) {
      const alttext = mathElement.getAttribute("alttext");
      if (alttext) {
        return alttext.trim();
      }
    }
    const annotation = element.querySelector('annotation[encoding="application/x-tex"]');
    if (annotation?.textContent) {
      return annotation.textContent.trim();
    }
    const imgNode = element.querySelector("img");
    return imgNode?.getAttribute("alt") || "";
  }

  // src/third_party/obsidian-clipper/domPrep.ts
  function preprocessDocument(doc, baseUrl) {
    doc.querySelectorAll("script, style, noscript").forEach((n) => n.remove());
    makeUrlsAbsolute(doc, baseUrl);
    return doc;
  }
  function makeUrlsAbsolute(doc, baseUrl) {
    const base = new URL(baseUrl);
    doc.querySelectorAll("[src]").forEach((el) => {
      const element = el;
      const src = element.getAttribute("src");
      if (src) {
        try {
          const absoluteUrl = new URL(src, base).toString();
          element.setAttribute("src", absoluteUrl);
        } catch (error) {
          console.warn("Invalid src URL:", src, error);
        }
      }
    });
    doc.querySelectorAll("[href]").forEach((el) => {
      const element = el;
      const href = element.getAttribute("href");
      if (href && !href.startsWith("#") && !href.startsWith("mailto:") && !href.startsWith("tel:")) {
        try {
          const absoluteUrl = new URL(href, base).toString();
          element.setAttribute("href", absoluteUrl);
        } catch (error) {
          console.warn("Invalid href URL:", href, error);
        }
      }
    });
    doc.querySelectorAll("[srcset]").forEach((el) => {
      const element = el;
      const srcset = element.getAttribute("srcset");
      if (srcset) {
        try {
          const absoluteSrcset = srcset.split(",").map((src) => {
            const parts = src.trim().split(/\s+/);
            if (parts.length >= 1) {
              const url = parts[0];
              const descriptor = parts.slice(1).join(" ");
              const absoluteUrl = new URL(url, base).toString();
              return descriptor ? `${absoluteUrl} ${descriptor}` : absoluteUrl;
            }
            return src;
          }).join(", ");
          element.setAttribute("srcset", absoluteSrcset);
        } catch (error) {
          console.warn("Invalid srcset URL:", srcset, error);
        }
      }
    });
    doc.querySelectorAll("[data-src]").forEach((el) => {
      const element = el;
      const dataSrc = element.getAttribute("data-src");
      if (dataSrc) {
        try {
          const absoluteUrl = new URL(dataSrc, base).toString();
          element.setAttribute("data-src", absoluteUrl);
        } catch (error) {
          console.warn("Invalid data-src URL:", dataSrc, error);
        }
      }
    });
  }

  // src/content/adapters/article.ts
  async function extractArticle(doc, url) {
    const cloned = preprocessDocument(doc.cloneNode(true), url);
    const rd = new import_readability.Readability(cloned).parse();
    const turndown = new turndown_browser_es_default({ codeBlockStyle: "fenced" });
    applyObsidianRules(turndown);
    turndown.addRule("imageExternalOnly", {
      filter: "img",
      replacement: (_content, node) => {
        const src = node.getAttribute("src");
        if (!src) return "";
        const abs = new URL(src, url).toString();
        const alt = (node.getAttribute("alt") || "").replace(/\|/g, "-");
        return `![${alt}](${abs})`;
      }
    });
    const bodyMd = turndown.turndown(rd?.content || doc.body.innerHTML);
    const title = (rd?.title || doc.title || new URL(url).hostname).trim();
    const fm = `---
type: article
title: "${esc(title)}"
url: "${url}"
clipped_at: "${(/* @__PURE__ */ new Date()).toISOString()}"
tags: [clipping]
---`;
    return {
      type: "article",
      title,
      markdown: `${fm}

${bodyMd}
`,
      meta: { url, domain: new URL(url).hostname, clippedAtISO: (/* @__PURE__ */ new Date()).toISOString() }
    };
  }
  var esc = (s) => s.replace(/"/g, '\\"');

  // src/content/adapters/clipper.ts
  function generateTextFragmentUrl(baseUrl, selectedText) {
    const paragraphs = selectedText.split(/\n\s*\n/).map((p) => p.trim()).filter((p) => p.length > 0);
    let textToUse = "";
    for (const para of paragraphs) {
      const cleaned = para.replace(/\s+/g, " ").trim();
      if (cleaned.length >= 20) {
        textToUse = cleaned;
        break;
      }
    }
    if (!textToUse) {
      textToUse = selectedText.replace(/\s+/g, " ").trim();
    }
    if (textToUse.length > 300) {
      textToUse = textToUse.substring(0, 300);
    }
    const encodedText = encodeURIComponent(textToUse);
    return `${baseUrl}#:~:text=${encodedText}`;
  }
  function generateClipperTitle(pageTitle, now) {
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, "0");
    const dd = String(now.getDate()).padStart(2, "0");
    const hh = String(now.getHours()).padStart(2, "0");
    const min = String(now.getMinutes()).padStart(2, "0");
    const ss = String(now.getSeconds()).padStart(2, "0");
    return `${pageTitle} ${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}`;
  }
  function formatDateTime(date) {
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, "0");
    const dd = String(date.getDate()).padStart(2, "0");
    const hh = String(date.getHours()).padStart(2, "0");
    const min = String(date.getMinutes()).padStart(2, "0");
    const ss = String(date.getSeconds()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}`;
  }
  async function extractClipperContent(doc, url, selectedHtml, selectedText, userComment) {
    const turndown = new turndown_browser_es_default({ codeBlockStyle: "fenced" });
    applyObsidianRules(turndown);
    turndown.addRule("imageExternalOnly", {
      filter: "img",
      replacement: (_content, node) => {
        const src = node.getAttribute("src");
        if (!src) return "";
        const abs = new URL(src, url).toString();
        const alt = (node.getAttribute("alt") || "").replace(/\|/g, "-");
        return `![${alt}](${abs})`;
      }
    });
    const contentMd = turndown.turndown(selectedHtml);
    const fragmentUrl = generateTextFragmentUrl(url, selectedText);
    const pageTitle = doc.title || new URL(url).hostname;
    const now = /* @__PURE__ */ new Date();
    const clipTitle = generateClipperTitle(pageTitle, now);
    const clippedAt = formatDateTime(now);
    let markdown = `---
type: clipper
title: "${esc2(pageTitle)}"
url: "${fragmentUrl}"
clipped_at: "${clippedAt}"
tags: [clipping, fragment]
---

${contentMd}
`;
    if (userComment && userComment.trim()) {
      markdown += `
---

## \u{1F4AD} \u6211\u7684\u8BC4\u8BBA

${userComment.trim()}
`;
    }
    return {
      type: "clipper",
      title: clipTitle,
      // Use unique title for filename
      pageTitle,
      // Keep original page title
      markdown,
      meta: {
        url,
        fragmentUrl,
        domain: new URL(url).hostname,
        clippedAtISO: now.toISOString(),
        hasComment: !!userComment,
        selectedTextPreview: selectedText.substring(0, 100)
      }
    };
  }
  var esc2 = (s) => s.replace(/"/g, '\\"');

  // src/i18n/locales.ts
  var messages = {
    "zh-CN": {
      // General
      extensionName: "All in Obsidian",
      extensionSubtitle: "\u914D\u7F6E\u4F60\u7684\u526A\u85CF\u63D2\u4EF6\uFF0C\u8BA9\u5185\u5BB9\u7BA1\u7406\u66F4\u667A\u80FD",
      // Settings page sections
      settingsTitle: "\u8BBE\u7F6E",
      languageSettings: "\u8BED\u8A00\u8BBE\u7F6E",
      languageLabel: "\u754C\u9762\u8BED\u8A00",
      languageHint: "\u{1F4A1} \u9009\u62E9\u4F60\u559C\u6B22\u7684\u754C\u9762\u8BED\u8A00",
      // API Configuration
      apiConfigTitle: "Obsidian Local REST API",
      apiConfigHint: "\u{1F4A1} \u914D\u7F6E HTTPS \u548C HTTP \u4E24\u4E2A URL\uFF0C\u6269\u5C55\u4F1A\u667A\u80FD\u9009\u62E9\u53EF\u7528\u7684\u8FDE\u63A5\u65B9\u5F0F",
      httpsUrlLabel: "HTTPS URL",
      httpsUrlHint: "\u901A\u5E38\u7AEF\u53E3\u4E3A 27124\uFF0C\u9002\u7528\u4E8E\u5B89\u5168\u8FDE\u63A5",
      httpUrlLabel: "HTTP URL",
      httpUrlHint: "\u901A\u5E38\u7AEF\u53E3\u4E3A 27123\uFF0C\u4F5C\u4E3A\u5907\u7528\u8FDE\u63A5",
      vaultNameLabel: "Vault \u540D\u79F0",
      vaultNamePlaceholder: "YourVault",
      vaultNameHint: "\u4F60\u7684 Obsidian \u4ED3\u5E93\u540D\u79F0",
      apiKeyLabel: "API Key",
      apiKeyPlaceholder: "\u4F60\u7684 API \u5BC6\u94A5",
      apiKeyHint: "\u5728 Obsidian Local REST API \u63D2\u4EF6\u8BBE\u7F6E\u4E2D\u83B7\u53D6",
      // Template Configuration
      templateConfigTitle: "\u8DEF\u5F84\u6A21\u677F\u914D\u7F6E",
      articleTemplateLabel: "\u6587\u7AE0\u8DEF\u5F84\u6A21\u677F",
      articleTemplateHint: "\u7528\u4E8E\u5B8C\u6574\u7684\u7F51\u9875\u6587\u7AE0\u526A\u85CF",
      fragmentTemplateLabel: "\u7247\u6BB5\u8DEF\u5F84\u6A21\u677F",
      fragmentTemplateHint: "\u7528\u4E8E\u9009\u4E2D\u6587\u672C\u7247\u6BB5\u7684\u5FEB\u901F\u526A\u85CF",
      aiTemplateLabel: "AI \u5BF9\u8BDD\u8DEF\u5F84\u6A21\u677F",
      aiTemplateHint: "\u7528\u4E8E AI \u804A\u5929\u5BF9\u8BDD\u7684\u526A\u85CF",
      availableVariables: "\u53EF\u7528\u53D8\u91CF\uFF1A",
      // Domain Mapping
      domainMappingTitle: "\u57DF\u540D\u6620\u5C04\u914D\u7F6E",
      domainMappingHint: "\u{1F4A1} \u4E3A\u7279\u5B9A\u57DF\u540D\u81EA\u5B9A\u4E49\u6587\u4EF6\u5939\u540D\u79F0",
      domainLabel: "\u57DF\u540D",
      folderNameLabel: "\u6587\u4EF6\u5939\u540D\u79F0",
      addMappingButton: "+ \u6DFB\u52A0\u6620\u5C04",
      // Config Transfer
      configTransferTitle: "\u914D\u7F6E\u540C\u6B65",
      configTransferHint: "\u{1F4A1} \u4E00\u952E\u590D\u5236\u4E0E\u5BFC\u5165\uFF0C\u8DE8\u6D4F\u89C8\u5668\u540C\u6B65\u66F4\u8F7B\u677E",
      copyConfigButton: "\u590D\u5236\u914D\u7F6E",
      importConfigButton: "\u5BFC\u5165\u5E76\u4FDD\u5B58",
      configTransferNote: "\u64CD\u4F5C\u4F1A\u4F7F\u7528\u7CFB\u7EDF\u526A\u8D34\u677F\uFF0C\u8BF7\u786E\u8BA4\u6D4F\u89C8\u5668\u5DF2\u6388\u6743\u8BBF\u95EE\u540E\u518D\u7EE7\u7EED\u3002",
      copyConfigSuccess: "\u2705 \u914D\u7F6E\u5DF2\u590D\u5236\u5230\u526A\u8D34\u677F",
      importSuccess: "\u2705 \u914D\u7F6E\u5DF2\u5BFC\u5165\u5E76\u4FDD\u5B58",
      importParseFailed: "\u274C \u914D\u7F6E\u89E3\u6790\u5931\u8D25",
      emptyImportError: "\u526A\u8D34\u677F\u4E3A\u7A7A\uFF0C\u8BF7\u5148\u590D\u5236\u914D\u7F6E",
      clipboardUnavailable: "\u65E0\u6CD5\u8BBF\u95EE\u526A\u8D34\u677F\uFF0C\u8BF7\u624B\u52A8\u590D\u5236",
      clipboardReadUnavailable: "\u65E0\u6CD5\u8BFB\u53D6\u526A\u8D34\u677F\uFF0C\u8BF7\u5728\u6D4F\u89C8\u5668\u8BBE\u7F6E\u4E2D\u6388\u4E88\u6743\u9650\u540E\u91CD\u8BD5",
      invalidTaxonomy: "\u5206\u7C7B\u5668 Taxonomy \u4E0D\u662F\u6709\u6548\u7684 JSON",
      // AI Chat Configuration
      aiChatConfigTitle: "AI \u5BF9\u8BDD\u526A\u85CF\u914D\u7F6E",
      aiChatConfigHint: "\u{1F4A1} \u81EA\u5B9A\u4E49 AI \u5BF9\u8BDD\u7684\u526A\u85CF\u683C\u5F0F\u548C\u5185\u5BB9",
      includeTimestampsLabel: "\u5305\u542B\u6D88\u606F\u65F6\u95F4\u6233",
      includeTimestampsHint: "\u5728\u6BCF\u6761\u6D88\u606F\u540E\u663E\u793A\u53D1\u9001\u65F6\u95F4\uFF08\u5982\u679C\u53EF\u7528\uFF09",
      userNameLabel: "\u7528\u6237\u540D\u79F0",
      userNamePlaceholder: "USER",
      userNameHint: '\u81EA\u5B9A\u4E49\u7528\u6237\u6D88\u606F\u7684\u663E\u793A\u540D\u79F0\uFF0C\u9ED8\u8BA4\u4E3A "USER"',
      // Deep Research Configuration
      deepResearchConfigTitle: "Gemini Deep Research \u914D\u7F6E",
      deepResearchConfigHint: "\u{1F4A1} \u81EA\u5B9A\u4E49 Deep Research \u62A5\u544A\u7684\u6355\u6349\u65B9\u5F0F",
      pureModeLabel: "\u63D0\u7EAF\u6A21\u5F0F\uFF08\u53EA\u6355\u6349\u62A5\u544A\u5185\u5BB9\uFF09",
      pureModeHint: "\u542F\u7528\u540E\uFF0C\u53EA\u6355\u6349 Deep Research \u62A5\u544A\u5185\u5BB9\uFF0C\u4E0D\u5305\u542B\u5BF9\u8BDD\u6D88\u606F",
      multipleReportsInfo: "\u2139\uFE0F \u5173\u4E8E\u591A\u4E2A\u62A5\u544A: Gemini \u4E00\u6B21\u53EA\u80FD\u663E\u793A\u4E00\u4E2A\u5B8C\u6574\u62A5\u544A\u3002\u5982\u9700\u4FDD\u5B58\u591A\u4E2A\u62A5\u544A\uFF0C\u8BF7\u5206\u522B\u6253\u5F00\u6BCF\u4E2A\u62A5\u544A\u5E76\u70B9\u51FB\u526A\u85CF\u3002",
      // Classifier Configuration
      classifierConfigTitle: "\u667A\u80FD\u5206\u7C7B\u914D\u7F6E\uFF08\u53EF\u9009\uFF09",
      classifierConfigHint: "\u{1F4A1} \u4F7F\u7528 LLM \u81EA\u52A8\u5206\u7C7B\u548C\u6807\u8BB0\u526A\u85CF\u5185\u5BB9",
      enableClassifierLabel: "\u542F\u7528\u667A\u80FD\u5206\u7C7B",
      providerLabel: "LLM \u63D0\u4F9B\u5546",
      endpointLabel: "API \u7AEF\u70B9",
      endpointPlaceholder: "http://localhost:11434/api/chat",
      modelLabel: "\u6A21\u578B\u540D\u79F0",
      modelPlaceholder: "llama3.1",
      taxonomyLabel: "\u5206\u7C7B\u4F53\u7CFB",
      taxonomyHint: "\u5B9A\u4E49\u5206\u7C7B\u4F53\u7CFB\uFF0CJSON \u683C\u5F0F",
      // Buttons
      saveButton: "\u{1F4BE} \u4FDD\u5B58\u914D\u7F6E",
      diagnoseButton: "\u{1F50D} \u8BCA\u65AD\u914D\u7F6E",
      fixButton: "\u{1F527} \u4FEE\u590D\u914D\u7F6E",
      reloadButton: "\u{1F504} \u91CD\u65B0\u52A0\u8F7D",
      // Messages
      saveSuccess: "\u2705 \u914D\u7F6E\u5DF2\u4FDD\u5B58",
      saveFailed: "\u274C \u4FDD\u5B58\u5931\u8D25",
      configFixed: "\u2705 \u914D\u7F6E\u5DF2\u4FEE\u590D\u5E76\u4FDD\u5B58",
      fixFailed: "\u274C \u4FEE\u590D\u5931\u8D25",
      reloadPrompt: "\u8BF7\u91CD\u65B0\u52A0\u8F7D\u9875\u9762\u67E5\u770B\u4FEE\u590D\u540E\u7684\u914D\u7F6E",
      // Diagnosis
      diagnosisTitle: "\u914D\u7F6E\u8BCA\u65AD",
      // Notifications
      clipSuccess: "\u5DF2\u4FDD\u5B58\u5230 Obsidian",
      clipFailed: "\u526A\u85CF\u5931\u8D25",
      extractionFailed: "\u5185\u5BB9\u63D0\u53D6\u5931\u8D25",
      connectionFailed: "\u8FDE\u63A5\u5931\u8D25",
      scriptInjectionFailed: "\u65E0\u6CD5\u6CE8\u5165\u5185\u5BB9\u811A\u672C",
      // Context Menu
      clipFullPage: "\u526A\u85CF\u6574\u4E2A\u9875\u9762\u5230 Obsidian",
      clipSelection: "\u2702\uFE0F \u526A\u85CF\u9009\u4E2D\u5185\u5BB9\u5230 Obsidian",
      // Dialog
      clipDialogTitle: "\u{1F4CE} \u526A\u85CF\u9009\u4E2D\u5185\u5BB9",
      commentLabel: "\u{1F4AD} \u6DFB\u52A0\u4F60\u7684\u8BC4\u8BBA\uFF08\u53EF\u9009\uFF09\uFF1A",
      commentPlaceholder: "\u5728\u8FD9\u91CC\u5199\u4E0B\u4F60\u7684\u60F3\u6CD5\u3001\u7B14\u8BB0\u6216\u8BC4\u8BBA...",
      cancelButton: "\u53D6\u6D88",
      clipButton: "\u2702\uFE0F \u526A\u85CF",
      // Multi-Vault
      additionalVaultsTitle: "\u989D\u5916\u4ED3\u5E93",
      additionalVaultsHint: "\u{1F4A1} \u6DFB\u52A0\u66F4\u591A\u4ED3\u5E93\uFF0C\u901A\u8FC7\u8DEF\u7531\u89C4\u5219\u81EA\u52A8\u5206\u914D\u5185\u5BB9",
      addVaultButton: "+ \u6DFB\u52A0\u4ED3\u5E93",
      multiVaultNameLabel: "\u4ED3\u5E93\u540D\u79F0",
      multiVaultNamePlaceholder: "\u6211\u7684\u7B14\u8BB0\u4ED3\u5E93",
      deleteVaultButton: "\u5220\u9664",
      defaultVaultBadge: "\u9ED8\u8BA4\u4ED3\u5E93",
      // Routing Rules
      routingRulesTitle: "\u8DEF\u7531\u89C4\u5219",
      routingRulesHint: "\u{1F4A1} \u6839\u636E\u57DF\u540D\u3001\u5173\u952E\u8BCD\u6216 URL \u6A21\u5F0F\u81EA\u52A8\u9009\u62E9\u76EE\u6807\u4ED3\u5E93",
      addRuleButton: "+ \u6DFB\u52A0\u89C4\u5219",
      ruleTypeLabel: "\u89C4\u5219\u7C7B\u578B",
      ruleTypeDomain: "\u57DF\u540D\u5339\u914D",
      ruleTypeKeyword: "\u5173\u952E\u8BCD\u5339\u914D",
      ruleTypeUrlPattern: "URL \u6A21\u5F0F",
      rulePatternLabel: "\u5339\u914D\u6A21\u5F0F",
      rulePatternPlaceholder: "\u4F8B\u5982\uFF1Aexample.com \u6216 \u5173\u952E\u8BCD1,\u5173\u952E\u8BCD2",
      ruleTargetVaultLabel: "\u76EE\u6807\u4ED3\u5E93",
      rulePriorityLabel: "\u4F18\u5148\u7EA7",
      ruleDescriptionLabel: "\u89C4\u5219\u63CF\u8FF0",
      ruleDescriptionPlaceholder: "\u4F8B\u5982\uFF1A\u6280\u672F\u6587\u7AE0\u4FDD\u5B58\u5230\u5DE5\u4F5C\u4ED3\u5E93",
      ruleEnabledLabel: "\u542F\u7528",
      deleteRuleButton: "\u5220\u9664",
      editRuleButton: "\u7F16\u8F91"
    },
    "en": {
      // General
      extensionName: "All in Obsidian",
      extensionSubtitle: "Configure your clipper for smarter content management",
      // Settings page sections
      settingsTitle: "Settings",
      languageSettings: "Language Settings",
      languageLabel: "Interface Language",
      languageHint: "\u{1F4A1} Choose your preferred interface language",
      // API Configuration
      apiConfigTitle: "Obsidian Local REST API",
      apiConfigHint: "\u{1F4A1} Configure both HTTPS and HTTP URLs, the extension will intelligently choose the available connection",
      httpsUrlLabel: "HTTPS URL",
      httpsUrlHint: "Usually port 27124, for secure connections",
      httpUrlLabel: "HTTP URL",
      httpUrlHint: "Usually port 27123, as fallback connection",
      vaultNameLabel: "Vault Name",
      vaultNamePlaceholder: "YourVault",
      vaultNameHint: "Your Obsidian vault name",
      apiKeyLabel: "API Key",
      apiKeyPlaceholder: "Your API key",
      apiKeyHint: "Get it from Obsidian Local REST API plugin settings",
      // Template Configuration
      templateConfigTitle: "Path Template Configuration",
      articleTemplateLabel: "Article Path Template",
      articleTemplateHint: "For full webpage article clipping",
      fragmentTemplateLabel: "Fragment Path Template",
      fragmentTemplateHint: "For quick clipping of selected text fragments",
      aiTemplateLabel: "AI Chat Path Template",
      aiTemplateHint: "For AI chat conversation clipping",
      availableVariables: "Available variables:",
      // Domain Mapping
      domainMappingTitle: "Domain Mapping Configuration",
      domainMappingHint: "\u{1F4A1} Customize folder names for specific domains",
      domainLabel: "Domain",
      folderNameLabel: "Folder Name",
      addMappingButton: "+ Add Mapping",
      // Config Transfer
      configTransferTitle: "Configuration Sync",
      configTransferHint: "\u{1F4A1} Copy once and import anywhere to keep browsers in sync.",
      copyConfigButton: "Copy configuration",
      importConfigButton: "Import from clipboard",
      configTransferNote: "These actions use the system clipboard\u2014ensure the browser is allowed to access it.",
      copyConfigSuccess: "\u2705 Configuration copied to clipboard",
      importSuccess: "\u2705 Configuration imported and saved",
      importParseFailed: "\u274C Failed to parse configuration",
      emptyImportError: "Clipboard is empty, please copy a configuration first",
      clipboardUnavailable: "Clipboard unavailable, please copy manually",
      clipboardReadUnavailable: "Unable to read the clipboard. Grant clipboard permissions and try again.",
      invalidTaxonomy: "Classifier taxonomy must be valid JSON",
      // AI Chat Configuration
      aiChatConfigTitle: "AI Chat Clipping Configuration",
      aiChatConfigHint: "\u{1F4A1} Customize the format and content of AI chat clips",
      includeTimestampsLabel: "Include message timestamps",
      includeTimestampsHint: "Show send time after each message (if available)",
      userNameLabel: "User Name",
      userNamePlaceholder: "USER",
      userNameHint: 'Customize the display name for user messages, default is "USER"',
      // Deep Research Configuration
      deepResearchConfigTitle: "Gemini Deep Research Configuration",
      deepResearchConfigHint: "\u{1F4A1} Customize how Deep Research reports are captured",
      pureModeLabel: "Pure Mode (capture report content only)",
      pureModeHint: "When enabled, only capture Deep Research report content, excluding conversation messages",
      multipleReportsInfo: "\u2139\uFE0F About multiple reports: Gemini can only display one complete report at a time. To save multiple reports, open each report separately and clip them.",
      // Classifier Configuration
      classifierConfigTitle: "Smart Classification Configuration (Optional)",
      classifierConfigHint: "\u{1F4A1} Use LLM to automatically classify and tag clipped content",
      enableClassifierLabel: "Enable Smart Classification",
      providerLabel: "LLM Provider",
      endpointLabel: "API Endpoint",
      endpointPlaceholder: "http://localhost:11434/api/chat",
      modelLabel: "Model Name",
      modelPlaceholder: "llama3.1",
      taxonomyLabel: "Taxonomy",
      taxonomyHint: "Define classification taxonomy in JSON format",
      // Buttons
      saveButton: "\u{1F4BE} Save Configuration",
      diagnoseButton: "\u{1F50D} Diagnose Configuration",
      fixButton: "\u{1F527} Fix Configuration",
      reloadButton: "\u{1F504} Reload",
      // Messages
      saveSuccess: "\u2705 Configuration saved",
      saveFailed: "\u274C Save failed",
      configFixed: "\u2705 Configuration fixed and saved",
      fixFailed: "\u274C Fix failed",
      reloadPrompt: "Please reload the page to see the fixed configuration",
      // Diagnosis
      diagnosisTitle: "Configuration Diagnosis",
      // Notifications
      clipSuccess: "Saved to Obsidian",
      clipFailed: "Clip failed",
      extractionFailed: "Content extraction failed",
      connectionFailed: "Connection failed",
      scriptInjectionFailed: "Failed to inject content script",
      // Context Menu
      clipFullPage: "Clip full page to Obsidian",
      clipSelection: "\u2702\uFE0F Clip selection to Obsidian",
      // Dialog
      clipDialogTitle: "\u{1F4CE} Clip Selection",
      commentLabel: "\u{1F4AD} Add your comment (optional):",
      commentPlaceholder: "Write your thoughts, notes or comments here...",
      cancelButton: "Cancel",
      clipButton: "\u2702\uFE0F Clip",
      // Multi-Vault
      additionalVaultsTitle: "Additional Vaults",
      additionalVaultsHint: "\u{1F4A1} Add more vaults and automatically route content using rules",
      addVaultButton: "+ Add Vault",
      multiVaultNameLabel: "Vault Name",
      multiVaultNamePlaceholder: "My Notes Vault",
      deleteVaultButton: "Delete",
      defaultVaultBadge: "Default Vault",
      // Routing Rules
      routingRulesTitle: "Routing Rules",
      routingRulesHint: "\u{1F4A1} Automatically select target vault based on domain, keywords, or URL patterns",
      addRuleButton: "+ Add Rule",
      ruleTypeLabel: "Rule Type",
      ruleTypeDomain: "Domain Match",
      ruleTypeKeyword: "Keyword Match",
      ruleTypeUrlPattern: "URL Pattern",
      rulePatternLabel: "Match Pattern",
      rulePatternPlaceholder: "e.g., example.com or keyword1,keyword2",
      ruleTargetVaultLabel: "Target Vault",
      rulePriorityLabel: "Priority",
      ruleDescriptionLabel: "Description",
      ruleDescriptionPlaceholder: "e.g., Save tech articles to work vault",
      ruleEnabledLabel: "Enabled",
      deleteRuleButton: "Delete",
      editRuleButton: "Edit"
    },
    "ja": {
      // General
      extensionName: "All in Obsidian",
      extensionSubtitle: "\u30AF\u30EA\u30C3\u30D1\u30FC\u3092\u8A2D\u5B9A\u3057\u3066\u3001\u3088\u308A\u30B9\u30DE\u30FC\u30C8\u306A\u30B3\u30F3\u30C6\u30F3\u30C4\u7BA1\u7406\u3092\u5B9F\u73FE",
      // Settings page sections
      settingsTitle: "\u8A2D\u5B9A",
      languageSettings: "\u8A00\u8A9E\u8A2D\u5B9A",
      languageLabel: "\u30A4\u30F3\u30BF\u30FC\u30D5\u30A7\u30FC\u30B9\u8A00\u8A9E",
      languageHint: "\u{1F4A1} \u304A\u597D\u307F\u306E\u30A4\u30F3\u30BF\u30FC\u30D5\u30A7\u30FC\u30B9\u8A00\u8A9E\u3092\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044",
      // API Configuration
      apiConfigTitle: "Obsidian Local REST API",
      apiConfigHint: "\u{1F4A1} HTTPS \u3068 HTTP \u306E\u4E21\u65B9\u306E URL \u3092\u8A2D\u5B9A\u3059\u308B\u3068\u3001\u62E1\u5F35\u6A5F\u80FD\u304C\u5229\u7528\u53EF\u80FD\u306A\u63A5\u7D9A\u3092\u81EA\u52D5\u7684\u306B\u9078\u629E\u3057\u307E\u3059",
      httpsUrlLabel: "HTTPS URL",
      httpsUrlHint: "\u901A\u5E38\u306F\u30DD\u30FC\u30C8 27124\u3001\u30BB\u30AD\u30E5\u30A2\u63A5\u7D9A\u7528",
      httpUrlLabel: "HTTP URL",
      httpUrlHint: "\u901A\u5E38\u306F\u30DD\u30FC\u30C8 27123\u3001\u30D5\u30A9\u30FC\u30EB\u30D0\u30C3\u30AF\u63A5\u7D9A\u7528",
      vaultNameLabel: "Vault \u540D",
      vaultNamePlaceholder: "YourVault",
      vaultNameHint: "Obsidian \u306E Vault \u540D",
      apiKeyLabel: "API \u30AD\u30FC",
      apiKeyPlaceholder: "API \u30AD\u30FC",
      apiKeyHint: "Obsidian Local REST API \u30D7\u30E9\u30B0\u30A4\u30F3\u306E\u8A2D\u5B9A\u304B\u3089\u53D6\u5F97",
      // Template Configuration
      templateConfigTitle: "\u30D1\u30B9\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u8A2D\u5B9A",
      articleTemplateLabel: "\u8A18\u4E8B\u30D1\u30B9\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
      articleTemplateHint: "\u5B8C\u5168\u306A\u30A6\u30A7\u30D6\u30DA\u30FC\u30B8\u8A18\u4E8B\u306E\u30AF\u30EA\u30C3\u30D4\u30F3\u30B0\u7528",
      fragmentTemplateLabel: "\u30D5\u30E9\u30B0\u30E1\u30F3\u30C8\u30D1\u30B9\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
      fragmentTemplateHint: "\u9078\u629E\u3057\u305F\u30C6\u30AD\u30B9\u30C8\u30D5\u30E9\u30B0\u30E1\u30F3\u30C8\u306E\u9AD8\u901F\u30AF\u30EA\u30C3\u30D4\u30F3\u30B0\u7528",
      aiTemplateLabel: "AI \u30C1\u30E3\u30C3\u30C8\u30D1\u30B9\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
      aiTemplateHint: "AI \u30C1\u30E3\u30C3\u30C8\u4F1A\u8A71\u306E\u30AF\u30EA\u30C3\u30D4\u30F3\u30B0\u7528",
      availableVariables: "\u5229\u7528\u53EF\u80FD\u306A\u5909\u6570\uFF1A",
      // Domain Mapping
      domainMappingTitle: "\u30C9\u30E1\u30A4\u30F3\u30DE\u30C3\u30D4\u30F3\u30B0\u8A2D\u5B9A",
      domainMappingHint: "\u{1F4A1} \u7279\u5B9A\u306E\u30C9\u30E1\u30A4\u30F3\u306E\u30D5\u30A9\u30EB\u30C0\u540D\u3092\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA",
      domainLabel: "\u30C9\u30E1\u30A4\u30F3",
      folderNameLabel: "\u30D5\u30A9\u30EB\u30C0\u540D",
      addMappingButton: "+ \u30DE\u30C3\u30D4\u30F3\u30B0\u3092\u8FFD\u52A0",
      // Config Transfer
      configTransferTitle: "\u8A2D\u5B9A\u306E\u540C\u671F",
      configTransferHint: "\u{1F4A1} \u4E00\u5EA6\u30B3\u30D4\u30FC\u3059\u308C\u3070\u3001\u3069\u306E\u30D6\u30E9\u30A6\u30B6\u3067\u3082\u3059\u3050\u306B\u540C\u671F\u3067\u304D\u307E\u3059\u3002",
      copyConfigButton: "\u8A2D\u5B9A\u3092\u30B3\u30D4\u30FC",
      importConfigButton: "\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u304B\u3089\u4FDD\u5B58",
      configTransferNote: "\u64CD\u4F5C\u3067\u306F\u30B7\u30B9\u30C6\u30E0\u306E\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u3092\u4F7F\u7528\u3057\u307E\u3059\u3002\u30D6\u30E9\u30A6\u30B6\u306B\u6A29\u9650\u304C\u4ED8\u4E0E\u3055\u308C\u3066\u3044\u308B\u304B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
      copyConfigSuccess: "\u2705 \u8A2D\u5B9A\u3092\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u306B\u30B3\u30D4\u30FC\u3057\u307E\u3057\u305F",
      importSuccess: "\u2705 \u8A2D\u5B9A\u3092\u30A4\u30F3\u30DD\u30FC\u30C8\u3057\u3066\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      importParseFailed: "\u274C \u8A2D\u5B9A\u306E\u89E3\u6790\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      emptyImportError: "\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u304C\u7A7A\u3067\u3059\u3002\u5148\u306B\u8A2D\u5B9A\u3092\u30B3\u30D4\u30FC\u3057\u3066\u304F\u3060\u3055\u3044",
      clipboardUnavailable: "\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u306B\u30A2\u30AF\u30BB\u30B9\u3067\u304D\u307E\u305B\u3093\u3002\u624B\u52D5\u3067\u30B3\u30D4\u30FC\u3057\u3066\u304F\u3060\u3055\u3044",
      clipboardReadUnavailable: "\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u3092\u8AAD\u307F\u53D6\u308C\u307E\u305B\u3093\u3002\u30D6\u30E9\u30A6\u30B6\u3067\u6A29\u9650\u3092\u8A31\u53EF\u3057\u3066\u304B\u3089\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044",
      invalidTaxonomy: "\u5206\u985E\u5668\u306E\u30BF\u30AF\u30BD\u30CE\u30DF\u30FC\u306F\u6709\u52B9\u306A JSON \u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059",
      // AI Chat Configuration
      aiChatConfigTitle: "AI \u30C1\u30E3\u30C3\u30C8\u30AF\u30EA\u30C3\u30D7\u8A2D\u5B9A",
      aiChatConfigHint: "\u{1F4A1} AI \u30C1\u30E3\u30C3\u30C8\u30AF\u30EA\u30C3\u30D7\u306E\u5F62\u5F0F\u3068\u5185\u5BB9\u3092\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA",
      includeTimestampsLabel: "\u30E1\u30C3\u30BB\u30FC\u30B8\u306E\u30BF\u30A4\u30E0\u30B9\u30BF\u30F3\u30D7\u3092\u542B\u3081\u308B",
      includeTimestampsHint: "\u5404\u30E1\u30C3\u30BB\u30FC\u30B8\u306E\u5F8C\u306B\u9001\u4FE1\u6642\u523B\u3092\u8868\u793A\uFF08\u5229\u7528\u53EF\u80FD\u306A\u5834\u5408\uFF09",
      userNameLabel: "\u30E6\u30FC\u30B6\u30FC\u540D",
      userNamePlaceholder: "USER",
      userNameHint: '\u30E6\u30FC\u30B6\u30FC\u30E1\u30C3\u30BB\u30FC\u30B8\u306E\u8868\u793A\u540D\u3092\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA\u3001\u30C7\u30D5\u30A9\u30EB\u30C8\u306F "USER"',
      // Deep Research Configuration
      deepResearchConfigTitle: "Gemini Deep Research \u8A2D\u5B9A",
      deepResearchConfigHint: "\u{1F4A1} Deep Research \u30EC\u30DD\u30FC\u30C8\u306E\u30AD\u30E3\u30D7\u30C1\u30E3\u65B9\u6CD5\u3092\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA",
      pureModeLabel: "\u30D4\u30E5\u30A2\u30E2\u30FC\u30C9\uFF08\u30EC\u30DD\u30FC\u30C8\u5185\u5BB9\u306E\u307F\u30AD\u30E3\u30D7\u30C1\u30E3\uFF09",
      pureModeHint: "\u6709\u52B9\u306B\u3059\u308B\u3068\u3001Deep Research \u30EC\u30DD\u30FC\u30C8\u306E\u5185\u5BB9\u306E\u307F\u3092\u30AD\u30E3\u30D7\u30C1\u30E3\u3057\u3001\u4F1A\u8A71\u30E1\u30C3\u30BB\u30FC\u30B8\u306F\u542B\u3081\u307E\u305B\u3093",
      multipleReportsInfo: "\u2139\uFE0F \u8907\u6570\u306E\u30EC\u30DD\u30FC\u30C8\u306B\u3064\u3044\u3066: Gemini \u306F\u4E00\u5EA6\u306B 1 \u3064\u306E\u5B8C\u5168\u306A\u30EC\u30DD\u30FC\u30C8\u306E\u307F\u3092\u8868\u793A\u3067\u304D\u307E\u3059\u3002\u8907\u6570\u306E\u30EC\u30DD\u30FC\u30C8\u3092\u4FDD\u5B58\u3059\u308B\u306B\u306F\u3001\u5404\u30EC\u30DD\u30FC\u30C8\u3092\u500B\u5225\u306B\u958B\u3044\u3066\u30AF\u30EA\u30C3\u30D7\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
      // Classifier Configuration
      classifierConfigTitle: "\u30B9\u30DE\u30FC\u30C8\u5206\u985E\u8A2D\u5B9A\uFF08\u30AA\u30D7\u30B7\u30E7\u30F3\uFF09",
      classifierConfigHint: "\u{1F4A1} LLM \u3092\u4F7F\u7528\u3057\u3066\u30AF\u30EA\u30C3\u30D7\u3055\u308C\u305F\u30B3\u30F3\u30C6\u30F3\u30C4\u3092\u81EA\u52D5\u7684\u306B\u5206\u985E\u304A\u3088\u3073\u30BF\u30B0\u4ED8\u3051",
      enableClassifierLabel: "\u30B9\u30DE\u30FC\u30C8\u5206\u985E\u3092\u6709\u52B9\u306B\u3059\u308B",
      providerLabel: "LLM \u30D7\u30ED\u30D0\u30A4\u30C0\u30FC",
      endpointLabel: "API \u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8",
      endpointPlaceholder: "http://localhost:11434/api/chat",
      modelLabel: "\u30E2\u30C7\u30EB\u540D",
      modelPlaceholder: "llama3.1",
      taxonomyLabel: "\u5206\u985E\u4F53\u7CFB",
      taxonomyHint: "JSON \u5F62\u5F0F\u3067\u5206\u985E\u4F53\u7CFB\u3092\u5B9A\u7FA9",
      // Buttons
      saveButton: "\u{1F4BE} \u8A2D\u5B9A\u3092\u4FDD\u5B58",
      diagnoseButton: "\u{1F50D} \u8A2D\u5B9A\u3092\u8A3A\u65AD",
      fixButton: "\u{1F527} \u8A2D\u5B9A\u3092\u4FEE\u5FA9",
      reloadButton: "\u{1F504} \u518D\u8AAD\u307F\u8FBC\u307F",
      // Messages
      saveSuccess: "\u2705 \u8A2D\u5B9A\u304C\u4FDD\u5B58\u3055\u308C\u307E\u3057\u305F",
      saveFailed: "\u274C \u4FDD\u5B58\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      configFixed: "\u2705 \u8A2D\u5B9A\u304C\u4FEE\u5FA9\u3055\u308C\u4FDD\u5B58\u3055\u308C\u307E\u3057\u305F",
      fixFailed: "\u274C \u4FEE\u5FA9\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      reloadPrompt: "\u4FEE\u5FA9\u3055\u308C\u305F\u8A2D\u5B9A\u3092\u78BA\u8A8D\u3059\u308B\u306B\u306F\u30DA\u30FC\u30B8\u3092\u518D\u8AAD\u307F\u8FBC\u307F\u3057\u3066\u304F\u3060\u3055\u3044",
      // Diagnosis
      diagnosisTitle: "\u8A2D\u5B9A\u8A3A\u65AD",
      // Notifications
      clipSuccess: "Obsidian \u306B\u4FDD\u5B58\u3055\u308C\u307E\u3057\u305F",
      clipFailed: "\u30AF\u30EA\u30C3\u30D7\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      extractionFailed: "\u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u62BD\u51FA\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      connectionFailed: "\u63A5\u7D9A\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      scriptInjectionFailed: "\u30B3\u30F3\u30C6\u30F3\u30C4\u30B9\u30AF\u30EA\u30D7\u30C8\u306E\u6CE8\u5165\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      // Context Menu
      clipFullPage: "\u30DA\u30FC\u30B8\u5168\u4F53\u3092 Obsidian \u306B\u30AF\u30EA\u30C3\u30D7",
      clipSelection: "\u2702\uFE0F \u9078\u629E\u7BC4\u56F2\u3092 Obsidian \u306B\u30AF\u30EA\u30C3\u30D7",
      // Dialog
      clipDialogTitle: "\u{1F4CE} \u9078\u629E\u7BC4\u56F2\u3092\u30AF\u30EA\u30C3\u30D7",
      commentLabel: "\u{1F4AD} \u30B3\u30E1\u30F3\u30C8\u3092\u8FFD\u52A0\uFF08\u30AA\u30D7\u30B7\u30E7\u30F3\uFF09\uFF1A",
      commentPlaceholder: "\u3053\u3053\u306B\u8003\u3048\u3001\u30E1\u30E2\u3001\u30B3\u30E1\u30F3\u30C8\u3092\u66F8\u3044\u3066\u304F\u3060\u3055\u3044...",
      cancelButton: "\u30AD\u30E3\u30F3\u30BB\u30EB",
      clipButton: "\u2702\uFE0F \u30AF\u30EA\u30C3\u30D7",
      // Multi-Vault
      additionalVaultsTitle: "\u8FFD\u52A0 Vault",
      additionalVaultsHint: "\u{1F4A1} \u3055\u3089\u306B Vault \u3092\u8FFD\u52A0\u3057\u3001\u30EB\u30FC\u30EB\u306B\u57FA\u3065\u3044\u3066\u81EA\u52D5\u7684\u306B\u30B3\u30F3\u30C6\u30F3\u30C4\u3092\u632F\u308A\u5206\u3051",
      addVaultButton: "+ Vault \u3092\u8FFD\u52A0",
      multiVaultNameLabel: "Vault \u540D",
      multiVaultNamePlaceholder: "\u30DE\u30A4\u30CE\u30FC\u30C8 Vault",
      deleteVaultButton: "\u524A\u9664",
      defaultVaultBadge: "\u30C7\u30D5\u30A9\u30EB\u30C8 Vault",
      // Routing Rules
      routingRulesTitle: "\u30EB\u30FC\u30C6\u30A3\u30F3\u30B0\u30EB\u30FC\u30EB",
      routingRulesHint: "\u{1F4A1} \u30C9\u30E1\u30A4\u30F3\u3001\u30AD\u30FC\u30EF\u30FC\u30C9\u3001\u307E\u305F\u306F URL \u30D1\u30BF\u30FC\u30F3\u306B\u57FA\u3065\u3044\u3066\u81EA\u52D5\u7684\u306B\u30BF\u30FC\u30B2\u30C3\u30C8 Vault \u3092\u9078\u629E",
      addRuleButton: "+ \u30EB\u30FC\u30EB\u3092\u8FFD\u52A0",
      ruleTypeLabel: "\u30EB\u30FC\u30EB\u30BF\u30A4\u30D7",
      ruleTypeDomain: "\u30C9\u30E1\u30A4\u30F3\u30DE\u30C3\u30C1",
      ruleTypeKeyword: "\u30AD\u30FC\u30EF\u30FC\u30C9\u30DE\u30C3\u30C1",
      ruleTypeUrlPattern: "URL \u30D1\u30BF\u30FC\u30F3",
      rulePatternLabel: "\u30DE\u30C3\u30C1\u30D1\u30BF\u30FC\u30F3",
      rulePatternPlaceholder: "\u4F8B\uFF1Aexample.com \u307E\u305F\u306F \u30AD\u30FC\u30EF\u30FC\u30C91,\u30AD\u30FC\u30EF\u30FC\u30C92",
      ruleTargetVaultLabel: "\u30BF\u30FC\u30B2\u30C3\u30C8 Vault",
      rulePriorityLabel: "\u512A\u5148\u5EA6",
      ruleDescriptionLabel: "\u8AAC\u660E",
      ruleDescriptionPlaceholder: "\u4F8B\uFF1A\u6280\u8853\u8A18\u4E8B\u3092\u4ED5\u4E8B\u7528 Vault \u306B\u4FDD\u5B58",
      ruleEnabledLabel: "\u6709\u52B9",
      deleteRuleButton: "\u524A\u9664",
      editRuleButton: "\u7DE8\u96C6"
    }
  };

  // src/i18n/index.ts
  var DEFAULT_LANGUAGE = "zh-CN";
  async function getCurrentLanguage() {
    try {
      const result = await chrome.storage.sync.get("language");
      return result.language || DEFAULT_LANGUAGE;
    } catch (error) {
      console.error("Failed to get language:", error);
      return DEFAULT_LANGUAGE;
    }
  }
  async function getMessages() {
    const language = await getCurrentLanguage();
    return messages[language];
  }

  // src/content/clipper-dialog.ts
  var ClipperDialog = class {
    constructor() {
      this.dialog = null;
      this.resolve = null;
    }
    /**
     * Show the dialog and wait for user input
     */
    async show(selectedText) {
      return new Promise((resolve) => {
        this.resolve = resolve;
        this.createDialog(selectedText);
      });
    }
    async createDialog(selectedText) {
      const msgs = await getMessages();
      this.remove();
      this.dialog = document.createElement("div");
      this.dialog.id = "obsidian-clipper-dialog";
      this.dialog.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.7);
      backdrop-filter: blur(4px);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 2147483647;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      animation: fadeIn 0.16s cubic-bezier(0.2, 0.8, 0.2, 1);
    `;
      const content = document.createElement("div");
      content.style.cssText = `
      background: #14172A;
      border: 1px solid #24273B;
      border-radius: 14px;
      padding: 24px;
      max-width: 600px;
      width: 90%;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35);
      animation: scaleIn 0.16s cubic-bezier(0.2, 0.8, 0.2, 1);
    `;
      const style = document.createElement("style");
      style.textContent = `
      @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }
      @keyframes scaleIn {
        from { opacity: 0; transform: scale(0.98); }
        to { opacity: 1; transform: scale(1); }
      }
    `;
      document.head.appendChild(style);
      const title = document.createElement("h2");
      title.textContent = msgs.clipDialogTitle;
      title.style.cssText = `
      margin: 0 0 4px 0;
      font-size: 20px;
      font-weight: 600;
      color: #E7E8F2;
    `;
      const divider = document.createElement("div");
      divider.style.cssText = `
      height: 1px;
      background: linear-gradient(90deg, #A855F7, #22D3EE);
      margin-bottom: 20px;
    `;
      const preview = document.createElement("div");
      preview.style.cssText = `
      background: #0B0C12;
      border: 1px solid #24273B;
      border-left: 3px solid #8B5CF6;
      padding: 12px 16px;
      margin-bottom: 20px;
      border-radius: 10px;
      max-height: 150px;
      overflow-y: auto;
      font-size: 14px;
      color: #A3A8C3;
      line-height: 1.6;
    `;
      preview.textContent = selectedText.substring(0, 500) + (selectedText.length > 500 ? "..." : "");
      const label = document.createElement("label");
      label.textContent = msgs.commentLabel;
      label.style.cssText = `
      display: block;
      margin-bottom: 8px;
      font-size: 14px;
      font-weight: 500;
      color: #E7E8F2;
    `;
      const textarea = document.createElement("textarea");
      textarea.id = "clipper-comment-input";
      textarea.placeholder = msgs.commentPlaceholder;
      textarea.style.cssText = `
      width: 100%;
      min-height: 120px;
      padding: 12px;
      background: #0B0C12;
      border: 1px solid #24273B;
      border-radius: 10px;
      font-size: 14px;
      font-family: inherit;
      color: #E7E8F2;
      resize: vertical;
      box-sizing: border-box;
      margin-bottom: 20px;
      transition: box-shadow 0.15s ease, border-color 0.15s ease;
      outline: none;
    `;
      textarea.addEventListener("focus", () => {
        textarea.style.borderColor = "#6D28D9";
        textarea.style.boxShadow = "0 0 0 3px rgba(124, 58, 237, 0.35)";
      });
      textarea.addEventListener("blur", () => {
        textarea.style.borderColor = "#24273B";
        textarea.style.boxShadow = "none";
      });
      const buttonContainer = document.createElement("div");
      buttonContainer.style.cssText = `
      display: flex;
      gap: 12px;
      justify-content: flex-end;
    `;
      const cancelBtn = document.createElement("button");
      cancelBtn.textContent = msgs.cancelButton;
      cancelBtn.style.cssText = `
      padding: 10px 20px;
      border: 1px solid #24273B;
      background: transparent;
      color: #E7E8F2;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.15s ease;
    `;
      cancelBtn.addEventListener("mouseenter", () => {
        cancelBtn.style.background = "#14172A";
        cancelBtn.style.borderColor = "#3a3f5c";
      });
      cancelBtn.addEventListener("mouseleave", () => {
        cancelBtn.style.background = "transparent";
        cancelBtn.style.borderColor = "#24273B";
      });
      cancelBtn.addEventListener("click", () => {
        this.handleCancel();
      });
      const confirmBtn = document.createElement("button");
      confirmBtn.textContent = msgs.clipButton;
      confirmBtn.style.cssText = `
      padding: 10px 24px;
      border: none;
      background: linear-gradient(135deg, #A855F7, #22D3EE);
      color: white;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 6px 20px rgba(122, 84, 255, 0.25);
      transition: transform 0.12s ease, box-shadow 0.12s ease, filter 0.12s ease;
    `;
      confirmBtn.addEventListener("mouseenter", () => {
        confirmBtn.style.transform = "translateY(-1px)";
        confirmBtn.style.filter = "saturate(1.1)";
        confirmBtn.style.boxShadow = "0 8px 24px rgba(122, 84, 255, 0.35)";
      });
      confirmBtn.addEventListener("mouseleave", () => {
        confirmBtn.style.transform = "translateY(0)";
        confirmBtn.style.filter = "saturate(1)";
        confirmBtn.style.boxShadow = "0 6px 20px rgba(122, 84, 255, 0.25)";
      });
      confirmBtn.addEventListener("mousedown", () => {
        confirmBtn.style.transform = "translateY(0)";
        confirmBtn.style.boxShadow = "0 6px 20px rgba(122, 84, 255, 0.25)";
      });
      confirmBtn.addEventListener("click", () => {
        this.handleConfirm(textarea.value);
      });
      buttonContainer.appendChild(cancelBtn);
      buttonContainer.appendChild(confirmBtn);
      content.appendChild(title);
      content.appendChild(divider);
      content.appendChild(preview);
      content.appendChild(label);
      content.appendChild(textarea);
      content.appendChild(buttonContainer);
      this.dialog.appendChild(content);
      document.body.appendChild(this.dialog);
      setTimeout(() => textarea.focus(), 100);
      const handleEsc = (e) => {
        if (e.key === "Escape") {
          this.handleCancel();
          document.removeEventListener("keydown", handleEsc);
        }
      };
      document.addEventListener("keydown", handleEsc);
      this.dialog.addEventListener("click", (e) => {
        if (e.target === this.dialog) {
          this.handleCancel();
        }
      });
    }
    handleConfirm(comment) {
      if (this.resolve) {
        this.resolve({ confirmed: true, comment });
      }
      this.remove();
    }
    handleCancel() {
      if (this.resolve) {
        this.resolve({ confirmed: false, comment: "" });
      }
      this.remove();
    }
    remove() {
      if (this.dialog) {
        this.dialog.remove();
        this.dialog = null;
      }
    }
  };

  // src/content/index.ts
  var clipMode = "full";
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.action === "clipSelection") {
      clipMode = "selection";
      handleClip();
      sendResponse({ success: true });
      return true;
    }
  });
  async function handleClip() {
    try {
      console.log("Content script started, mode:", clipMode);
      const url = location.href;
      const doc = document;
      let result;
      if (clipMode === "selection") {
        const selection = window.getSelection();
        if (!selection || selection.rangeCount === 0) {
          throw new Error("No text selected");
        }
        const selectedText = selection.toString().trim();
        if (!selectedText) {
          throw new Error("Selected text is empty");
        }
        const range = selection.getRangeAt(0);
        const container = document.createElement("div");
        container.appendChild(range.cloneContents());
        const selectedHtml = container.innerHTML;
        console.log("Selected text length:", selectedText.length);
        console.log("Selected HTML length:", selectedHtml.length);
        const dialog = new ClipperDialog();
        const dialogResult = await dialog.show(selectedText);
        if (!dialogResult.confirmed) {
          console.log("User cancelled clipping");
          return;
        }
        result = await extractClipperContent(
          doc,
          url,
          selectedHtml,
          selectedText,
          dialogResult.comment
        );
        clipMode = "full";
      } else {
        console.log("Detecting page type...");
        const isChat = isAIChat(url, doc);
        console.log("Is AI chat:", isChat);
        result = isChat ? await extractAIChat(doc, url) : await extractArticle(doc, url);
      }
      console.log("Extraction result:", result);
      if (!result || !result.markdown) {
        throw new Error("Extraction failed: no markdown content");
      }
      chrome.runtime.sendMessage({ type: "CLIP_RESULT", payload: result });
      console.log("Message sent to background");
    } catch (error) {
      console.error("Content script error:", error);
      chrome.runtime.sendMessage({
        type: "CLIP_ERROR",
        error: error.message || String(error)
      });
    }
  }
  handleClip();
})();
//# sourceMappingURL=index.js.map
