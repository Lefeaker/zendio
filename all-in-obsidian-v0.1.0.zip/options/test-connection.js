"use strict";
(() => {
  // src/options/test-connection.ts
  function el(id) {
    return document.getElementById(id);
  }
  function showResult(elementId, message, type) {
    const elmt = document.getElementById(elementId);
    elmt.textContent = message;
    elmt.className = `result ${type}`;
    elmt.style.display = "block";
  }
  async function loadConfig() {
    try {
      const { options } = await chrome.storage.sync.get("options");
      if (options?.rest) {
        el("baseUrl").value = options.rest.baseUrl || "";
        el("vault").value = options.rest.vault || "";
        el("apiKey").value = options.rest.apiKey || "";
        showResult("cert-result", "\u2705 \u914D\u7F6E\u5DF2\u52A0\u8F7D", "success");
      } else {
        showResult("cert-result", "\u26A0\uFE0F \u672A\u627E\u5230\u4FDD\u5B58\u7684\u914D\u7F6E", "info");
      }
    } catch (error) {
      showResult("cert-result", `\u274C \u52A0\u8F7D\u914D\u7F6E\u5931\u8D25: ${error.message}`, "error");
    }
  }
  function saveTestConfig() {
    const config = {
      baseUrl: el("baseUrl").value.trim(),
      vault: el("vault").value.trim(),
      apiKey: el("apiKey").value.trim()
    };
    localStorage.setItem("testConfig", JSON.stringify(config));
    showResult("cert-result", "\u2705 \u6D4B\u8BD5\u914D\u7F6E\u5DF2\u4FDD\u5B58\u5230 localStorage", "success");
  }
  function getConfig() {
    return {
      baseUrl: el("baseUrl").value.trim() || "https://127.0.0.1:27124",
      vault: el("vault").value.trim() || "blog",
      apiKey: el("apiKey").value.trim()
    };
  }
  function openApiUrl() {
    const config = getConfig();
    window.open(config.baseUrl, "_blank");
    showResult(
      "cert-result",
      `\u5DF2\u5728\u65B0\u6807\u7B7E\u9875\u6253\u5F00 ${config.baseUrl}

\u5982\u679C\u770B\u5230\u8BC1\u4E66\u8B66\u544A\uFF1A
1. \u70B9\u51FB"\u9AD8\u7EA7"
2. \u70B9\u51FB"\u7EE7\u7EED\u8BBF\u95EE"
3. \u5E94\u8BE5\u770B\u5230 API \u6B22\u8FCE\u9875\u9762
4. \u7136\u540E\u56DE\u5230\u8FD9\u91CC\u7EE7\u7EED\u6D4B\u8BD5`,
      "info"
    );
  }
  async function testConnection() {
    const config = getConfig();
    const url = `${config.baseUrl.replace(/\/$/, "")}/`;
    showResult("connection-result", "\u6B63\u5728\u6D4B\u8BD5\u8FDE\u63A5...", "info");
    try {
      const response = await fetch(url, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${config.apiKey}`
        }
      });
      const text = await response.text();
      showResult(
        "connection-result",
        `\u2705 \u8FDE\u63A5\u6210\u529F\uFF01

\u72B6\u6001\u7801: ${response.status}
\u54CD\u5E94: ${text.substring(0, 200)}${text.length > 200 ? "..." : ""}`,
        "success"
      );
    } catch (error) {
      showResult(
        "connection-result",
        `\u274C \u8FDE\u63A5\u5931\u8D25

\u9519\u8BEF: ${error.message}

\u53EF\u80FD\u7684\u539F\u56E0\uFF1A
1. Obsidian \u672A\u8FD0\u884C
2. Local REST API \u63D2\u4EF6\u672A\u542F\u7528
3. \u8BC1\u4E66\u672A\u4FE1\u4EFB\uFF08\u8BF7\u5148\u5B8C\u6210\u6B65\u9AA4 1\uFF09
4. \u5730\u5740\u6216\u7AEF\u53E3\u9519\u8BEF`,
        "error"
      );
    }
  }
  async function testWrite() {
    const config = getConfig();
    const testPath = "Test/connection-test.md";
    const testContent = `# \u8FDE\u63A5\u6D4B\u8BD5

\u6D4B\u8BD5\u65F6\u95F4: ${(/* @__PURE__ */ new Date()).toLocaleString()}

\u8FD9\u662F\u4E00\u4E2A\u6D4B\u8BD5\u6587\u4EF6\u3002`;
    const encodedPath = testPath.split("/").map((part) => encodeURIComponent(part)).join("/");
    const url = `${config.baseUrl.replace(/\/$/, "")}/vault/${encodeURIComponent(config.vault)}/${encodedPath}`;
    const apiKeyPreview = config.apiKey ? `${config.apiKey.substring(0, 8)}...` : "(\u7A7A)";
    console.log("\u6D4B\u8BD5\u5199\u5165\u914D\u7F6E:", {
      baseUrl: config.baseUrl,
      vault: config.vault,
      apiKey: apiKeyPreview,
      url,
      hasApiKey: !!config.apiKey,
      apiKeyLength: config.apiKey?.length || 0
    });
    showResult("write-result", `\u6B63\u5728\u6D4B\u8BD5\u5199\u5165...

\u8C03\u8BD5\u4FE1\u606F:
Vault: ${config.vault}
API Key: ${apiKeyPreview} (\u957F\u5EA6: ${config.apiKey?.length || 0})`, "info");
    try {
      const response = await fetch(url, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${config.apiKey}`,
          "Content-Type": "text/markdown; charset=utf-8"
        },
        body: testContent
      });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }
      showResult(
        "write-result",
        `\u2705 \u5199\u5165\u6210\u529F\uFF01

\u6587\u4EF6\u8DEF\u5F84: ${testPath}
Vault: ${config.vault}

\u8BF7\u5728 Obsidian \u4E2D\u68C0\u67E5\u6587\u4EF6\u662F\u5426\u521B\u5EFA\u6210\u529F\u3002`,
        "success"
      );
    } catch (error) {
      showResult(
        "write-result",
        `\u274C \u5199\u5165\u5931\u8D25

\u9519\u8BEF: ${error.message}

\u8C03\u8BD5\u4FE1\u606F:
- Vault: ${config.vault}
- API Key \u957F\u5EA6: ${config.apiKey?.length || 0}
- API Key \u524D\u7F00: ${apiKeyPreview}

\u8BF7\u68C0\u67E5\uFF1A
1. Vault \u540D\u79F0\u662F\u5426\u6B63\u786E
2. API Key \u662F\u5426\u6B63\u786E
3. \u662F\u5426\u6709\u5199\u5165\u6743\u9650`,
        "error"
      );
    }
  }
  async function testFromBackground() {
    showResult("background-result", "\u6B63\u5728\u4ECE\u540E\u53F0\u811A\u672C\u6D4B\u8BD5...", "info");
    try {
      const response = await chrome.runtime.sendMessage({
        type: "TEST_CONNECTION"
      });
      showResult("background-result", `\u540E\u53F0\u811A\u672C\u54CD\u5E94:
${JSON.stringify(response, null, 2)}`, response.success ? "success" : "error");
    } catch (error) {
      showResult("background-result", `\u274C \u540E\u53F0\u811A\u672C\u6D4B\u8BD5\u5931\u8D25

${error.message}`, "error");
    }
  }
  async function debugApiKey() {
    showResult("debug-result", "\u6B63\u5728\u68C0\u67E5 API Key...", "info");
    try {
      const inputApiKey = el("apiKey").value.trim();
      const { options } = await chrome.storage.sync.get("options");
      const savedApiKey = options?.rest?.apiKey || "";
      const match = inputApiKey === savedApiKey;
      const inputPreview = inputApiKey ? `${inputApiKey.substring(0, 8)}...${inputApiKey.substring(inputApiKey.length - 4)}` : "(\u7A7A)";
      const savedPreview = savedApiKey ? `${savedApiKey.substring(0, 8)}...${savedApiKey.substring(savedApiKey.length - 4)}` : "(\u7A7A)";
      showResult(
        "debug-result",
        `\u{1F50D} API Key \u8C03\u8BD5\u4FE1\u606F:

\u8F93\u5165\u6846\u4E2D\u7684 API Key:
  - \u9884\u89C8: ${inputPreview}
  - \u957F\u5EA6: ${inputApiKey.length}
  - \u662F\u5426\u4E3A\u7A7A: ${!inputApiKey}

\u6269\u5C55\u914D\u7F6E\u4E2D\u7684 API Key:
  - \u9884\u89C8: ${savedPreview}
  - \u957F\u5EA6: ${savedApiKey.length}
  - \u662F\u5426\u4E3A\u7A7A: ${!savedApiKey}

\u4E24\u8005\u662F\u5426\u4E00\u81F4: ${match ? "\u2705 \u662F" : "\u274C \u5426"}

` + (match ? "\u2705 API Key \u4E00\u81F4\uFF0C\u5982\u679C\u4ECD\u7136 401\uFF0C\u8BF7\u68C0\u67E5 Obsidian \u63D2\u4EF6\u8BBE\u7F6E" : '\u26A0\uFE0F API Key \u4E0D\u4E00\u81F4\uFF01\u8BF7\u70B9\u51FB"\u4ECE\u6269\u5C55\u52A0\u8F7D\u914D\u7F6E"\u6216\u91CD\u65B0\u8F93\u5165\u6B63\u786E\u7684 API Key'),
        match ? "success" : "error"
      );
    } catch (error) {
      showResult("debug-result", `\u274C \u8C03\u8BD5\u5931\u8D25: ${error.message}`, "error");
    }
  }
  function showCurlCommand() {
    const config = getConfig();
    const testPath = "Test/connection-test.md";
    const encodedPath = testPath.split("/").map(encodeURIComponent).join("/");
    const url = `${config.baseUrl}/vault/${encodeURIComponent(config.vault)}/${encodedPath}`;
    const content = `# \u8FDE\u63A5\u6D4B\u8BD5

\u8FD9\u662F\u4E00\u4E2A\u6D4B\u8BD5\u6587\u4EF6\uFF0C\u521B\u5EFA\u4E8E ${(/* @__PURE__ */ new Date()).toISOString()}
`;
    const curlCommand = `curl -X PUT '${url}' \\
  -H 'Authorization: Bearer ${config.apiKey}' \\
  -H 'Content-Type: text/markdown; charset=utf-8' \\
  -d '${content.replace(/'/g, "'\\''")}'`;
    const curlInsecure = `curl -X PUT '${url}' \\
  -H 'Authorization: Bearer ${config.apiKey}' \\
  -H 'Content-Type: text/markdown; charset=utf-8' \\
  -k \\
  -d '${content.replace(/'/g, "'\\''")}'`;
    const message = `\u{1F4CB} \u8BF7\u5728\u7EC8\u7AEF\u4E2D\u8FD0\u884C\u4EE5\u4E0B\u547D\u4EE4\u6D4B\u8BD5\uFF1A

\u5982\u679C\u4F7F\u7528 HTTPS\uFF08\u9700\u8981\u4FE1\u4EFB\u8BC1\u4E66\uFF09\uFF1A
${curlCommand}

\u5982\u679C\u4F7F\u7528 HTTPS \u4F46\u60F3\u8DF3\u8FC7\u8BC1\u4E66\u9A8C\u8BC1\uFF08\u6DFB\u52A0 -k \u53C2\u6570\uFF09\uFF1A
${curlInsecure}

\u5982\u679C\u6210\u529F\uFF0C\u8BF4\u660E API Key \u548C\u670D\u52A1\u7AEF\u90FD\u6B63\u5E38\uFF0C\u95EE\u9898\u5728\u4E8E\u6D4F\u89C8\u5668/\u6269\u5C55\u7684 fetch \u5B9E\u73B0\u3002
\u5982\u679C\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u8FD4\u56DE\u7684\u9519\u8BEF\u4FE1\u606F\u3002`;
    showResult("curl-result", message, "info");
    navigator.clipboard.writeText(curlInsecure).then(() => {
      console.log("curl \u547D\u4EE4\u5DF2\u590D\u5236\u5230\u526A\u8D34\u677F\uFF08\u5E26 -k \u53C2\u6570\u7684\u7248\u672C\uFF09");
    }).catch((err) => {
      console.error("\u590D\u5236\u5931\u8D25:", err);
    });
  }
  window.addEventListener("DOMContentLoaded", () => {
    loadConfig();
    el("btnLoad").addEventListener("click", loadConfig);
    el("btnSave").addEventListener("click", saveTestConfig);
    el("btnDebug").addEventListener("click", debugApiKey);
    el("btnOpen").addEventListener("click", openApiUrl);
    el("btnTestConn").addEventListener("click", testConnection);
    el("btnTestWrite").addEventListener("click", testWrite);
    el("btnShowCurl").addEventListener("click", showCurlCommand);
    el("btnTestBG").addEventListener("click", testFromBackground);
  });
})();
//# sourceMappingURL=test-connection.js.map
