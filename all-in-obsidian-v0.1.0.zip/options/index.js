"use strict";
(() => {
  // src/i18n/locales.ts
  var messages = {
    "zh-CN": {
      // General
      extensionName: "All in Obsidian",
      extensionSubtitle: "\u914D\u7F6E\u4F60\u7684\u526A\u85CF\u63D2\u4EF6\uFF0C\u8BA9\u5185\u5BB9\u7BA1\u7406\u66F4\u667A\u80FD",
      // Settings page sections
      settingsTitle: "\u8BBE\u7F6E",
      languageSettings: "\u8BED\u8A00\u8BBE\u7F6E",
      languageLabel: "\u754C\u9762\u8BED\u8A00",
      languageHint: "\u{1F4A1} \u9009\u62E9\u4F60\u559C\u6B22\u7684\u754C\u9762\u8BED\u8A00",
      // API Configuration
      apiConfigTitle: "Obsidian Local REST API",
      apiConfigHint: "\u{1F4A1} \u914D\u7F6E HTTPS \u548C HTTP \u4E24\u4E2A URL\uFF0C\u6269\u5C55\u4F1A\u667A\u80FD\u9009\u62E9\u53EF\u7528\u7684\u8FDE\u63A5\u65B9\u5F0F",
      httpsUrlLabel: "HTTPS URL",
      httpsUrlHint: "\u901A\u5E38\u7AEF\u53E3\u4E3A 27124\uFF0C\u9002\u7528\u4E8E\u5B89\u5168\u8FDE\u63A5",
      httpUrlLabel: "HTTP URL",
      httpUrlHint: "\u901A\u5E38\u7AEF\u53E3\u4E3A 27123\uFF0C\u4F5C\u4E3A\u5907\u7528\u8FDE\u63A5",
      vaultNameLabel: "Vault \u540D\u79F0",
      vaultNamePlaceholder: "YourVault",
      vaultNameHint: "\u4F60\u7684 Obsidian \u4ED3\u5E93\u540D\u79F0",
      apiKeyLabel: "API Key",
      apiKeyPlaceholder: "\u4F60\u7684 API \u5BC6\u94A5",
      apiKeyHint: "\u5728 Obsidian Local REST API \u63D2\u4EF6\u8BBE\u7F6E\u4E2D\u83B7\u53D6",
      // Template Configuration
      templateConfigTitle: "\u8DEF\u5F84\u6A21\u677F\u914D\u7F6E",
      articleTemplateLabel: "\u6587\u7AE0\u8DEF\u5F84\u6A21\u677F",
      articleTemplateHint: "\u7528\u4E8E\u5B8C\u6574\u7684\u7F51\u9875\u6587\u7AE0\u526A\u85CF",
      fragmentTemplateLabel: "\u7247\u6BB5\u8DEF\u5F84\u6A21\u677F",
      fragmentTemplateHint: "\u7528\u4E8E\u9009\u4E2D\u6587\u672C\u7247\u6BB5\u7684\u5FEB\u901F\u526A\u85CF",
      aiTemplateLabel: "AI \u5BF9\u8BDD\u8DEF\u5F84\u6A21\u677F",
      aiTemplateHint: "\u7528\u4E8E AI \u804A\u5929\u5BF9\u8BDD\u7684\u526A\u85CF",
      availableVariables: "\u53EF\u7528\u53D8\u91CF\uFF1A",
      // Domain Mapping
      domainMappingTitle: "\u57DF\u540D\u6620\u5C04\u914D\u7F6E",
      domainMappingHint: "\u{1F4A1} \u4E3A\u7279\u5B9A\u57DF\u540D\u81EA\u5B9A\u4E49\u6587\u4EF6\u5939\u540D\u79F0",
      domainLabel: "\u57DF\u540D",
      folderNameLabel: "\u6587\u4EF6\u5939\u540D\u79F0",
      addMappingButton: "+ \u6DFB\u52A0\u6620\u5C04",
      // Config Transfer
      configTransferTitle: "\u914D\u7F6E\u540C\u6B65",
      configTransferHint: "\u{1F4A1} \u4E00\u952E\u590D\u5236\u4E0E\u5BFC\u5165\uFF0C\u8DE8\u6D4F\u89C8\u5668\u540C\u6B65\u66F4\u8F7B\u677E",
      copyConfigButton: "\u590D\u5236\u914D\u7F6E",
      importConfigButton: "\u5BFC\u5165\u5E76\u4FDD\u5B58",
      configTransferNote: "\u64CD\u4F5C\u4F1A\u4F7F\u7528\u7CFB\u7EDF\u526A\u8D34\u677F\uFF0C\u8BF7\u786E\u8BA4\u6D4F\u89C8\u5668\u5DF2\u6388\u6743\u8BBF\u95EE\u540E\u518D\u7EE7\u7EED\u3002",
      copyConfigSuccess: "\u2705 \u914D\u7F6E\u5DF2\u590D\u5236\u5230\u526A\u8D34\u677F",
      importSuccess: "\u2705 \u914D\u7F6E\u5DF2\u5BFC\u5165\u5E76\u4FDD\u5B58",
      importParseFailed: "\u274C \u914D\u7F6E\u89E3\u6790\u5931\u8D25",
      emptyImportError: "\u526A\u8D34\u677F\u4E3A\u7A7A\uFF0C\u8BF7\u5148\u590D\u5236\u914D\u7F6E",
      clipboardUnavailable: "\u65E0\u6CD5\u8BBF\u95EE\u526A\u8D34\u677F\uFF0C\u8BF7\u624B\u52A8\u590D\u5236",
      clipboardReadUnavailable: "\u65E0\u6CD5\u8BFB\u53D6\u526A\u8D34\u677F\uFF0C\u8BF7\u5728\u6D4F\u89C8\u5668\u8BBE\u7F6E\u4E2D\u6388\u4E88\u6743\u9650\u540E\u91CD\u8BD5",
      invalidTaxonomy: "\u5206\u7C7B\u5668 Taxonomy \u4E0D\u662F\u6709\u6548\u7684 JSON",
      // AI Chat Configuration
      aiChatConfigTitle: "AI \u5BF9\u8BDD\u526A\u85CF\u914D\u7F6E",
      aiChatConfigHint: "\u{1F4A1} \u81EA\u5B9A\u4E49 AI \u5BF9\u8BDD\u7684\u526A\u85CF\u683C\u5F0F\u548C\u5185\u5BB9",
      includeTimestampsLabel: "\u5305\u542B\u6D88\u606F\u65F6\u95F4\u6233",
      includeTimestampsHint: "\u5728\u6BCF\u6761\u6D88\u606F\u540E\u663E\u793A\u53D1\u9001\u65F6\u95F4\uFF08\u5982\u679C\u53EF\u7528\uFF09",
      userNameLabel: "\u7528\u6237\u540D\u79F0",
      userNamePlaceholder: "USER",
      userNameHint: '\u81EA\u5B9A\u4E49\u7528\u6237\u6D88\u606F\u7684\u663E\u793A\u540D\u79F0\uFF0C\u9ED8\u8BA4\u4E3A "USER"',
      // Deep Research Configuration
      deepResearchConfigTitle: "Gemini Deep Research \u914D\u7F6E",
      deepResearchConfigHint: "\u{1F4A1} \u81EA\u5B9A\u4E49 Deep Research \u62A5\u544A\u7684\u6355\u6349\u65B9\u5F0F",
      pureModeLabel: "\u63D0\u7EAF\u6A21\u5F0F\uFF08\u53EA\u6355\u6349\u62A5\u544A\u5185\u5BB9\uFF09",
      pureModeHint: "\u542F\u7528\u540E\uFF0C\u53EA\u6355\u6349 Deep Research \u62A5\u544A\u5185\u5BB9\uFF0C\u4E0D\u5305\u542B\u5BF9\u8BDD\u6D88\u606F",
      multipleReportsInfo: "\u2139\uFE0F \u5173\u4E8E\u591A\u4E2A\u62A5\u544A: Gemini \u4E00\u6B21\u53EA\u80FD\u663E\u793A\u4E00\u4E2A\u5B8C\u6574\u62A5\u544A\u3002\u5982\u9700\u4FDD\u5B58\u591A\u4E2A\u62A5\u544A\uFF0C\u8BF7\u5206\u522B\u6253\u5F00\u6BCF\u4E2A\u62A5\u544A\u5E76\u70B9\u51FB\u526A\u85CF\u3002",
      // Classifier Configuration
      classifierConfigTitle: "\u667A\u80FD\u5206\u7C7B\u914D\u7F6E\uFF08\u53EF\u9009\uFF09",
      classifierConfigHint: "\u{1F4A1} \u4F7F\u7528 LLM \u81EA\u52A8\u5206\u7C7B\u548C\u6807\u8BB0\u526A\u85CF\u5185\u5BB9",
      enableClassifierLabel: "\u542F\u7528\u667A\u80FD\u5206\u7C7B",
      providerLabel: "LLM \u63D0\u4F9B\u5546",
      endpointLabel: "API \u7AEF\u70B9",
      endpointPlaceholder: "http://localhost:11434/api/chat",
      modelLabel: "\u6A21\u578B\u540D\u79F0",
      modelPlaceholder: "llama3.1",
      taxonomyLabel: "\u5206\u7C7B\u4F53\u7CFB",
      taxonomyHint: "\u5B9A\u4E49\u5206\u7C7B\u4F53\u7CFB\uFF0CJSON \u683C\u5F0F",
      // Buttons
      saveButton: "\u{1F4BE} \u4FDD\u5B58\u914D\u7F6E",
      diagnoseButton: "\u{1F50D} \u8BCA\u65AD\u914D\u7F6E",
      fixButton: "\u{1F527} \u4FEE\u590D\u914D\u7F6E",
      reloadButton: "\u{1F504} \u91CD\u65B0\u52A0\u8F7D",
      // Messages
      saveSuccess: "\u2705 \u914D\u7F6E\u5DF2\u4FDD\u5B58",
      saveFailed: "\u274C \u4FDD\u5B58\u5931\u8D25",
      configFixed: "\u2705 \u914D\u7F6E\u5DF2\u4FEE\u590D\u5E76\u4FDD\u5B58",
      fixFailed: "\u274C \u4FEE\u590D\u5931\u8D25",
      reloadPrompt: "\u8BF7\u91CD\u65B0\u52A0\u8F7D\u9875\u9762\u67E5\u770B\u4FEE\u590D\u540E\u7684\u914D\u7F6E",
      // Diagnosis
      diagnosisTitle: "\u914D\u7F6E\u8BCA\u65AD",
      // Notifications
      clipSuccess: "\u5DF2\u4FDD\u5B58\u5230 Obsidian",
      clipFailed: "\u526A\u85CF\u5931\u8D25",
      extractionFailed: "\u5185\u5BB9\u63D0\u53D6\u5931\u8D25",
      connectionFailed: "\u8FDE\u63A5\u5931\u8D25",
      scriptInjectionFailed: "\u65E0\u6CD5\u6CE8\u5165\u5185\u5BB9\u811A\u672C",
      // Context Menu
      clipFullPage: "\u526A\u85CF\u6574\u4E2A\u9875\u9762\u5230 Obsidian",
      clipSelection: "\u2702\uFE0F \u526A\u85CF\u9009\u4E2D\u5185\u5BB9\u5230 Obsidian",
      // Dialog
      clipDialogTitle: "\u{1F4CE} \u526A\u85CF\u9009\u4E2D\u5185\u5BB9",
      commentLabel: "\u{1F4AD} \u6DFB\u52A0\u4F60\u7684\u8BC4\u8BBA\uFF08\u53EF\u9009\uFF09\uFF1A",
      commentPlaceholder: "\u5728\u8FD9\u91CC\u5199\u4E0B\u4F60\u7684\u60F3\u6CD5\u3001\u7B14\u8BB0\u6216\u8BC4\u8BBA...",
      cancelButton: "\u53D6\u6D88",
      clipButton: "\u2702\uFE0F \u526A\u85CF",
      // Multi-Vault
      additionalVaultsTitle: "\u989D\u5916\u4ED3\u5E93",
      additionalVaultsHint: "\u{1F4A1} \u6DFB\u52A0\u66F4\u591A\u4ED3\u5E93\uFF0C\u901A\u8FC7\u8DEF\u7531\u89C4\u5219\u81EA\u52A8\u5206\u914D\u5185\u5BB9",
      addVaultButton: "+ \u6DFB\u52A0\u4ED3\u5E93",
      multiVaultNameLabel: "\u4ED3\u5E93\u540D\u79F0",
      multiVaultNamePlaceholder: "\u6211\u7684\u7B14\u8BB0\u4ED3\u5E93",
      deleteVaultButton: "\u5220\u9664",
      defaultVaultBadge: "\u9ED8\u8BA4\u4ED3\u5E93",
      // Routing Rules
      routingRulesTitle: "\u8DEF\u7531\u89C4\u5219",
      routingRulesHint: "\u{1F4A1} \u6839\u636E\u57DF\u540D\u3001\u5173\u952E\u8BCD\u6216 URL \u6A21\u5F0F\u81EA\u52A8\u9009\u62E9\u76EE\u6807\u4ED3\u5E93",
      addRuleButton: "+ \u6DFB\u52A0\u89C4\u5219",
      ruleTypeLabel: "\u89C4\u5219\u7C7B\u578B",
      ruleTypeDomain: "\u57DF\u540D\u5339\u914D",
      ruleTypeKeyword: "\u5173\u952E\u8BCD\u5339\u914D",
      ruleTypeUrlPattern: "URL \u6A21\u5F0F",
      rulePatternLabel: "\u5339\u914D\u6A21\u5F0F",
      rulePatternPlaceholder: "\u4F8B\u5982\uFF1Aexample.com \u6216 \u5173\u952E\u8BCD1,\u5173\u952E\u8BCD2",
      ruleTargetVaultLabel: "\u76EE\u6807\u4ED3\u5E93",
      rulePriorityLabel: "\u4F18\u5148\u7EA7",
      ruleDescriptionLabel: "\u89C4\u5219\u63CF\u8FF0",
      ruleDescriptionPlaceholder: "\u4F8B\u5982\uFF1A\u6280\u672F\u6587\u7AE0\u4FDD\u5B58\u5230\u5DE5\u4F5C\u4ED3\u5E93",
      ruleEnabledLabel: "\u542F\u7528",
      deleteRuleButton: "\u5220\u9664",
      editRuleButton: "\u7F16\u8F91"
    },
    "en": {
      // General
      extensionName: "All in Obsidian",
      extensionSubtitle: "Configure your clipper for smarter content management",
      // Settings page sections
      settingsTitle: "Settings",
      languageSettings: "Language Settings",
      languageLabel: "Interface Language",
      languageHint: "\u{1F4A1} Choose your preferred interface language",
      // API Configuration
      apiConfigTitle: "Obsidian Local REST API",
      apiConfigHint: "\u{1F4A1} Configure both HTTPS and HTTP URLs, the extension will intelligently choose the available connection",
      httpsUrlLabel: "HTTPS URL",
      httpsUrlHint: "Usually port 27124, for secure connections",
      httpUrlLabel: "HTTP URL",
      httpUrlHint: "Usually port 27123, as fallback connection",
      vaultNameLabel: "Vault Name",
      vaultNamePlaceholder: "YourVault",
      vaultNameHint: "Your Obsidian vault name",
      apiKeyLabel: "API Key",
      apiKeyPlaceholder: "Your API key",
      apiKeyHint: "Get it from Obsidian Local REST API plugin settings",
      // Template Configuration
      templateConfigTitle: "Path Template Configuration",
      articleTemplateLabel: "Article Path Template",
      articleTemplateHint: "For full webpage article clipping",
      fragmentTemplateLabel: "Fragment Path Template",
      fragmentTemplateHint: "For quick clipping of selected text fragments",
      aiTemplateLabel: "AI Chat Path Template",
      aiTemplateHint: "For AI chat conversation clipping",
      availableVariables: "Available variables:",
      // Domain Mapping
      domainMappingTitle: "Domain Mapping Configuration",
      domainMappingHint: "\u{1F4A1} Customize folder names for specific domains",
      domainLabel: "Domain",
      folderNameLabel: "Folder Name",
      addMappingButton: "+ Add Mapping",
      // Config Transfer
      configTransferTitle: "Configuration Sync",
      configTransferHint: "\u{1F4A1} Copy once and import anywhere to keep browsers in sync.",
      copyConfigButton: "Copy configuration",
      importConfigButton: "Import from clipboard",
      configTransferNote: "These actions use the system clipboard\u2014ensure the browser is allowed to access it.",
      copyConfigSuccess: "\u2705 Configuration copied to clipboard",
      importSuccess: "\u2705 Configuration imported and saved",
      importParseFailed: "\u274C Failed to parse configuration",
      emptyImportError: "Clipboard is empty, please copy a configuration first",
      clipboardUnavailable: "Clipboard unavailable, please copy manually",
      clipboardReadUnavailable: "Unable to read the clipboard. Grant clipboard permissions and try again.",
      invalidTaxonomy: "Classifier taxonomy must be valid JSON",
      // AI Chat Configuration
      aiChatConfigTitle: "AI Chat Clipping Configuration",
      aiChatConfigHint: "\u{1F4A1} Customize the format and content of AI chat clips",
      includeTimestampsLabel: "Include message timestamps",
      includeTimestampsHint: "Show send time after each message (if available)",
      userNameLabel: "User Name",
      userNamePlaceholder: "USER",
      userNameHint: 'Customize the display name for user messages, default is "USER"',
      // Deep Research Configuration
      deepResearchConfigTitle: "Gemini Deep Research Configuration",
      deepResearchConfigHint: "\u{1F4A1} Customize how Deep Research reports are captured",
      pureModeLabel: "Pure Mode (capture report content only)",
      pureModeHint: "When enabled, only capture Deep Research report content, excluding conversation messages",
      multipleReportsInfo: "\u2139\uFE0F About multiple reports: Gemini can only display one complete report at a time. To save multiple reports, open each report separately and clip them.",
      // Classifier Configuration
      classifierConfigTitle: "Smart Classification Configuration (Optional)",
      classifierConfigHint: "\u{1F4A1} Use LLM to automatically classify and tag clipped content",
      enableClassifierLabel: "Enable Smart Classification",
      providerLabel: "LLM Provider",
      endpointLabel: "API Endpoint",
      endpointPlaceholder: "http://localhost:11434/api/chat",
      modelLabel: "Model Name",
      modelPlaceholder: "llama3.1",
      taxonomyLabel: "Taxonomy",
      taxonomyHint: "Define classification taxonomy in JSON format",
      // Buttons
      saveButton: "\u{1F4BE} Save Configuration",
      diagnoseButton: "\u{1F50D} Diagnose Configuration",
      fixButton: "\u{1F527} Fix Configuration",
      reloadButton: "\u{1F504} Reload",
      // Messages
      saveSuccess: "\u2705 Configuration saved",
      saveFailed: "\u274C Save failed",
      configFixed: "\u2705 Configuration fixed and saved",
      fixFailed: "\u274C Fix failed",
      reloadPrompt: "Please reload the page to see the fixed configuration",
      // Diagnosis
      diagnosisTitle: "Configuration Diagnosis",
      // Notifications
      clipSuccess: "Saved to Obsidian",
      clipFailed: "Clip failed",
      extractionFailed: "Content extraction failed",
      connectionFailed: "Connection failed",
      scriptInjectionFailed: "Failed to inject content script",
      // Context Menu
      clipFullPage: "Clip full page to Obsidian",
      clipSelection: "\u2702\uFE0F Clip selection to Obsidian",
      // Dialog
      clipDialogTitle: "\u{1F4CE} Clip Selection",
      commentLabel: "\u{1F4AD} Add your comment (optional):",
      commentPlaceholder: "Write your thoughts, notes or comments here...",
      cancelButton: "Cancel",
      clipButton: "\u2702\uFE0F Clip",
      // Multi-Vault
      additionalVaultsTitle: "Additional Vaults",
      additionalVaultsHint: "\u{1F4A1} Add more vaults and automatically route content using rules",
      addVaultButton: "+ Add Vault",
      multiVaultNameLabel: "Vault Name",
      multiVaultNamePlaceholder: "My Notes Vault",
      deleteVaultButton: "Delete",
      defaultVaultBadge: "Default Vault",
      // Routing Rules
      routingRulesTitle: "Routing Rules",
      routingRulesHint: "\u{1F4A1} Automatically select target vault based on domain, keywords, or URL patterns",
      addRuleButton: "+ Add Rule",
      ruleTypeLabel: "Rule Type",
      ruleTypeDomain: "Domain Match",
      ruleTypeKeyword: "Keyword Match",
      ruleTypeUrlPattern: "URL Pattern",
      rulePatternLabel: "Match Pattern",
      rulePatternPlaceholder: "e.g., example.com or keyword1,keyword2",
      ruleTargetVaultLabel: "Target Vault",
      rulePriorityLabel: "Priority",
      ruleDescriptionLabel: "Description",
      ruleDescriptionPlaceholder: "e.g., Save tech articles to work vault",
      ruleEnabledLabel: "Enabled",
      deleteRuleButton: "Delete",
      editRuleButton: "Edit"
    },
    "ja": {
      // General
      extensionName: "All in Obsidian",
      extensionSubtitle: "\u30AF\u30EA\u30C3\u30D1\u30FC\u3092\u8A2D\u5B9A\u3057\u3066\u3001\u3088\u308A\u30B9\u30DE\u30FC\u30C8\u306A\u30B3\u30F3\u30C6\u30F3\u30C4\u7BA1\u7406\u3092\u5B9F\u73FE",
      // Settings page sections
      settingsTitle: "\u8A2D\u5B9A",
      languageSettings: "\u8A00\u8A9E\u8A2D\u5B9A",
      languageLabel: "\u30A4\u30F3\u30BF\u30FC\u30D5\u30A7\u30FC\u30B9\u8A00\u8A9E",
      languageHint: "\u{1F4A1} \u304A\u597D\u307F\u306E\u30A4\u30F3\u30BF\u30FC\u30D5\u30A7\u30FC\u30B9\u8A00\u8A9E\u3092\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044",
      // API Configuration
      apiConfigTitle: "Obsidian Local REST API",
      apiConfigHint: "\u{1F4A1} HTTPS \u3068 HTTP \u306E\u4E21\u65B9\u306E URL \u3092\u8A2D\u5B9A\u3059\u308B\u3068\u3001\u62E1\u5F35\u6A5F\u80FD\u304C\u5229\u7528\u53EF\u80FD\u306A\u63A5\u7D9A\u3092\u81EA\u52D5\u7684\u306B\u9078\u629E\u3057\u307E\u3059",
      httpsUrlLabel: "HTTPS URL",
      httpsUrlHint: "\u901A\u5E38\u306F\u30DD\u30FC\u30C8 27124\u3001\u30BB\u30AD\u30E5\u30A2\u63A5\u7D9A\u7528",
      httpUrlLabel: "HTTP URL",
      httpUrlHint: "\u901A\u5E38\u306F\u30DD\u30FC\u30C8 27123\u3001\u30D5\u30A9\u30FC\u30EB\u30D0\u30C3\u30AF\u63A5\u7D9A\u7528",
      vaultNameLabel: "Vault \u540D",
      vaultNamePlaceholder: "YourVault",
      vaultNameHint: "Obsidian \u306E Vault \u540D",
      apiKeyLabel: "API \u30AD\u30FC",
      apiKeyPlaceholder: "API \u30AD\u30FC",
      apiKeyHint: "Obsidian Local REST API \u30D7\u30E9\u30B0\u30A4\u30F3\u306E\u8A2D\u5B9A\u304B\u3089\u53D6\u5F97",
      // Template Configuration
      templateConfigTitle: "\u30D1\u30B9\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u8A2D\u5B9A",
      articleTemplateLabel: "\u8A18\u4E8B\u30D1\u30B9\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
      articleTemplateHint: "\u5B8C\u5168\u306A\u30A6\u30A7\u30D6\u30DA\u30FC\u30B8\u8A18\u4E8B\u306E\u30AF\u30EA\u30C3\u30D4\u30F3\u30B0\u7528",
      fragmentTemplateLabel: "\u30D5\u30E9\u30B0\u30E1\u30F3\u30C8\u30D1\u30B9\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
      fragmentTemplateHint: "\u9078\u629E\u3057\u305F\u30C6\u30AD\u30B9\u30C8\u30D5\u30E9\u30B0\u30E1\u30F3\u30C8\u306E\u9AD8\u901F\u30AF\u30EA\u30C3\u30D4\u30F3\u30B0\u7528",
      aiTemplateLabel: "AI \u30C1\u30E3\u30C3\u30C8\u30D1\u30B9\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
      aiTemplateHint: "AI \u30C1\u30E3\u30C3\u30C8\u4F1A\u8A71\u306E\u30AF\u30EA\u30C3\u30D4\u30F3\u30B0\u7528",
      availableVariables: "\u5229\u7528\u53EF\u80FD\u306A\u5909\u6570\uFF1A",
      // Domain Mapping
      domainMappingTitle: "\u30C9\u30E1\u30A4\u30F3\u30DE\u30C3\u30D4\u30F3\u30B0\u8A2D\u5B9A",
      domainMappingHint: "\u{1F4A1} \u7279\u5B9A\u306E\u30C9\u30E1\u30A4\u30F3\u306E\u30D5\u30A9\u30EB\u30C0\u540D\u3092\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA",
      domainLabel: "\u30C9\u30E1\u30A4\u30F3",
      folderNameLabel: "\u30D5\u30A9\u30EB\u30C0\u540D",
      addMappingButton: "+ \u30DE\u30C3\u30D4\u30F3\u30B0\u3092\u8FFD\u52A0",
      // Config Transfer
      configTransferTitle: "\u8A2D\u5B9A\u306E\u540C\u671F",
      configTransferHint: "\u{1F4A1} \u4E00\u5EA6\u30B3\u30D4\u30FC\u3059\u308C\u3070\u3001\u3069\u306E\u30D6\u30E9\u30A6\u30B6\u3067\u3082\u3059\u3050\u306B\u540C\u671F\u3067\u304D\u307E\u3059\u3002",
      copyConfigButton: "\u8A2D\u5B9A\u3092\u30B3\u30D4\u30FC",
      importConfigButton: "\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u304B\u3089\u4FDD\u5B58",
      configTransferNote: "\u64CD\u4F5C\u3067\u306F\u30B7\u30B9\u30C6\u30E0\u306E\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u3092\u4F7F\u7528\u3057\u307E\u3059\u3002\u30D6\u30E9\u30A6\u30B6\u306B\u6A29\u9650\u304C\u4ED8\u4E0E\u3055\u308C\u3066\u3044\u308B\u304B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
      copyConfigSuccess: "\u2705 \u8A2D\u5B9A\u3092\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u306B\u30B3\u30D4\u30FC\u3057\u307E\u3057\u305F",
      importSuccess: "\u2705 \u8A2D\u5B9A\u3092\u30A4\u30F3\u30DD\u30FC\u30C8\u3057\u3066\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      importParseFailed: "\u274C \u8A2D\u5B9A\u306E\u89E3\u6790\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      emptyImportError: "\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u304C\u7A7A\u3067\u3059\u3002\u5148\u306B\u8A2D\u5B9A\u3092\u30B3\u30D4\u30FC\u3057\u3066\u304F\u3060\u3055\u3044",
      clipboardUnavailable: "\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u306B\u30A2\u30AF\u30BB\u30B9\u3067\u304D\u307E\u305B\u3093\u3002\u624B\u52D5\u3067\u30B3\u30D4\u30FC\u3057\u3066\u304F\u3060\u3055\u3044",
      clipboardReadUnavailable: "\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u3092\u8AAD\u307F\u53D6\u308C\u307E\u305B\u3093\u3002\u30D6\u30E9\u30A6\u30B6\u3067\u6A29\u9650\u3092\u8A31\u53EF\u3057\u3066\u304B\u3089\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044",
      invalidTaxonomy: "\u5206\u985E\u5668\u306E\u30BF\u30AF\u30BD\u30CE\u30DF\u30FC\u306F\u6709\u52B9\u306A JSON \u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059",
      // AI Chat Configuration
      aiChatConfigTitle: "AI \u30C1\u30E3\u30C3\u30C8\u30AF\u30EA\u30C3\u30D7\u8A2D\u5B9A",
      aiChatConfigHint: "\u{1F4A1} AI \u30C1\u30E3\u30C3\u30C8\u30AF\u30EA\u30C3\u30D7\u306E\u5F62\u5F0F\u3068\u5185\u5BB9\u3092\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA",
      includeTimestampsLabel: "\u30E1\u30C3\u30BB\u30FC\u30B8\u306E\u30BF\u30A4\u30E0\u30B9\u30BF\u30F3\u30D7\u3092\u542B\u3081\u308B",
      includeTimestampsHint: "\u5404\u30E1\u30C3\u30BB\u30FC\u30B8\u306E\u5F8C\u306B\u9001\u4FE1\u6642\u523B\u3092\u8868\u793A\uFF08\u5229\u7528\u53EF\u80FD\u306A\u5834\u5408\uFF09",
      userNameLabel: "\u30E6\u30FC\u30B6\u30FC\u540D",
      userNamePlaceholder: "USER",
      userNameHint: '\u30E6\u30FC\u30B6\u30FC\u30E1\u30C3\u30BB\u30FC\u30B8\u306E\u8868\u793A\u540D\u3092\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA\u3001\u30C7\u30D5\u30A9\u30EB\u30C8\u306F "USER"',
      // Deep Research Configuration
      deepResearchConfigTitle: "Gemini Deep Research \u8A2D\u5B9A",
      deepResearchConfigHint: "\u{1F4A1} Deep Research \u30EC\u30DD\u30FC\u30C8\u306E\u30AD\u30E3\u30D7\u30C1\u30E3\u65B9\u6CD5\u3092\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA",
      pureModeLabel: "\u30D4\u30E5\u30A2\u30E2\u30FC\u30C9\uFF08\u30EC\u30DD\u30FC\u30C8\u5185\u5BB9\u306E\u307F\u30AD\u30E3\u30D7\u30C1\u30E3\uFF09",
      pureModeHint: "\u6709\u52B9\u306B\u3059\u308B\u3068\u3001Deep Research \u30EC\u30DD\u30FC\u30C8\u306E\u5185\u5BB9\u306E\u307F\u3092\u30AD\u30E3\u30D7\u30C1\u30E3\u3057\u3001\u4F1A\u8A71\u30E1\u30C3\u30BB\u30FC\u30B8\u306F\u542B\u3081\u307E\u305B\u3093",
      multipleReportsInfo: "\u2139\uFE0F \u8907\u6570\u306E\u30EC\u30DD\u30FC\u30C8\u306B\u3064\u3044\u3066: Gemini \u306F\u4E00\u5EA6\u306B 1 \u3064\u306E\u5B8C\u5168\u306A\u30EC\u30DD\u30FC\u30C8\u306E\u307F\u3092\u8868\u793A\u3067\u304D\u307E\u3059\u3002\u8907\u6570\u306E\u30EC\u30DD\u30FC\u30C8\u3092\u4FDD\u5B58\u3059\u308B\u306B\u306F\u3001\u5404\u30EC\u30DD\u30FC\u30C8\u3092\u500B\u5225\u306B\u958B\u3044\u3066\u30AF\u30EA\u30C3\u30D7\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
      // Classifier Configuration
      classifierConfigTitle: "\u30B9\u30DE\u30FC\u30C8\u5206\u985E\u8A2D\u5B9A\uFF08\u30AA\u30D7\u30B7\u30E7\u30F3\uFF09",
      classifierConfigHint: "\u{1F4A1} LLM \u3092\u4F7F\u7528\u3057\u3066\u30AF\u30EA\u30C3\u30D7\u3055\u308C\u305F\u30B3\u30F3\u30C6\u30F3\u30C4\u3092\u81EA\u52D5\u7684\u306B\u5206\u985E\u304A\u3088\u3073\u30BF\u30B0\u4ED8\u3051",
      enableClassifierLabel: "\u30B9\u30DE\u30FC\u30C8\u5206\u985E\u3092\u6709\u52B9\u306B\u3059\u308B",
      providerLabel: "LLM \u30D7\u30ED\u30D0\u30A4\u30C0\u30FC",
      endpointLabel: "API \u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8",
      endpointPlaceholder: "http://localhost:11434/api/chat",
      modelLabel: "\u30E2\u30C7\u30EB\u540D",
      modelPlaceholder: "llama3.1",
      taxonomyLabel: "\u5206\u985E\u4F53\u7CFB",
      taxonomyHint: "JSON \u5F62\u5F0F\u3067\u5206\u985E\u4F53\u7CFB\u3092\u5B9A\u7FA9",
      // Buttons
      saveButton: "\u{1F4BE} \u8A2D\u5B9A\u3092\u4FDD\u5B58",
      diagnoseButton: "\u{1F50D} \u8A2D\u5B9A\u3092\u8A3A\u65AD",
      fixButton: "\u{1F527} \u8A2D\u5B9A\u3092\u4FEE\u5FA9",
      reloadButton: "\u{1F504} \u518D\u8AAD\u307F\u8FBC\u307F",
      // Messages
      saveSuccess: "\u2705 \u8A2D\u5B9A\u304C\u4FDD\u5B58\u3055\u308C\u307E\u3057\u305F",
      saveFailed: "\u274C \u4FDD\u5B58\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      configFixed: "\u2705 \u8A2D\u5B9A\u304C\u4FEE\u5FA9\u3055\u308C\u4FDD\u5B58\u3055\u308C\u307E\u3057\u305F",
      fixFailed: "\u274C \u4FEE\u5FA9\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      reloadPrompt: "\u4FEE\u5FA9\u3055\u308C\u305F\u8A2D\u5B9A\u3092\u78BA\u8A8D\u3059\u308B\u306B\u306F\u30DA\u30FC\u30B8\u3092\u518D\u8AAD\u307F\u8FBC\u307F\u3057\u3066\u304F\u3060\u3055\u3044",
      // Diagnosis
      diagnosisTitle: "\u8A2D\u5B9A\u8A3A\u65AD",
      // Notifications
      clipSuccess: "Obsidian \u306B\u4FDD\u5B58\u3055\u308C\u307E\u3057\u305F",
      clipFailed: "\u30AF\u30EA\u30C3\u30D7\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      extractionFailed: "\u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u62BD\u51FA\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      connectionFailed: "\u63A5\u7D9A\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      scriptInjectionFailed: "\u30B3\u30F3\u30C6\u30F3\u30C4\u30B9\u30AF\u30EA\u30D7\u30C8\u306E\u6CE8\u5165\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      // Context Menu
      clipFullPage: "\u30DA\u30FC\u30B8\u5168\u4F53\u3092 Obsidian \u306B\u30AF\u30EA\u30C3\u30D7",
      clipSelection: "\u2702\uFE0F \u9078\u629E\u7BC4\u56F2\u3092 Obsidian \u306B\u30AF\u30EA\u30C3\u30D7",
      // Dialog
      clipDialogTitle: "\u{1F4CE} \u9078\u629E\u7BC4\u56F2\u3092\u30AF\u30EA\u30C3\u30D7",
      commentLabel: "\u{1F4AD} \u30B3\u30E1\u30F3\u30C8\u3092\u8FFD\u52A0\uFF08\u30AA\u30D7\u30B7\u30E7\u30F3\uFF09\uFF1A",
      commentPlaceholder: "\u3053\u3053\u306B\u8003\u3048\u3001\u30E1\u30E2\u3001\u30B3\u30E1\u30F3\u30C8\u3092\u66F8\u3044\u3066\u304F\u3060\u3055\u3044...",
      cancelButton: "\u30AD\u30E3\u30F3\u30BB\u30EB",
      clipButton: "\u2702\uFE0F \u30AF\u30EA\u30C3\u30D7",
      // Multi-Vault
      additionalVaultsTitle: "\u8FFD\u52A0 Vault",
      additionalVaultsHint: "\u{1F4A1} \u3055\u3089\u306B Vault \u3092\u8FFD\u52A0\u3057\u3001\u30EB\u30FC\u30EB\u306B\u57FA\u3065\u3044\u3066\u81EA\u52D5\u7684\u306B\u30B3\u30F3\u30C6\u30F3\u30C4\u3092\u632F\u308A\u5206\u3051",
      addVaultButton: "+ Vault \u3092\u8FFD\u52A0",
      multiVaultNameLabel: "Vault \u540D",
      multiVaultNamePlaceholder: "\u30DE\u30A4\u30CE\u30FC\u30C8 Vault",
      deleteVaultButton: "\u524A\u9664",
      defaultVaultBadge: "\u30C7\u30D5\u30A9\u30EB\u30C8 Vault",
      // Routing Rules
      routingRulesTitle: "\u30EB\u30FC\u30C6\u30A3\u30F3\u30B0\u30EB\u30FC\u30EB",
      routingRulesHint: "\u{1F4A1} \u30C9\u30E1\u30A4\u30F3\u3001\u30AD\u30FC\u30EF\u30FC\u30C9\u3001\u307E\u305F\u306F URL \u30D1\u30BF\u30FC\u30F3\u306B\u57FA\u3065\u3044\u3066\u81EA\u52D5\u7684\u306B\u30BF\u30FC\u30B2\u30C3\u30C8 Vault \u3092\u9078\u629E",
      addRuleButton: "+ \u30EB\u30FC\u30EB\u3092\u8FFD\u52A0",
      ruleTypeLabel: "\u30EB\u30FC\u30EB\u30BF\u30A4\u30D7",
      ruleTypeDomain: "\u30C9\u30E1\u30A4\u30F3\u30DE\u30C3\u30C1",
      ruleTypeKeyword: "\u30AD\u30FC\u30EF\u30FC\u30C9\u30DE\u30C3\u30C1",
      ruleTypeUrlPattern: "URL \u30D1\u30BF\u30FC\u30F3",
      rulePatternLabel: "\u30DE\u30C3\u30C1\u30D1\u30BF\u30FC\u30F3",
      rulePatternPlaceholder: "\u4F8B\uFF1Aexample.com \u307E\u305F\u306F \u30AD\u30FC\u30EF\u30FC\u30C91,\u30AD\u30FC\u30EF\u30FC\u30C92",
      ruleTargetVaultLabel: "\u30BF\u30FC\u30B2\u30C3\u30C8 Vault",
      rulePriorityLabel: "\u512A\u5148\u5EA6",
      ruleDescriptionLabel: "\u8AAC\u660E",
      ruleDescriptionPlaceholder: "\u4F8B\uFF1A\u6280\u8853\u8A18\u4E8B\u3092\u4ED5\u4E8B\u7528 Vault \u306B\u4FDD\u5B58",
      ruleEnabledLabel: "\u6709\u52B9",
      deleteRuleButton: "\u524A\u9664",
      editRuleButton: "\u7DE8\u96C6"
    }
  };

  // src/i18n/index.ts
  var DEFAULT_LANGUAGE = "zh-CN";
  async function getCurrentLanguage() {
    try {
      const result = await chrome.storage.sync.get("language");
      return result.language || DEFAULT_LANGUAGE;
    } catch (error) {
      console.error("Failed to get language:", error);
      return DEFAULT_LANGUAGE;
    }
  }
  async function setCurrentLanguage(language) {
    try {
      await chrome.storage.sync.set({ language });
    } catch (error) {
      console.error("Failed to set language:", error);
    }
  }
  async function getMessages() {
    const language = await getCurrentLanguage();
    return messages[language];
  }
  async function initI18n() {
    const msgs = await getMessages();
    document.querySelectorAll("[data-i18n]").forEach((element) => {
      const key = element.getAttribute("data-i18n");
      if (key && msgs[key]) {
        element.textContent = msgs[key];
      }
    });
    document.querySelectorAll("[data-i18n-placeholder]").forEach((element) => {
      const key = element.getAttribute("data-i18n-placeholder");
      if (key && msgs[key]) {
        element.placeholder = msgs[key];
      }
    });
    document.querySelectorAll("[data-i18n-title]").forEach((element) => {
      const key = element.getAttribute("data-i18n-title");
      if (key && msgs[key]) {
        element.setAttribute("title", msgs[key]);
      }
    });
  }

  // src/background/vault-router.ts
  function generateId() {
    return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  }

  // src/options/index.ts
  function $(id) {
    return document.getElementById(id);
  }
  var OptionsValidationError = class extends Error {
    constructor(detail) {
      super("INVALID_TAXONOMY");
      this.name = "OptionsValidationError";
      this.code = "INVALID_TAXONOMY";
      this.detail = detail;
    }
  };
  var ConfigTransferError = class extends Error {
    constructor(code, detail) {
      super(code);
      this.name = "ConfigTransferError";
      this.code = code;
      this.detail = detail;
    }
  };
  var DEFAULT_DOMAIN_MAPPINGS = {
    "mp.weixin.qq.com": "\u516C\u4F17\u53F7",
    "wx.zsxq.com": "\u77E5\u8BC6\u661F\u7403",
    "www.zhihu.com": "\u77E5\u4E4E",
    "juejin.cn": "\u6398\u91D1",
    "www.youtube.com": "YouTube",
    "twitter.com": "Twitter",
    "x.com": "Twitter",
    "medium.com": "Medium"
  };
  var DEFAULT_CLASSIFIER_TAXONOMY = {
    type: ["article", "ai_chat"],
    topics: ["cs", "misc"],
    ai_platform: ["chatgpt", "claude", "other"]
  };
  var lastLoadedOptions = null;
  var transferMessageTimer;
  async function load() {
    try {
      console.log("[load] Starting load...");
      const { options } = await chrome.storage.sync.get("options");
      console.log("[load] Options from storage:", options);
      lastLoadedOptions = options ? JSON.parse(JSON.stringify(options)) : {};
      const currentLang = await getCurrentLanguage();
      $("languageSelect").value = currentLang;
      console.log("[load] Applying options to UI...");
      applyOptionsToUI(lastLoadedOptions || {});
      console.log("[load] Clearing transfer message...");
      clearTransferMessage();
      console.log("[load] Loading vault router config...");
      if (lastLoadedOptions?.vaultRouter) {
        additionalVaults = lastLoadedOptions.vaultRouter.vaults || [];
        routingRules = lastLoadedOptions.vaultRouter.rules || [];
      } else {
        additionalVaults = [];
        routingRules = [];
      }
      console.log("[load] Rendering additional vaults...");
      await renderAdditionalVaults();
      console.log("[load] Rendering routing rules...");
      await renderRoutingRules();
      console.log("[load] Load completed successfully");
    } catch (error) {
      console.error("[load] Error during load:", error);
      throw error;
    }
  }
  function applyOptionsToUI(options = {}) {
    const rest = options?.rest || {};
    $("restHttpsUrl").value = rest?.httpsUrl || "https://127.0.0.1:27124/";
    $("restHttpUrl").value = rest?.httpUrl || "http://127.0.0.1:27123/";
    $("restVault").value = rest?.vault || "YourVault";
    $("restKey").value = rest?.apiKey || "";
    const templates = options?.templates || {};
    $("tplArticle").value = templates?.article || "Articles/{domain}/{yyyy}/{slug}.md";
    $("tplFragment").value = templates?.fragment || "Fragments/{yyyy}/{mm}/{dd}/{title}.md";
    $("tplAI").value = templates?.ai || "AI/{platform}/{yyyy}/{yyyy}-{mm}-{dd}_{title}.md";
    const mappings = options?.domainMappings && Object.keys(options.domainMappings).length > 0 ? options.domainMappings : DEFAULT_DOMAIN_MAPPINGS;
    renderDomainMappings(mappings);
    const aiChat = options?.aiChat || {};
    $("aiIncludeTimestamps").checked = aiChat?.includeTimestamps ?? false;
    $("aiUserName").value = aiChat?.userName || "USER";
    const deepResearch = options?.deepResearch || {};
    $("deepResearchPureMode").checked = deepResearch.pureMode ?? false;
    const classifier = options?.classifier || {};
    $("clsEnable").checked = !!classifier?.enabled;
    $("clsProvider").value = classifier?.provider || "ollama";
    $("clsEndpoint").value = classifier?.endpoint || "http://localhost:11434/api/chat";
    $("clsModel").value = classifier?.model || "llama3.1";
    $("clsKey").value = classifier?.apiKey || "";
    let taxonomy = DEFAULT_CLASSIFIER_TAXONOMY;
    if (classifier?.taxonomy) {
      taxonomy = classifier.taxonomy;
    }
    let taxonomyString = JSON.stringify(DEFAULT_CLASSIFIER_TAXONOMY, null, 2);
    try {
      taxonomyString = JSON.stringify(taxonomy, null, 2);
    } catch (error) {
      console.warn("Failed to stringify taxonomy config, fallback to default", error);
    }
    $("clsTax").value = taxonomyString;
    toggleClassifierConfig();
  }
  function renderDomainMappings(mappings) {
    const container = $("domainMappings");
    container.innerHTML = "";
    Object.entries(mappings).forEach(([domain, name]) => {
      addMappingRow(domain, name);
    });
  }
  function addMappingRow(domain = "", name = "") {
    const container = $("domainMappings");
    const row = document.createElement("div");
    row.className = "mapping-item";
    const domainInput = document.createElement("input");
    domainInput.type = "text";
    domainInput.placeholder = "\u4F8B\u5982: mp.weixin.qq.com";
    domainInput.value = domain;
    domainInput.className = "mapping-domain";
    const nameInput = document.createElement("input");
    nameInput.type = "text";
    nameInput.placeholder = "\u4F8B\u5982: \u516C\u4F17\u53F7";
    nameInput.value = name;
    nameInput.className = "mapping-name";
    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "\u5220\u9664";
    deleteBtn.className = "danger";
    deleteBtn.onclick = () => {
      row.remove();
    };
    row.appendChild(domainInput);
    row.appendChild(nameInput);
    row.appendChild(deleteBtn);
    container.appendChild(row);
  }
  function getDomainMappings() {
    const mappings = {};
    const rows = document.querySelectorAll(".mapping-item");
    rows.forEach((row) => {
      const domainInput = row.querySelector(".mapping-domain");
      const nameInput = row.querySelector(".mapping-name");
      const domain = domainInput.value.trim();
      const name = nameInput.value.trim();
      if (domain && name) {
        mappings[domain] = name;
      }
    });
    return mappings;
  }
  function toggleClassifierConfig() {
    const enabled = $("clsEnable").checked;
    const config = $("classifierConfig");
    config.style.display = enabled ? "block" : "none";
  }
  function collectOptions() {
    const httpsUrl = ($("restHttpsUrl").value || "").trim();
    const httpUrl = ($("restHttpUrl").value || "").trim();
    const taxonomyInput = $("clsTax").value || "";
    let taxonomy = {};
    const trimmedTaxonomy = taxonomyInput.trim();
    if (trimmedTaxonomy) {
      try {
        taxonomy = JSON.parse(trimmedTaxonomy);
      } catch (error) {
        throw new OptionsValidationError(error?.message);
      }
    }
    const options = {
      rest: {
        baseUrl: httpsUrl || httpUrl || "https://127.0.0.1:27124/",
        httpsUrl: httpsUrl || void 0,
        httpUrl: httpUrl || void 0,
        vault: ($("restVault").value || "").trim() || "YourVault",
        apiKey: ($("restKey").value || "").trim(),
        rootDir: lastLoadedOptions?.rest?.rootDir
      },
      templates: {
        article: ($("tplArticle").value || "").trim() || "Articles/{domain}/{yyyy}/{slug}.md",
        fragment: ($("tplFragment").value || "").trim() || "Fragments/{yyyy}/{mm}/{dd}/{title}.md",
        ai: ($("tplAI").value || "").trim() || "AI/{platform}/{yyyy}/{yyyy}-{mm}-{dd}_{title}.md"
      },
      domainMappings: getDomainMappings(),
      aiChat: {
        includeTimestamps: $("aiIncludeTimestamps").checked,
        userName: ($("aiUserName").value || "").trim() || "USER"
      },
      deepResearch: {
        pureMode: $("deepResearchPureMode").checked
      },
      classifier: {
        enabled: $("clsEnable").checked,
        provider: $("clsProvider").value || "ollama",
        endpoint: ($("clsEndpoint").value || "").trim(),
        model: ($("clsModel").value || "").trim(),
        apiKey: ($("clsKey").value || "").trim(),
        taxonomy
      }
    };
    if (lastLoadedOptions) {
      for (const [key, value] of Object.entries(lastLoadedOptions)) {
        if (!["rest", "templates", "domainMappings", "aiChat", "deepResearch", "classifier", "vaultRouter"].includes(key)) {
          options[key] = value;
        }
      }
    }
    if (additionalVaults.length > 0 || routingRules.length > 0) {
      options.vaultRouter = {
        vaults: additionalVaults,
        rules: routingRules,
        defaultVaultId: additionalVaults.find((v) => v.isDefault)?.id || (additionalVaults[0]?.id || "")
      };
    }
    return options;
  }
  async function copyConfig() {
    clearTransferMessage();
    const msgs = await getMessages();
    try {
      const options = collectOptions();
      const jsonText = JSON.stringify(options, null, 2);
      await writeToClipboard(jsonText);
      showTransferMessage("success", msgs.copyConfigSuccess);
    } catch (error) {
      showTransferMessage("error", formatOptionsError(error, msgs));
    }
  }
  async function writeToClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return;
    }
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    const success = document.execCommand("copy");
    document.body.removeChild(textarea);
    if (!success) {
      throw new ConfigTransferError("CLIPBOARD_UNAVAILABLE");
    }
  }
  async function readFromClipboard() {
    if (navigator.clipboard && navigator.clipboard.readText) {
      return navigator.clipboard.readText();
    }
    throw new ConfigTransferError("CLIPBOARD_READ_UNAVAILABLE");
  }
  function parseConfigInput(raw) {
    const textValue = (raw || "").trim();
    if (!textValue) {
      throw new ConfigTransferError("EMPTY_IMPORT");
    }
    try {
      const parsed = JSON.parse(textValue);
      if (typeof parsed !== "object" || parsed === null) {
        throw new ConfigTransferError("PARSE_FAILED");
      }
      return parsed;
    } catch (error) {
      if (error instanceof ConfigTransferError) {
        throw error;
      }
      const detail = error instanceof Error ? error.message : void 0;
      throw new ConfigTransferError("PARSE_FAILED", detail);
    }
  }
  async function importConfigFromClipboard() {
    clearTransferMessage();
    const msgs = await getMessages();
    try {
      const raw = await readFromClipboard();
      const parsed = parseConfigInput(raw);
      lastLoadedOptions = parsed;
      applyOptionsToUI(parsed);
      const normalized = collectOptions();
      await chrome.storage.sync.set({ options: normalized });
      lastLoadedOptions = normalized;
      showTransferMessage("success", msgs.importSuccess);
      const msgEl = $("msg");
      msgEl.textContent = msgs.importSuccess;
      msgEl.className = "message success";
      setTimeout(() => {
        msgEl.textContent = "";
        msgEl.className = "";
      }, 2e3);
    } catch (error) {
      showTransferMessage("error", formatOptionsError(error, msgs));
    }
  }
  function showTransferMessage(type, text) {
    const msgEl = $("configTransferMsg");
    msgEl.textContent = text;
    msgEl.className = type === "success" ? "message success" : "message error";
    if (transferMessageTimer) {
      window.clearTimeout(transferMessageTimer);
    }
    transferMessageTimer = window.setTimeout(() => {
      msgEl.textContent = "";
      msgEl.className = "message";
    }, 2500);
  }
  function clearTransferMessage() {
    try {
      const msgEl = $("configTransferMsg");
      if (msgEl) {
        msgEl.textContent = "";
        msgEl.className = "message";
      }
      if (transferMessageTimer) {
        window.clearTimeout(transferMessageTimer);
        transferMessageTimer = void 0;
      }
    } catch (error) {
      console.error("[clearTransferMessage] Error:", error);
    }
  }
  function formatOptionsError(error, msgs) {
    if (error instanceof OptionsValidationError) {
      return error.detail ? `${msgs.invalidTaxonomy}: ${error.detail}` : msgs.invalidTaxonomy;
    }
    if (error instanceof ConfigTransferError) {
      switch (error.code) {
        case "EMPTY_IMPORT":
          return msgs.emptyImportError;
        case "CLIPBOARD_UNAVAILABLE":
          return msgs.clipboardUnavailable;
        case "CLIPBOARD_READ_UNAVAILABLE":
          return msgs.clipboardReadUnavailable;
        case "PARSE_FAILED":
        default:
          return error.detail ? `${msgs.importParseFailed}: ${error.detail}` : msgs.importParseFailed;
      }
    }
    if (error instanceof Error) {
      return error.message;
    }
    return String(error);
  }
  async function save() {
    const msgEl = $("msg");
    try {
      const options = collectOptions();
      await chrome.storage.sync.set({ options });
      lastLoadedOptions = options;
      const msgs = await getMessages();
      msgEl.textContent = msgs.saveSuccess;
      msgEl.className = "message success";
      setTimeout(() => {
        msgEl.textContent = "";
        msgEl.className = "";
      }, 2e3);
    } catch (error) {
      const msgs = await getMessages();
      msgEl.textContent = `${msgs.saveFailed}: ${formatOptionsError(error, msgs)}`;
      msgEl.className = "message error";
    }
  }
  async function diagnose() {
    const diagSection = $("diagSection");
    const diagOutput = $("diagOutput");
    diagSection.style.display = "block";
    diagOutput.textContent = "\u6B63\u5728\u8BCA\u65AD...\n";
    try {
      const { options } = await chrome.storage.sync.get("options");
      diagOutput.textContent += "\n\u{1F4CB} \u5F53\u524D\u914D\u7F6E:\n";
      diagOutput.textContent += JSON.stringify(options, null, 2) + "\n";
      diagOutput.textContent += "\n\u{1F50D} \u68C0\u67E5\u914D\u7F6E:\n";
      if (!options) {
        diagOutput.textContent += "\u274C \u672A\u627E\u5230\u914D\u7F6E\n";
        return;
      }
      if (!options.rest) {
        diagOutput.textContent += "\u274C REST API \u914D\u7F6E\u7F3A\u5931\n";
        return;
      }
      const { rest } = options;
      if (rest.httpsUrl) {
        diagOutput.textContent += `\u2705 HTTPS URL: ${rest.httpsUrl}
`;
      } else {
        diagOutput.textContent += "\u26A0\uFE0F \u672A\u914D\u7F6E HTTPS URL\n";
      }
      if (rest.httpUrl) {
        diagOutput.textContent += `\u2705 HTTP URL: ${rest.httpUrl}
`;
      } else {
        diagOutput.textContent += "\u26A0\uFE0F \u672A\u914D\u7F6E HTTP URL\n";
      }
      if (rest.baseUrl) {
        diagOutput.textContent += `\u2139\uFE0F Base URL (\u5411\u540E\u517C\u5BB9): ${rest.baseUrl}
`;
        if (rest.baseUrl.startsWith("http://") && rest.baseUrl.includes(":27124")) {
          diagOutput.textContent += "\u274C \u9519\u8BEF: baseUrl \u4F7F\u7528\u4E86 HTTP \u534F\u8BAE\u4F46\u7AEF\u53E3\u662F 27124 (HTTPS \u7AEF\u53E3)\n";
          diagOutput.textContent += '\u{1F4A1} \u5EFA\u8BAE: \u70B9\u51FB\u4E0B\u65B9"\u4FEE\u590D\u914D\u7F6E"\u6309\u94AE\n';
        } else if (rest.baseUrl.startsWith("https://") && rest.baseUrl.includes(":27123")) {
          diagOutput.textContent += "\u274C \u9519\u8BEF: baseUrl \u4F7F\u7528\u4E86 HTTPS \u534F\u8BAE\u4F46\u7AEF\u53E3\u662F 27123 (HTTP \u7AEF\u53E3)\n";
          diagOutput.textContent += '\u{1F4A1} \u5EFA\u8BAE: \u70B9\u51FB\u4E0B\u65B9"\u4FEE\u590D\u914D\u7F6E"\u6309\u94AE\n';
        }
      }
      if (!rest.vault) {
        diagOutput.textContent += "\u26A0\uFE0F \u672A\u914D\u7F6E Vault\n";
      } else {
        diagOutput.textContent += `\u2705 Vault: ${rest.vault}
`;
      }
      if (!rest.apiKey) {
        diagOutput.textContent += "\u26A0\uFE0F \u672A\u914D\u7F6E API Key\n";
      } else {
        diagOutput.textContent += `\u2705 API Key: ${rest.apiKey.substring(0, 8)}...
`;
      }
      diagOutput.textContent += "\n\u{1F50C} \u6D4B\u8BD5\u8FDE\u63A5:\n";
      const testUrls = [];
      if (rest.httpsUrl) testUrls.push({ url: rest.httpsUrl, protocol: "HTTPS" });
      if (rest.httpUrl) testUrls.push({ url: rest.httpUrl, protocol: "HTTP" });
      for (const { url, protocol } of testUrls) {
        try {
          diagOutput.textContent += `
\u6D4B\u8BD5 ${protocol} (${url})...
`;
          const testUrl = `${url}vault/`;
          const response = await fetch(testUrl, {
            headers: { "Authorization": `Bearer ${rest.apiKey}` }
          });
          if (response.ok) {
            const data = await response.json();
            diagOutput.textContent += `\u2705 ${protocol} \u8FDE\u63A5\u6210\u529F
`;
            diagOutput.textContent += `   \u8FD4\u56DE\u6570\u636E: ${JSON.stringify(data)}
`;
          } else {
            diagOutput.textContent += `\u274C ${protocol} \u8FDE\u63A5\u5931\u8D25: ${response.status} ${response.statusText}
`;
          }
        } catch (error) {
          diagOutput.textContent += `\u274C ${protocol} \u8FDE\u63A5\u5931\u8D25: ${error.message}
`;
        }
      }
      diagOutput.textContent += "\n\u2705 \u8BCA\u65AD\u5B8C\u6210\n";
    } catch (error) {
      diagOutput.textContent += `
\u274C \u8BCA\u65AD\u5931\u8D25: ${error.message}
`;
    }
  }
  async function fixConfig() {
    const diagOutput = $("diagOutput");
    try {
      const { options } = await chrome.storage.sync.get("options");
      if (!options || !options.rest) {
        diagOutput.textContent += "\n\u274C \u65E0\u6CD5\u4FEE\u590D: \u672A\u627E\u5230\u914D\u7F6E\n";
        return;
      }
      diagOutput.textContent += "\n\u{1F527} \u4FEE\u590D\u914D\u7F6E...\n";
      let baseUrl = options.rest.httpsUrl || options.rest.baseUrl || "https://127.0.0.1:27124/";
      if (baseUrl.startsWith("http://") && baseUrl.includes(":27124")) {
        baseUrl = baseUrl.replace("http://", "https://");
        diagOutput.textContent += "\u2705 \u4FEE\u590D: \u5C06 HTTP://...27124 \u6539\u4E3A HTTPS://...27124\n";
      } else if (baseUrl.startsWith("https://") && baseUrl.includes(":27123")) {
        baseUrl = baseUrl.replace("https://", "http://");
        diagOutput.textContent += "\u2705 \u4FEE\u590D: \u5C06 HTTPS://...27123 \u6539\u4E3A HTTP://...27123\n";
      }
      const templates = options.templates || {};
      let templatesFixed = false;
      if (!templates.fragment) {
        templates.fragment = "Fragments/{yyyy}/{mm}/{dd}/{title}.md";
        diagOutput.textContent += "\u2705 \u6DFB\u52A0: fragment \u6A21\u677F\n";
        templatesFixed = true;
      }
      if (templates.article && templates.article.includes("Clippings/")) {
        templates.article = templates.article.replace("Clippings/", "Articles/");
        diagOutput.textContent += "\u2705 \u66F4\u65B0: article \u6A21\u677F (Clippings \u2192 Articles)\n";
        templatesFixed = true;
      }
      const newOptions = {
        ...options,
        rest: {
          ...options.rest,
          httpsUrl: options.rest.httpsUrl || "https://127.0.0.1:27124/",
          httpUrl: options.rest.httpUrl || "http://127.0.0.1:27123/",
          baseUrl
        },
        templates: {
          article: templates.article || "Articles/{domain}/{yyyy}/{slug}.md",
          fragment: templates.fragment || "Fragments/{yyyy}/{mm}/{dd}/{title}.md",
          ai: templates.ai || "AI/{platform}/{yyyy}/{yyyy}-{mm}-{dd}_{title}.md"
        }
      };
      await chrome.storage.sync.set({ options: newOptions });
      diagOutput.textContent += "\u2705 \u914D\u7F6E\u5DF2\u4FEE\u590D\u5E76\u4FDD\u5B58\n";
      diagOutput.textContent += "\n\u8BF7\u91CD\u65B0\u52A0\u8F7D\u9875\u9762\u67E5\u770B\u4FEE\u590D\u540E\u7684\u914D\u7F6E\n";
      setTimeout(() => {
        void load();
        void diagnose();
      }, 1e3);
    } catch (error) {
      diagOutput.textContent += `
\u274C \u4FEE\u590D\u5931\u8D25: ${error.message}
`;
    }
  }
  document.addEventListener("DOMContentLoaded", async () => {
    await initI18n();
    await load();
    $("languageSelect").addEventListener("change", async (e) => {
      const newLang = e.target.value;
      await setCurrentLanguage(newLang);
      await initI18n();
      await load();
    });
    $("addMappingBtn").addEventListener("click", () => {
      addMappingRow();
    });
    $("clsEnable").addEventListener("change", () => {
      toggleClassifierConfig();
    });
    $("copyConfigBtn").addEventListener("click", () => {
      void copyConfig();
    });
    $("importConfigBtn").addEventListener("click", () => {
      void importConfigFromClipboard();
    });
    $("addAdditionalVaultBtn").addEventListener("click", () => {
      void addAdditionalVault();
    });
    $("addRoutingRuleBtn").addEventListener("click", () => {
      void addRoutingRule();
    });
  });
  $("saveBtn").addEventListener("click", () => {
    void save();
  });
  $("diagBtn").addEventListener("click", () => {
    void diagnose();
  });
  $("fixBtn").addEventListener("click", () => {
    void fixConfig();
  });
  $("reloadBtn").addEventListener("click", () => {
    void load();
    void diagnose();
  });
  var additionalVaults = [];
  var routingRules = [];
  async function renderAdditionalVaults() {
    const msgs = await getMessages();
    const container = $("additionalVaultsList");
    container.innerHTML = "";
    for (const vault of additionalVaults) {
      const row = document.createElement("div");
      row.className = "vault-form-row";
      row.dataset.id = vault.id;
      row.innerHTML = `
      <div class="row">
        <div class="form-group">
          <label data-i18n="multiVaultNameLabel">\u4ED3\u5E93\u540D\u79F0</label>
          <input type="text" class="vault-name" value="${vault.name}" placeholder="\u6211\u7684\u7B14\u8BB0\u4ED3\u5E93" />
          <small>\u7528\u4E8E\u8BC6\u522B\u6B64\u4ED3\u5E93\u7684\u53CB\u597D\u540D\u79F0</small>
        </div>
      </div>
      <div class="row">
        <div class="form-group">
          <label data-i18n="httpsUrlLabel">HTTPS URL</label>
          <input type="text" class="vault-https-url" value="${vault.httpsUrl}" placeholder="https://127.0.0.1:27124/" />
          <small data-i18n="httpsUrlHint">\u901A\u5E38\u7AEF\u53E3\u4E3A 27124\uFF0C\u9002\u7528\u4E8E\u5B89\u5168\u8FDE\u63A5</small>
        </div>
        <div class="form-group">
          <label data-i18n="httpUrlLabel">HTTP URL</label>
          <input type="text" class="vault-http-url" value="${vault.httpUrl}" placeholder="http://127.0.0.1:27123/" />
          <small data-i18n="httpUrlHint">\u901A\u5E38\u7AEF\u53E3\u4E3A 27123\uFF0C\u4F5C\u4E3A\u5907\u7528\u8FDE\u63A5</small>
        </div>
      </div>
      <div class="row">
        <div class="form-group">
          <label data-i18n="vaultNameLabel">Vault \u540D\u79F0</label>
          <input type="text" class="vault-vault" value="${vault.vault}" placeholder="YourVault" />
          <small data-i18n="vaultNameHint">\u4F60\u7684 Obsidian \u4ED3\u5E93\u540D\u79F0</small>
        </div>
        <div class="form-group">
          <label data-i18n="apiKeyLabel">API Key</label>
          <input type="password" class="vault-api-key" value="${vault.apiKey}" placeholder="\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022" />
          <small data-i18n="apiKeyHint">\u5728 Obsidian Local REST API \u63D2\u4EF6\u4E2D\u83B7\u53D6</small>
        </div>
      </div>
      <div class="form-actions">
        <button class="btn-remove" data-id="${vault.id}">
          <span data-i18n="deleteVaultButton">\u5220\u9664</span>
        </button>
      </div>
    `;
      container.appendChild(row);
    }
    container.querySelectorAll(".btn-remove").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const id = e.target.closest("button").dataset.id;
        if (confirm("\u786E\u5B9A\u8981\u5220\u9664\u8FD9\u4E2A\u4ED3\u5E93\u5417\uFF1F\u76F8\u5173\u7684\u8DEF\u7531\u89C4\u5219\u4E5F\u4F1A\u88AB\u5220\u9664\u3002")) {
          additionalVaults = additionalVaults.filter((v) => v.id !== id);
          routingRules = routingRules.filter((r) => r.vaultId !== id);
          void renderAdditionalVaults();
          void renderRoutingRules();
        }
      });
    });
    container.querySelectorAll(".vault-form-row").forEach((row) => {
      const id = row.dataset.id;
      const vault = additionalVaults.find((v) => v.id === id);
      if (!vault) return;
      const nameInput = row.querySelector(".vault-name");
      const httpsUrlInput = row.querySelector(".vault-https-url");
      const httpUrlInput = row.querySelector(".vault-http-url");
      const vaultInput = row.querySelector(".vault-vault");
      const apiKeyInput = row.querySelector(".vault-api-key");
      nameInput.addEventListener("input", () => {
        vault.name = nameInput.value;
      });
      httpsUrlInput.addEventListener("input", () => {
        vault.httpsUrl = httpsUrlInput.value;
      });
      httpUrlInput.addEventListener("input", () => {
        vault.httpUrl = httpUrlInput.value;
      });
      vaultInput.addEventListener("input", () => {
        vault.vault = vaultInput.value;
      });
      apiKeyInput.addEventListener("input", () => {
        vault.apiKey = apiKeyInput.value;
      });
    });
    await initI18n();
  }
  async function addAdditionalVault() {
    const newVault = {
      id: generateId(),
      name: "\u65B0\u4ED3\u5E93",
      httpsUrl: "https://127.0.0.1:27124/",
      httpUrl: "http://127.0.0.1:27123/",
      vault: "YourVault",
      apiKey: "",
      isDefault: false
    };
    additionalVaults.push(newVault);
    await renderAdditionalVaults();
    await renderRoutingRules();
  }
  async function renderRoutingRules() {
    const msgs = await getMessages();
    const container = $("routingRulesList");
    container.innerHTML = "";
    for (const rule of routingRules) {
      const vault = additionalVaults.find((v) => v.id === rule.vaultId);
      const row = document.createElement("div");
      row.className = "rule-form-row";
      row.dataset.id = rule.id;
      row.style.opacity = rule.enabled ? "1" : "0.6";
      let vaultOptions = "";
      for (const v of additionalVaults) {
        const selected = v.id === rule.vaultId ? "selected" : "";
        vaultOptions += `<option value="${v.id}" ${selected}>${v.name}</option>`;
      }
      row.innerHTML = `
      <div class="row">
        <div class="form-group">
          <label data-i18n="ruleTypeLabel">\u89C4\u5219\u7C7B\u578B</label>
          <select class="rule-type">
            <option value="domain" ${rule.type === "domain" ? "selected" : ""} data-i18n="ruleTypeDomain">\u57DF\u540D\u5339\u914D</option>
            <option value="keyword" ${rule.type === "keyword" ? "selected" : ""} data-i18n="ruleTypeKeyword">\u5173\u952E\u8BCD\u5339\u914D</option>
            <option value="url-pattern" ${rule.type === "url-pattern" ? "selected" : ""} data-i18n="ruleTypeUrlPattern">URL \u6A21\u5F0F</option>
          </select>
        </div>
        <div class="form-group">
          <label data-i18n="rulePatternLabel">\u5339\u914D\u6A21\u5F0F</label>
          <input type="text" class="rule-pattern" value="${rule.pattern}" placeholder="github.com" />
          <small data-i18n="rulePatternPlaceholder">\u4F8B\u5982: github.com \u6216 \u7F16\u7A0B,\u4EE3\u7801</small>
        </div>
      </div>
      <div class="row">
        <div class="form-group">
          <label data-i18n="ruleTargetVaultLabel">\u76EE\u6807\u4ED3\u5E93</label>
          <select class="rule-vault">
            ${vaultOptions || '<option value="">\u8BF7\u5148\u6DFB\u52A0\u989D\u5916\u4ED3\u5E93</option>'}
          </select>
        </div>
        <div class="form-group">
          <label data-i18n="rulePriorityLabel">\u4F18\u5148\u7EA7 (0-100)</label>
          <input type="number" class="rule-priority" value="${rule.priority}" min="0" max="100" placeholder="10" />
          <small>\u6570\u5B57\u8D8A\u5927\u4F18\u5148\u7EA7\u8D8A\u9AD8</small>
        </div>
      </div>
      <div class="row">
        <div class="form-group">
          <label data-i18n="ruleDescriptionLabel">\u63CF\u8FF0\uFF08\u53EF\u9009\uFF09</label>
          <input type="text" class="rule-description" value="${rule.description || ""}" placeholder="\u89C4\u5219\u8BF4\u660E" />
          <small>\u5E2E\u52A9\u4F60\u8BB0\u4F4F\u8FD9\u4E2A\u89C4\u5219\u7684\u7528\u9014</small>
        </div>
        <div class="form-group">
          <label>
            <input type="checkbox" class="rule-enabled" ${rule.enabled ? "checked" : ""} />
            <span data-i18n="ruleEnabledLabel">\u542F\u7528\u6B64\u89C4\u5219</span>
          </label>
        </div>
      </div>
      <div class="form-actions">
        <button class="btn-remove" data-id="${rule.id}">
          <span data-i18n="deleteRuleButton">\u5220\u9664</span>
        </button>
      </div>
    `;
      container.appendChild(row);
    }
    container.querySelectorAll(".btn-remove").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const id = e.target.closest("button").dataset.id;
        if (confirm("\u786E\u5B9A\u8981\u5220\u9664\u8FD9\u4E2A\u89C4\u5219\u5417\uFF1F")) {
          routingRules = routingRules.filter((r) => r.id !== id);
          void renderRoutingRules();
        }
      });
    });
    container.querySelectorAll(".rule-form-row").forEach((row) => {
      const id = row.dataset.id;
      const rule = routingRules.find((r) => r.id === id);
      if (!rule) return;
      const typeSelect = row.querySelector(".rule-type");
      const patternInput = row.querySelector(".rule-pattern");
      const vaultSelect = row.querySelector(".rule-vault");
      const priorityInput = row.querySelector(".rule-priority");
      const descriptionInput = row.querySelector(".rule-description");
      const enabledCheckbox = row.querySelector(".rule-enabled");
      typeSelect.addEventListener("change", () => {
        rule.type = typeSelect.value;
      });
      patternInput.addEventListener("input", () => {
        rule.pattern = patternInput.value;
      });
      vaultSelect.addEventListener("change", () => {
        rule.vaultId = vaultSelect.value;
      });
      priorityInput.addEventListener("input", () => {
        rule.priority = parseInt(priorityInput.value) || 10;
      });
      descriptionInput.addEventListener("input", () => {
        rule.description = descriptionInput.value || void 0;
      });
      enabledCheckbox.addEventListener("change", () => {
        rule.enabled = enabledCheckbox.checked;
        row.style.opacity = rule.enabled ? "1" : "0.6";
      });
    });
    await initI18n();
  }
  async function addRoutingRule() {
    if (additionalVaults.length === 0) {
      alert("\u8BF7\u5148\u6DFB\u52A0\u989D\u5916\u4ED3\u5E93");
      return;
    }
    const newRule = {
      id: generateId(),
      vaultId: additionalVaults[0].id,
      type: "domain",
      pattern: "",
      priority: 10,
      description: void 0,
      enabled: true
    };
    routingRules.push(newRule);
    await renderRoutingRules();
  }
})();
//# sourceMappingURL=index.js.map
