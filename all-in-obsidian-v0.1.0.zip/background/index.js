"use strict";
(() => {
  // src/background/store.ts
  var DEFAULTS = {
    rest: {
      baseUrl: "https://127.0.0.1:27124/",
      // 保留作为默认值
      httpsUrl: "https://127.0.0.1:27124/",
      // HTTPS URL
      httpUrl: "http://127.0.0.1:27123/",
      // HTTP URL
      vault: "YourVault",
      apiKey: ""
    },
    templates: {
      article: "Articles/{domain}/{yyyy}/{slug}.md",
      ai: "AI/{platform}/{yyyy}/{yyyy}-{mm}-{dd}_{title}.md",
      fragment: "Fragments/{yyyy}/{mm}/{dd}/{title}.md"
    },
    domainMappings: {
      "mp.weixin.qq.com": "\u516C\u4F17\u53F7",
      "wx.zsxq.com": "\u77E5\u8BC6\u661F\u7403",
      "www.zhihu.com": "\u77E5\u4E4E",
      "juejin.cn": "\u6398\u91D1",
      "www.youtube.com": "YouTube",
      "twitter.com": "Twitter",
      "x.com": "Twitter",
      "medium.com": "Medium"
    },
    classifier: {
      enabled: false,
      provider: "ollama",
      endpoint: "http://localhost:11434/api/chat",
      model: "llama3.1",
      taxonomy: {
        type: ["article", "ai_chat"],
        topics: ["cs", "math", "product", "research", "howto", "news", "misc"],
        ai_platform: ["chatgpt", "claude", "gemini", "copilot", "perplexity", "poe", "other"]
      }
    },
    deepResearch: {
      pureMode: false
      // 默认包含对话内容
    }
  };
  async function getOptions() {
    const { options } = await chrome.storage.sync.get("options");
    if (!options) {
      return {
        ...DEFAULTS,
        vaultRouter: void 0
        // 不自动创建默认配置
      };
    }
    const merged = {
      rest: {
        baseUrl: options.rest?.baseUrl || DEFAULTS.rest.baseUrl,
        httpsUrl: options.rest?.httpsUrl || DEFAULTS.rest.httpsUrl,
        httpUrl: options.rest?.httpUrl || DEFAULTS.rest.httpUrl,
        vault: options.rest?.vault || DEFAULTS.rest.vault,
        apiKey: options.rest?.apiKey || DEFAULTS.rest.apiKey,
        rootDir: options.rest?.rootDir
      },
      templates: {
        article: options.templates?.article || DEFAULTS.templates.article,
        fragment: options.templates?.fragment || DEFAULTS.templates.fragment,
        ai: options.templates?.ai || DEFAULTS.templates.ai
      },
      domainMappings: options.domainMappings || DEFAULTS.domainMappings,
      classifier: options.classifier ? {
        enabled: options.classifier.enabled ?? DEFAULTS.classifier.enabled,
        provider: options.classifier.provider || DEFAULTS.classifier.provider,
        endpoint: options.classifier.endpoint || DEFAULTS.classifier.endpoint,
        model: options.classifier.model || DEFAULTS.classifier.model,
        apiKey: options.classifier.apiKey || DEFAULTS.classifier.apiKey,
        taxonomy: options.classifier.taxonomy || DEFAULTS.classifier.taxonomy
      } : DEFAULTS.classifier,
      deepResearch: options.deepResearch || DEFAULTS.deepResearch,
      vaultRouter: options.vaultRouter
      // 只使用用户配置的 vaultRouter，不自动创建
    };
    return merged;
  }

  // src/background/sinks/obsidianRest.ts
  async function writeFile(rest, filePath, content) {
    const encodedPath = filePath.split("/").map((part) => encodeURIComponent(part)).join("/");
    console.log("Writing to Obsidian:", {
      filePath,
      baseUrl: rest.baseUrl,
      httpsUrl: rest.httpsUrl,
      httpUrl: rest.httpUrl,
      vault: rest.vault,
      hasApiKey: !!rest.apiKey,
      apiKeyLength: rest.apiKey?.length,
      apiKeyFirst8: rest.apiKey?.slice(0, 8),
      apiKeyLast8: rest.apiKey?.slice(-8)
    });
    async function doPut(targetUrl, protocol) {
      const res = await fetch(targetUrl, {
        method: "PUT",
        headers: {
          "Authorization": `Bearer ${rest.apiKey}`,
          "Content-Type": "text/markdown; charset=utf-8"
        },
        body: content
      });
      if (!res.ok) {
        const errorText = await res.text().catch(() => res.statusText);
        throw new Error(`REST write failed (${protocol}): ${res.status} ${errorText}`);
      }
      return res;
    }
    function buildUrl(baseUrl) {
      return `${baseUrl.replace(/\/$/, "")}/vault/${encodeURIComponent(rest.vault)}/${encodedPath}`;
    }
    const urlsToTry = [];
    const isLocalAddress = (url) => /^https?:\/\/(127\.0\.0\.1|localhost)/.test(url);
    if (rest.httpsUrl || rest.httpUrl) {
      console.log("\u4F7F\u7528\u7528\u6237\u914D\u7F6E\u7684 HTTPS/HTTP URL");
      if (rest.httpsUrl && rest.httpsUrl.trim()) {
        urlsToTry.push({
          url: buildUrl(rest.httpsUrl),
          protocol: "HTTPS (\u7528\u6237\u914D\u7F6E)"
        });
      }
      if (rest.httpUrl && rest.httpUrl.trim()) {
        urlsToTry.push({
          url: buildUrl(rest.httpUrl),
          protocol: "HTTP (\u7528\u6237\u914D\u7F6E)"
        });
      }
      if (rest.httpsUrl && rest.httpUrl && isLocalAddress(rest.httpsUrl)) {
        const httpAltPort = rest.httpUrl.replace(":27123", ":27124");
        if (httpAltPort !== rest.httpUrl) {
          urlsToTry.push({
            url: buildUrl(httpAltPort),
            protocol: "HTTP (\u5907\u7528\u7AEF\u53E3)"
          });
        }
      }
    } else {
      console.log("\u4F7F\u7528 baseUrl \u914D\u7F6E\uFF08\u5411\u540E\u517C\u5BB9\u6A21\u5F0F\uFF09");
      if (isLocalAddress(rest.baseUrl)) {
        const isHttps = rest.baseUrl.startsWith("https://");
        if (isHttps) {
          urlsToTry.push({
            url: buildUrl(rest.baseUrl),
            protocol: "HTTPS"
          });
          urlsToTry.push({
            url: buildUrl(rest.baseUrl.replace(/^https:/, "http:")),
            protocol: "HTTP (same port)"
          });
          const httpAltPort = rest.baseUrl.replace(/^https:/, "http:").replace(":27124", ":27123");
          if (httpAltPort !== rest.baseUrl.replace(/^https:/, "http:")) {
            urlsToTry.push({
              url: buildUrl(httpAltPort),
              protocol: "HTTP (port 27123)"
            });
          }
        } else {
          urlsToTry.push({
            url: buildUrl(rest.baseUrl),
            protocol: "HTTP"
          });
          urlsToTry.push({
            url: buildUrl(rest.baseUrl.replace(/^http:/, "https:")),
            protocol: "HTTPS (same port)"
          });
          const httpsAltPort = rest.baseUrl.replace(/^http:/, "https:").replace(":27123", ":27124");
          if (httpsAltPort !== rest.baseUrl.replace(/^http:/, "https:")) {
            urlsToTry.push({
              url: buildUrl(httpsAltPort),
              protocol: "HTTPS (port 27124)"
            });
          }
        }
      } else {
        urlsToTry.push({
          url: buildUrl(rest.baseUrl),
          protocol: rest.baseUrl.startsWith("https://") ? "HTTPS" : "HTTP"
        });
      }
    }
    const errors = [];
    for (const { url, protocol } of urlsToTry) {
      try {
        console.log(`Trying ${protocol}:`, url.replace(rest.apiKey, "***"));
        const res = await doPut(url, protocol);
        console.log(`\u2705 Write successful (${protocol}):`, res.status);
        return;
      } catch (error) {
        const err = error;
        console.warn(`\u274C ${protocol} failed:`, err.message);
        errors.push({ protocol, error: err });
        if (!err.message.includes("Failed to fetch") && !err.message.includes("NetworkError")) {
          throw err;
        }
      }
    }
    const errorDetails = errors.map((e) => `  - ${e.protocol}: ${e.error.message}`).join("\n");
    const configInfo = rest.httpsUrl || rest.httpUrl ? `HTTPS: ${rest.httpsUrl || "\u672A\u914D\u7F6E"}, HTTP: ${rest.httpUrl || "\u672A\u914D\u7F6E"}` : `baseUrl: ${rest.baseUrl}`;
    throw new Error(
      `\u65E0\u6CD5\u8FDE\u63A5\u5230 Obsidian Local REST API\u3002
\u914D\u7F6E\uFF1A${configInfo}
\u5DF2\u5C1D\u8BD5\u7684\u534F\u8BAE\uFF1A
${errorDetails}

\u8BF7\u68C0\u67E5\uFF1A
1. Obsidian \u662F\u5426\u6B63\u5728\u8FD0\u884C
2. Local REST API \u63D2\u4EF6\u662F\u5426\u5DF2\u542F\u7528
3. \u5728\u6269\u5C55\u9009\u9879\u4E2D\u914D\u7F6E\u6B63\u786E\u7684 HTTPS \u548C HTTP URL
4. \u68C0\u67E5\u9632\u706B\u5899\u8BBE\u7F6E\u662F\u5426\u963B\u6B62\u4E86\u8FDE\u63A5`
    );
  }

  // src/background/llm/classifier.ts
  async function classify(cfg, meta, preview) {
    const sys = `\u4F60\u662F\u4E00\u4E2A\u4E25\u683C\u7684JSON\u5206\u7C7B\u5668\u3002taxonomy=${JSON.stringify(cfg.taxonomy)}\u3002\u8F93\u51FAJSON: {type, topics, ai_platform, tags}`;
    const user = `meta=${JSON.stringify(meta)}
preview:
${preview}`;
    if (cfg.provider === "ollama") {
      const r2 = await fetch(cfg.endpoint || "http://localhost:11434/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: cfg.model || "llama3.1", stream: false, messages: [{ role: "system", content: sys }, { role: "user", content: user }] })
      });
      const j2 = await r2.json();
      return safeJson(j2?.message?.content);
    }
    const endpoint = cfg.endpoint || "https://api.openai.com/v1/chat/completions";
    const r = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${cfg.apiKey || ""}` },
      body: JSON.stringify({ model: cfg.model, messages: [{ role: "system", content: sys }, { role: "user", content: user }], temperature: 0 })
    });
    const j = await r.json();
    return safeJson(j?.choices?.[0]?.message?.content);
  }
  function safeJson(t) {
    try {
      return JSON.parse(t);
    } catch {
      return { type: "article", topics: [], tags: [] };
    }
  }

  // src/background/pathResolver.ts
  function resolvePath(tplCfg, payload, cls, domainMappings) {
    const d = /* @__PURE__ */ new Date();
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    const safe = (s) => s?.replace(/[\\/:*?"<>|]/g, "_").slice(0, 180) || "note";
    const slug = (s) => safe(s).toLowerCase().replace(/\s+/g, "-");
    const title = payload.title || "Untitled";
    if (payload.type === "ai_chat") {
      const tpl = tplCfg?.ai || "AI/{platform}/{yyyy}/{yyyy}-{mm}-{dd}_{title}.md";
      return tpl.replace("{platform}", payload.meta?.platform || cls.ai_platform || "chat").replace("{yyyy}", String(yyyy)).replace("{mm}", mm).replace("{dd}", dd).replace("{title}", safe(title));
    } else if (payload.type === "fragment") {
      const tpl = tplCfg?.fragment || "Fragments/{yyyy}/{mm}/{dd}/{title}.md";
      let domain = payload.meta?.domain || (payload.meta?.url ? new URL(payload.meta.url).hostname : "unknown");
      if (domainMappings && domainMappings[domain]) {
        domain = domainMappings[domain];
      }
      return tpl.replace("{domain}", safe(domain)).replace("{yyyy}", String(yyyy)).replace("{mm}", mm).replace("{dd}", dd).replace("{slug}", slug(title)).replace("{title}", safe(title));
    } else if (payload.type === "clipper") {
      const tpl = tplCfg?.clipper || "Clippings/{domain}/{yyyy}/{yyyy}-{mm}-{dd}/{slug}.md";
      let domain = payload.meta?.domain || (payload.meta?.url ? new URL(payload.meta.url).hostname : "unknown");
      if (domainMappings && domainMappings[domain]) {
        domain = domainMappings[domain];
      }
      return tpl.replace("{domain}", safe(domain)).replace("{yyyy}", String(yyyy)).replace("{mm}", mm).replace("{dd}", dd).replace("{slug}", slug(title));
    } else {
      const tpl = tplCfg?.article || "Articles/{domain}/{yyyy}/{slug}.md";
      let domain = payload.meta?.domain || (payload.meta?.url ? new URL(payload.meta.url).hostname : "unknown");
      if (domainMappings && domainMappings[domain]) {
        domain = domainMappings[domain];
      }
      return tpl.replace("{domain}", safe(domain)).replace("{yyyy}", String(yyyy)).replace("{mm}", mm).replace("{dd}", dd).replace("{slug}", slug(title)).replace("{title}", safe(title));
    }
  }

  // src/i18n/locales.ts
  var messages = {
    "zh-CN": {
      // General
      extensionName: "All in Obsidian",
      extensionSubtitle: "\u914D\u7F6E\u4F60\u7684\u526A\u85CF\u63D2\u4EF6\uFF0C\u8BA9\u5185\u5BB9\u7BA1\u7406\u66F4\u667A\u80FD",
      // Settings page sections
      settingsTitle: "\u8BBE\u7F6E",
      languageSettings: "\u8BED\u8A00\u8BBE\u7F6E",
      languageLabel: "\u754C\u9762\u8BED\u8A00",
      languageHint: "\u{1F4A1} \u9009\u62E9\u4F60\u559C\u6B22\u7684\u754C\u9762\u8BED\u8A00",
      // API Configuration
      apiConfigTitle: "Obsidian Local REST API",
      apiConfigHint: "\u{1F4A1} \u914D\u7F6E HTTPS \u548C HTTP \u4E24\u4E2A URL\uFF0C\u6269\u5C55\u4F1A\u667A\u80FD\u9009\u62E9\u53EF\u7528\u7684\u8FDE\u63A5\u65B9\u5F0F",
      httpsUrlLabel: "HTTPS URL",
      httpsUrlHint: "\u901A\u5E38\u7AEF\u53E3\u4E3A 27124\uFF0C\u9002\u7528\u4E8E\u5B89\u5168\u8FDE\u63A5",
      httpUrlLabel: "HTTP URL",
      httpUrlHint: "\u901A\u5E38\u7AEF\u53E3\u4E3A 27123\uFF0C\u4F5C\u4E3A\u5907\u7528\u8FDE\u63A5",
      vaultNameLabel: "Vault \u540D\u79F0",
      vaultNamePlaceholder: "YourVault",
      vaultNameHint: "\u4F60\u7684 Obsidian \u4ED3\u5E93\u540D\u79F0",
      apiKeyLabel: "API Key",
      apiKeyPlaceholder: "\u4F60\u7684 API \u5BC6\u94A5",
      apiKeyHint: "\u5728 Obsidian Local REST API \u63D2\u4EF6\u8BBE\u7F6E\u4E2D\u83B7\u53D6",
      // Template Configuration
      templateConfigTitle: "\u8DEF\u5F84\u6A21\u677F\u914D\u7F6E",
      articleTemplateLabel: "\u6587\u7AE0\u8DEF\u5F84\u6A21\u677F",
      articleTemplateHint: "\u7528\u4E8E\u5B8C\u6574\u7684\u7F51\u9875\u6587\u7AE0\u526A\u85CF",
      fragmentTemplateLabel: "\u7247\u6BB5\u8DEF\u5F84\u6A21\u677F",
      fragmentTemplateHint: "\u7528\u4E8E\u9009\u4E2D\u6587\u672C\u7247\u6BB5\u7684\u5FEB\u901F\u526A\u85CF",
      aiTemplateLabel: "AI \u5BF9\u8BDD\u8DEF\u5F84\u6A21\u677F",
      aiTemplateHint: "\u7528\u4E8E AI \u804A\u5929\u5BF9\u8BDD\u7684\u526A\u85CF",
      availableVariables: "\u53EF\u7528\u53D8\u91CF\uFF1A",
      // Domain Mapping
      domainMappingTitle: "\u57DF\u540D\u6620\u5C04\u914D\u7F6E",
      domainMappingHint: "\u{1F4A1} \u4E3A\u7279\u5B9A\u57DF\u540D\u81EA\u5B9A\u4E49\u6587\u4EF6\u5939\u540D\u79F0",
      domainLabel: "\u57DF\u540D",
      folderNameLabel: "\u6587\u4EF6\u5939\u540D\u79F0",
      addMappingButton: "+ \u6DFB\u52A0\u6620\u5C04",
      // Config Transfer
      configTransferTitle: "\u914D\u7F6E\u540C\u6B65",
      configTransferHint: "\u{1F4A1} \u4E00\u952E\u590D\u5236\u4E0E\u5BFC\u5165\uFF0C\u8DE8\u6D4F\u89C8\u5668\u540C\u6B65\u66F4\u8F7B\u677E",
      copyConfigButton: "\u590D\u5236\u914D\u7F6E",
      importConfigButton: "\u5BFC\u5165\u5E76\u4FDD\u5B58",
      configTransferNote: "\u64CD\u4F5C\u4F1A\u4F7F\u7528\u7CFB\u7EDF\u526A\u8D34\u677F\uFF0C\u8BF7\u786E\u8BA4\u6D4F\u89C8\u5668\u5DF2\u6388\u6743\u8BBF\u95EE\u540E\u518D\u7EE7\u7EED\u3002",
      copyConfigSuccess: "\u2705 \u914D\u7F6E\u5DF2\u590D\u5236\u5230\u526A\u8D34\u677F",
      importSuccess: "\u2705 \u914D\u7F6E\u5DF2\u5BFC\u5165\u5E76\u4FDD\u5B58",
      importParseFailed: "\u274C \u914D\u7F6E\u89E3\u6790\u5931\u8D25",
      emptyImportError: "\u526A\u8D34\u677F\u4E3A\u7A7A\uFF0C\u8BF7\u5148\u590D\u5236\u914D\u7F6E",
      clipboardUnavailable: "\u65E0\u6CD5\u8BBF\u95EE\u526A\u8D34\u677F\uFF0C\u8BF7\u624B\u52A8\u590D\u5236",
      clipboardReadUnavailable: "\u65E0\u6CD5\u8BFB\u53D6\u526A\u8D34\u677F\uFF0C\u8BF7\u5728\u6D4F\u89C8\u5668\u8BBE\u7F6E\u4E2D\u6388\u4E88\u6743\u9650\u540E\u91CD\u8BD5",
      invalidTaxonomy: "\u5206\u7C7B\u5668 Taxonomy \u4E0D\u662F\u6709\u6548\u7684 JSON",
      // AI Chat Configuration
      aiChatConfigTitle: "AI \u5BF9\u8BDD\u526A\u85CF\u914D\u7F6E",
      aiChatConfigHint: "\u{1F4A1} \u81EA\u5B9A\u4E49 AI \u5BF9\u8BDD\u7684\u526A\u85CF\u683C\u5F0F\u548C\u5185\u5BB9",
      includeTimestampsLabel: "\u5305\u542B\u6D88\u606F\u65F6\u95F4\u6233",
      includeTimestampsHint: "\u5728\u6BCF\u6761\u6D88\u606F\u540E\u663E\u793A\u53D1\u9001\u65F6\u95F4\uFF08\u5982\u679C\u53EF\u7528\uFF09",
      userNameLabel: "\u7528\u6237\u540D\u79F0",
      userNamePlaceholder: "USER",
      userNameHint: '\u81EA\u5B9A\u4E49\u7528\u6237\u6D88\u606F\u7684\u663E\u793A\u540D\u79F0\uFF0C\u9ED8\u8BA4\u4E3A "USER"',
      // Deep Research Configuration
      deepResearchConfigTitle: "Gemini Deep Research \u914D\u7F6E",
      deepResearchConfigHint: "\u{1F4A1} \u81EA\u5B9A\u4E49 Deep Research \u62A5\u544A\u7684\u6355\u6349\u65B9\u5F0F",
      pureModeLabel: "\u63D0\u7EAF\u6A21\u5F0F\uFF08\u53EA\u6355\u6349\u62A5\u544A\u5185\u5BB9\uFF09",
      pureModeHint: "\u542F\u7528\u540E\uFF0C\u53EA\u6355\u6349 Deep Research \u62A5\u544A\u5185\u5BB9\uFF0C\u4E0D\u5305\u542B\u5BF9\u8BDD\u6D88\u606F",
      multipleReportsInfo: "\u2139\uFE0F \u5173\u4E8E\u591A\u4E2A\u62A5\u544A: Gemini \u4E00\u6B21\u53EA\u80FD\u663E\u793A\u4E00\u4E2A\u5B8C\u6574\u62A5\u544A\u3002\u5982\u9700\u4FDD\u5B58\u591A\u4E2A\u62A5\u544A\uFF0C\u8BF7\u5206\u522B\u6253\u5F00\u6BCF\u4E2A\u62A5\u544A\u5E76\u70B9\u51FB\u526A\u85CF\u3002",
      // Classifier Configuration
      classifierConfigTitle: "\u667A\u80FD\u5206\u7C7B\u914D\u7F6E\uFF08\u53EF\u9009\uFF09",
      classifierConfigHint: "\u{1F4A1} \u4F7F\u7528 LLM \u81EA\u52A8\u5206\u7C7B\u548C\u6807\u8BB0\u526A\u85CF\u5185\u5BB9",
      enableClassifierLabel: "\u542F\u7528\u667A\u80FD\u5206\u7C7B",
      providerLabel: "LLM \u63D0\u4F9B\u5546",
      endpointLabel: "API \u7AEF\u70B9",
      endpointPlaceholder: "http://localhost:11434/api/chat",
      modelLabel: "\u6A21\u578B\u540D\u79F0",
      modelPlaceholder: "llama3.1",
      taxonomyLabel: "\u5206\u7C7B\u4F53\u7CFB",
      taxonomyHint: "\u5B9A\u4E49\u5206\u7C7B\u4F53\u7CFB\uFF0CJSON \u683C\u5F0F",
      // Buttons
      saveButton: "\u{1F4BE} \u4FDD\u5B58\u914D\u7F6E",
      diagnoseButton: "\u{1F50D} \u8BCA\u65AD\u914D\u7F6E",
      fixButton: "\u{1F527} \u4FEE\u590D\u914D\u7F6E",
      reloadButton: "\u{1F504} \u91CD\u65B0\u52A0\u8F7D",
      // Messages
      saveSuccess: "\u2705 \u914D\u7F6E\u5DF2\u4FDD\u5B58",
      saveFailed: "\u274C \u4FDD\u5B58\u5931\u8D25",
      configFixed: "\u2705 \u914D\u7F6E\u5DF2\u4FEE\u590D\u5E76\u4FDD\u5B58",
      fixFailed: "\u274C \u4FEE\u590D\u5931\u8D25",
      reloadPrompt: "\u8BF7\u91CD\u65B0\u52A0\u8F7D\u9875\u9762\u67E5\u770B\u4FEE\u590D\u540E\u7684\u914D\u7F6E",
      // Diagnosis
      diagnosisTitle: "\u914D\u7F6E\u8BCA\u65AD",
      // Notifications
      clipSuccess: "\u5DF2\u4FDD\u5B58\u5230 Obsidian",
      clipFailed: "\u526A\u85CF\u5931\u8D25",
      extractionFailed: "\u5185\u5BB9\u63D0\u53D6\u5931\u8D25",
      connectionFailed: "\u8FDE\u63A5\u5931\u8D25",
      scriptInjectionFailed: "\u65E0\u6CD5\u6CE8\u5165\u5185\u5BB9\u811A\u672C",
      // Context Menu
      clipFullPage: "\u526A\u85CF\u6574\u4E2A\u9875\u9762\u5230 Obsidian",
      clipSelection: "\u2702\uFE0F \u526A\u85CF\u9009\u4E2D\u5185\u5BB9\u5230 Obsidian",
      // Dialog
      clipDialogTitle: "\u{1F4CE} \u526A\u85CF\u9009\u4E2D\u5185\u5BB9",
      commentLabel: "\u{1F4AD} \u6DFB\u52A0\u4F60\u7684\u8BC4\u8BBA\uFF08\u53EF\u9009\uFF09\uFF1A",
      commentPlaceholder: "\u5728\u8FD9\u91CC\u5199\u4E0B\u4F60\u7684\u60F3\u6CD5\u3001\u7B14\u8BB0\u6216\u8BC4\u8BBA...",
      cancelButton: "\u53D6\u6D88",
      clipButton: "\u2702\uFE0F \u526A\u85CF",
      // Multi-Vault
      additionalVaultsTitle: "\u989D\u5916\u4ED3\u5E93",
      additionalVaultsHint: "\u{1F4A1} \u6DFB\u52A0\u66F4\u591A\u4ED3\u5E93\uFF0C\u901A\u8FC7\u8DEF\u7531\u89C4\u5219\u81EA\u52A8\u5206\u914D\u5185\u5BB9",
      addVaultButton: "+ \u6DFB\u52A0\u4ED3\u5E93",
      multiVaultNameLabel: "\u4ED3\u5E93\u540D\u79F0",
      multiVaultNamePlaceholder: "\u6211\u7684\u7B14\u8BB0\u4ED3\u5E93",
      deleteVaultButton: "\u5220\u9664",
      defaultVaultBadge: "\u9ED8\u8BA4\u4ED3\u5E93",
      // Routing Rules
      routingRulesTitle: "\u8DEF\u7531\u89C4\u5219",
      routingRulesHint: "\u{1F4A1} \u6839\u636E\u57DF\u540D\u3001\u5173\u952E\u8BCD\u6216 URL \u6A21\u5F0F\u81EA\u52A8\u9009\u62E9\u76EE\u6807\u4ED3\u5E93",
      addRuleButton: "+ \u6DFB\u52A0\u89C4\u5219",
      ruleTypeLabel: "\u89C4\u5219\u7C7B\u578B",
      ruleTypeDomain: "\u57DF\u540D\u5339\u914D",
      ruleTypeKeyword: "\u5173\u952E\u8BCD\u5339\u914D",
      ruleTypeUrlPattern: "URL \u6A21\u5F0F",
      rulePatternLabel: "\u5339\u914D\u6A21\u5F0F",
      rulePatternPlaceholder: "\u4F8B\u5982\uFF1Aexample.com \u6216 \u5173\u952E\u8BCD1,\u5173\u952E\u8BCD2",
      ruleTargetVaultLabel: "\u76EE\u6807\u4ED3\u5E93",
      rulePriorityLabel: "\u4F18\u5148\u7EA7",
      ruleDescriptionLabel: "\u89C4\u5219\u63CF\u8FF0",
      ruleDescriptionPlaceholder: "\u4F8B\u5982\uFF1A\u6280\u672F\u6587\u7AE0\u4FDD\u5B58\u5230\u5DE5\u4F5C\u4ED3\u5E93",
      ruleEnabledLabel: "\u542F\u7528",
      deleteRuleButton: "\u5220\u9664",
      editRuleButton: "\u7F16\u8F91"
    },
    "en": {
      // General
      extensionName: "All in Obsidian",
      extensionSubtitle: "Configure your clipper for smarter content management",
      // Settings page sections
      settingsTitle: "Settings",
      languageSettings: "Language Settings",
      languageLabel: "Interface Language",
      languageHint: "\u{1F4A1} Choose your preferred interface language",
      // API Configuration
      apiConfigTitle: "Obsidian Local REST API",
      apiConfigHint: "\u{1F4A1} Configure both HTTPS and HTTP URLs, the extension will intelligently choose the available connection",
      httpsUrlLabel: "HTTPS URL",
      httpsUrlHint: "Usually port 27124, for secure connections",
      httpUrlLabel: "HTTP URL",
      httpUrlHint: "Usually port 27123, as fallback connection",
      vaultNameLabel: "Vault Name",
      vaultNamePlaceholder: "YourVault",
      vaultNameHint: "Your Obsidian vault name",
      apiKeyLabel: "API Key",
      apiKeyPlaceholder: "Your API key",
      apiKeyHint: "Get it from Obsidian Local REST API plugin settings",
      // Template Configuration
      templateConfigTitle: "Path Template Configuration",
      articleTemplateLabel: "Article Path Template",
      articleTemplateHint: "For full webpage article clipping",
      fragmentTemplateLabel: "Fragment Path Template",
      fragmentTemplateHint: "For quick clipping of selected text fragments",
      aiTemplateLabel: "AI Chat Path Template",
      aiTemplateHint: "For AI chat conversation clipping",
      availableVariables: "Available variables:",
      // Domain Mapping
      domainMappingTitle: "Domain Mapping Configuration",
      domainMappingHint: "\u{1F4A1} Customize folder names for specific domains",
      domainLabel: "Domain",
      folderNameLabel: "Folder Name",
      addMappingButton: "+ Add Mapping",
      // Config Transfer
      configTransferTitle: "Configuration Sync",
      configTransferHint: "\u{1F4A1} Copy once and import anywhere to keep browsers in sync.",
      copyConfigButton: "Copy configuration",
      importConfigButton: "Import from clipboard",
      configTransferNote: "These actions use the system clipboard\u2014ensure the browser is allowed to access it.",
      copyConfigSuccess: "\u2705 Configuration copied to clipboard",
      importSuccess: "\u2705 Configuration imported and saved",
      importParseFailed: "\u274C Failed to parse configuration",
      emptyImportError: "Clipboard is empty, please copy a configuration first",
      clipboardUnavailable: "Clipboard unavailable, please copy manually",
      clipboardReadUnavailable: "Unable to read the clipboard. Grant clipboard permissions and try again.",
      invalidTaxonomy: "Classifier taxonomy must be valid JSON",
      // AI Chat Configuration
      aiChatConfigTitle: "AI Chat Clipping Configuration",
      aiChatConfigHint: "\u{1F4A1} Customize the format and content of AI chat clips",
      includeTimestampsLabel: "Include message timestamps",
      includeTimestampsHint: "Show send time after each message (if available)",
      userNameLabel: "User Name",
      userNamePlaceholder: "USER",
      userNameHint: 'Customize the display name for user messages, default is "USER"',
      // Deep Research Configuration
      deepResearchConfigTitle: "Gemini Deep Research Configuration",
      deepResearchConfigHint: "\u{1F4A1} Customize how Deep Research reports are captured",
      pureModeLabel: "Pure Mode (capture report content only)",
      pureModeHint: "When enabled, only capture Deep Research report content, excluding conversation messages",
      multipleReportsInfo: "\u2139\uFE0F About multiple reports: Gemini can only display one complete report at a time. To save multiple reports, open each report separately and clip them.",
      // Classifier Configuration
      classifierConfigTitle: "Smart Classification Configuration (Optional)",
      classifierConfigHint: "\u{1F4A1} Use LLM to automatically classify and tag clipped content",
      enableClassifierLabel: "Enable Smart Classification",
      providerLabel: "LLM Provider",
      endpointLabel: "API Endpoint",
      endpointPlaceholder: "http://localhost:11434/api/chat",
      modelLabel: "Model Name",
      modelPlaceholder: "llama3.1",
      taxonomyLabel: "Taxonomy",
      taxonomyHint: "Define classification taxonomy in JSON format",
      // Buttons
      saveButton: "\u{1F4BE} Save Configuration",
      diagnoseButton: "\u{1F50D} Diagnose Configuration",
      fixButton: "\u{1F527} Fix Configuration",
      reloadButton: "\u{1F504} Reload",
      // Messages
      saveSuccess: "\u2705 Configuration saved",
      saveFailed: "\u274C Save failed",
      configFixed: "\u2705 Configuration fixed and saved",
      fixFailed: "\u274C Fix failed",
      reloadPrompt: "Please reload the page to see the fixed configuration",
      // Diagnosis
      diagnosisTitle: "Configuration Diagnosis",
      // Notifications
      clipSuccess: "Saved to Obsidian",
      clipFailed: "Clip failed",
      extractionFailed: "Content extraction failed",
      connectionFailed: "Connection failed",
      scriptInjectionFailed: "Failed to inject content script",
      // Context Menu
      clipFullPage: "Clip full page to Obsidian",
      clipSelection: "\u2702\uFE0F Clip selection to Obsidian",
      // Dialog
      clipDialogTitle: "\u{1F4CE} Clip Selection",
      commentLabel: "\u{1F4AD} Add your comment (optional):",
      commentPlaceholder: "Write your thoughts, notes or comments here...",
      cancelButton: "Cancel",
      clipButton: "\u2702\uFE0F Clip",
      // Multi-Vault
      additionalVaultsTitle: "Additional Vaults",
      additionalVaultsHint: "\u{1F4A1} Add more vaults and automatically route content using rules",
      addVaultButton: "+ Add Vault",
      multiVaultNameLabel: "Vault Name",
      multiVaultNamePlaceholder: "My Notes Vault",
      deleteVaultButton: "Delete",
      defaultVaultBadge: "Default Vault",
      // Routing Rules
      routingRulesTitle: "Routing Rules",
      routingRulesHint: "\u{1F4A1} Automatically select target vault based on domain, keywords, or URL patterns",
      addRuleButton: "+ Add Rule",
      ruleTypeLabel: "Rule Type",
      ruleTypeDomain: "Domain Match",
      ruleTypeKeyword: "Keyword Match",
      ruleTypeUrlPattern: "URL Pattern",
      rulePatternLabel: "Match Pattern",
      rulePatternPlaceholder: "e.g., example.com or keyword1,keyword2",
      ruleTargetVaultLabel: "Target Vault",
      rulePriorityLabel: "Priority",
      ruleDescriptionLabel: "Description",
      ruleDescriptionPlaceholder: "e.g., Save tech articles to work vault",
      ruleEnabledLabel: "Enabled",
      deleteRuleButton: "Delete",
      editRuleButton: "Edit"
    },
    "ja": {
      // General
      extensionName: "All in Obsidian",
      extensionSubtitle: "\u30AF\u30EA\u30C3\u30D1\u30FC\u3092\u8A2D\u5B9A\u3057\u3066\u3001\u3088\u308A\u30B9\u30DE\u30FC\u30C8\u306A\u30B3\u30F3\u30C6\u30F3\u30C4\u7BA1\u7406\u3092\u5B9F\u73FE",
      // Settings page sections
      settingsTitle: "\u8A2D\u5B9A",
      languageSettings: "\u8A00\u8A9E\u8A2D\u5B9A",
      languageLabel: "\u30A4\u30F3\u30BF\u30FC\u30D5\u30A7\u30FC\u30B9\u8A00\u8A9E",
      languageHint: "\u{1F4A1} \u304A\u597D\u307F\u306E\u30A4\u30F3\u30BF\u30FC\u30D5\u30A7\u30FC\u30B9\u8A00\u8A9E\u3092\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044",
      // API Configuration
      apiConfigTitle: "Obsidian Local REST API",
      apiConfigHint: "\u{1F4A1} HTTPS \u3068 HTTP \u306E\u4E21\u65B9\u306E URL \u3092\u8A2D\u5B9A\u3059\u308B\u3068\u3001\u62E1\u5F35\u6A5F\u80FD\u304C\u5229\u7528\u53EF\u80FD\u306A\u63A5\u7D9A\u3092\u81EA\u52D5\u7684\u306B\u9078\u629E\u3057\u307E\u3059",
      httpsUrlLabel: "HTTPS URL",
      httpsUrlHint: "\u901A\u5E38\u306F\u30DD\u30FC\u30C8 27124\u3001\u30BB\u30AD\u30E5\u30A2\u63A5\u7D9A\u7528",
      httpUrlLabel: "HTTP URL",
      httpUrlHint: "\u901A\u5E38\u306F\u30DD\u30FC\u30C8 27123\u3001\u30D5\u30A9\u30FC\u30EB\u30D0\u30C3\u30AF\u63A5\u7D9A\u7528",
      vaultNameLabel: "Vault \u540D",
      vaultNamePlaceholder: "YourVault",
      vaultNameHint: "Obsidian \u306E Vault \u540D",
      apiKeyLabel: "API \u30AD\u30FC",
      apiKeyPlaceholder: "API \u30AD\u30FC",
      apiKeyHint: "Obsidian Local REST API \u30D7\u30E9\u30B0\u30A4\u30F3\u306E\u8A2D\u5B9A\u304B\u3089\u53D6\u5F97",
      // Template Configuration
      templateConfigTitle: "\u30D1\u30B9\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u8A2D\u5B9A",
      articleTemplateLabel: "\u8A18\u4E8B\u30D1\u30B9\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
      articleTemplateHint: "\u5B8C\u5168\u306A\u30A6\u30A7\u30D6\u30DA\u30FC\u30B8\u8A18\u4E8B\u306E\u30AF\u30EA\u30C3\u30D4\u30F3\u30B0\u7528",
      fragmentTemplateLabel: "\u30D5\u30E9\u30B0\u30E1\u30F3\u30C8\u30D1\u30B9\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
      fragmentTemplateHint: "\u9078\u629E\u3057\u305F\u30C6\u30AD\u30B9\u30C8\u30D5\u30E9\u30B0\u30E1\u30F3\u30C8\u306E\u9AD8\u901F\u30AF\u30EA\u30C3\u30D4\u30F3\u30B0\u7528",
      aiTemplateLabel: "AI \u30C1\u30E3\u30C3\u30C8\u30D1\u30B9\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
      aiTemplateHint: "AI \u30C1\u30E3\u30C3\u30C8\u4F1A\u8A71\u306E\u30AF\u30EA\u30C3\u30D4\u30F3\u30B0\u7528",
      availableVariables: "\u5229\u7528\u53EF\u80FD\u306A\u5909\u6570\uFF1A",
      // Domain Mapping
      domainMappingTitle: "\u30C9\u30E1\u30A4\u30F3\u30DE\u30C3\u30D4\u30F3\u30B0\u8A2D\u5B9A",
      domainMappingHint: "\u{1F4A1} \u7279\u5B9A\u306E\u30C9\u30E1\u30A4\u30F3\u306E\u30D5\u30A9\u30EB\u30C0\u540D\u3092\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA",
      domainLabel: "\u30C9\u30E1\u30A4\u30F3",
      folderNameLabel: "\u30D5\u30A9\u30EB\u30C0\u540D",
      addMappingButton: "+ \u30DE\u30C3\u30D4\u30F3\u30B0\u3092\u8FFD\u52A0",
      // Config Transfer
      configTransferTitle: "\u8A2D\u5B9A\u306E\u540C\u671F",
      configTransferHint: "\u{1F4A1} \u4E00\u5EA6\u30B3\u30D4\u30FC\u3059\u308C\u3070\u3001\u3069\u306E\u30D6\u30E9\u30A6\u30B6\u3067\u3082\u3059\u3050\u306B\u540C\u671F\u3067\u304D\u307E\u3059\u3002",
      copyConfigButton: "\u8A2D\u5B9A\u3092\u30B3\u30D4\u30FC",
      importConfigButton: "\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u304B\u3089\u4FDD\u5B58",
      configTransferNote: "\u64CD\u4F5C\u3067\u306F\u30B7\u30B9\u30C6\u30E0\u306E\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u3092\u4F7F\u7528\u3057\u307E\u3059\u3002\u30D6\u30E9\u30A6\u30B6\u306B\u6A29\u9650\u304C\u4ED8\u4E0E\u3055\u308C\u3066\u3044\u308B\u304B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
      copyConfigSuccess: "\u2705 \u8A2D\u5B9A\u3092\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u306B\u30B3\u30D4\u30FC\u3057\u307E\u3057\u305F",
      importSuccess: "\u2705 \u8A2D\u5B9A\u3092\u30A4\u30F3\u30DD\u30FC\u30C8\u3057\u3066\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      importParseFailed: "\u274C \u8A2D\u5B9A\u306E\u89E3\u6790\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      emptyImportError: "\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u304C\u7A7A\u3067\u3059\u3002\u5148\u306B\u8A2D\u5B9A\u3092\u30B3\u30D4\u30FC\u3057\u3066\u304F\u3060\u3055\u3044",
      clipboardUnavailable: "\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u306B\u30A2\u30AF\u30BB\u30B9\u3067\u304D\u307E\u305B\u3093\u3002\u624B\u52D5\u3067\u30B3\u30D4\u30FC\u3057\u3066\u304F\u3060\u3055\u3044",
      clipboardReadUnavailable: "\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u3092\u8AAD\u307F\u53D6\u308C\u307E\u305B\u3093\u3002\u30D6\u30E9\u30A6\u30B6\u3067\u6A29\u9650\u3092\u8A31\u53EF\u3057\u3066\u304B\u3089\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044",
      invalidTaxonomy: "\u5206\u985E\u5668\u306E\u30BF\u30AF\u30BD\u30CE\u30DF\u30FC\u306F\u6709\u52B9\u306A JSON \u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059",
      // AI Chat Configuration
      aiChatConfigTitle: "AI \u30C1\u30E3\u30C3\u30C8\u30AF\u30EA\u30C3\u30D7\u8A2D\u5B9A",
      aiChatConfigHint: "\u{1F4A1} AI \u30C1\u30E3\u30C3\u30C8\u30AF\u30EA\u30C3\u30D7\u306E\u5F62\u5F0F\u3068\u5185\u5BB9\u3092\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA",
      includeTimestampsLabel: "\u30E1\u30C3\u30BB\u30FC\u30B8\u306E\u30BF\u30A4\u30E0\u30B9\u30BF\u30F3\u30D7\u3092\u542B\u3081\u308B",
      includeTimestampsHint: "\u5404\u30E1\u30C3\u30BB\u30FC\u30B8\u306E\u5F8C\u306B\u9001\u4FE1\u6642\u523B\u3092\u8868\u793A\uFF08\u5229\u7528\u53EF\u80FD\u306A\u5834\u5408\uFF09",
      userNameLabel: "\u30E6\u30FC\u30B6\u30FC\u540D",
      userNamePlaceholder: "USER",
      userNameHint: '\u30E6\u30FC\u30B6\u30FC\u30E1\u30C3\u30BB\u30FC\u30B8\u306E\u8868\u793A\u540D\u3092\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA\u3001\u30C7\u30D5\u30A9\u30EB\u30C8\u306F "USER"',
      // Deep Research Configuration
      deepResearchConfigTitle: "Gemini Deep Research \u8A2D\u5B9A",
      deepResearchConfigHint: "\u{1F4A1} Deep Research \u30EC\u30DD\u30FC\u30C8\u306E\u30AD\u30E3\u30D7\u30C1\u30E3\u65B9\u6CD5\u3092\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA",
      pureModeLabel: "\u30D4\u30E5\u30A2\u30E2\u30FC\u30C9\uFF08\u30EC\u30DD\u30FC\u30C8\u5185\u5BB9\u306E\u307F\u30AD\u30E3\u30D7\u30C1\u30E3\uFF09",
      pureModeHint: "\u6709\u52B9\u306B\u3059\u308B\u3068\u3001Deep Research \u30EC\u30DD\u30FC\u30C8\u306E\u5185\u5BB9\u306E\u307F\u3092\u30AD\u30E3\u30D7\u30C1\u30E3\u3057\u3001\u4F1A\u8A71\u30E1\u30C3\u30BB\u30FC\u30B8\u306F\u542B\u3081\u307E\u305B\u3093",
      multipleReportsInfo: "\u2139\uFE0F \u8907\u6570\u306E\u30EC\u30DD\u30FC\u30C8\u306B\u3064\u3044\u3066: Gemini \u306F\u4E00\u5EA6\u306B 1 \u3064\u306E\u5B8C\u5168\u306A\u30EC\u30DD\u30FC\u30C8\u306E\u307F\u3092\u8868\u793A\u3067\u304D\u307E\u3059\u3002\u8907\u6570\u306E\u30EC\u30DD\u30FC\u30C8\u3092\u4FDD\u5B58\u3059\u308B\u306B\u306F\u3001\u5404\u30EC\u30DD\u30FC\u30C8\u3092\u500B\u5225\u306B\u958B\u3044\u3066\u30AF\u30EA\u30C3\u30D7\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
      // Classifier Configuration
      classifierConfigTitle: "\u30B9\u30DE\u30FC\u30C8\u5206\u985E\u8A2D\u5B9A\uFF08\u30AA\u30D7\u30B7\u30E7\u30F3\uFF09",
      classifierConfigHint: "\u{1F4A1} LLM \u3092\u4F7F\u7528\u3057\u3066\u30AF\u30EA\u30C3\u30D7\u3055\u308C\u305F\u30B3\u30F3\u30C6\u30F3\u30C4\u3092\u81EA\u52D5\u7684\u306B\u5206\u985E\u304A\u3088\u3073\u30BF\u30B0\u4ED8\u3051",
      enableClassifierLabel: "\u30B9\u30DE\u30FC\u30C8\u5206\u985E\u3092\u6709\u52B9\u306B\u3059\u308B",
      providerLabel: "LLM \u30D7\u30ED\u30D0\u30A4\u30C0\u30FC",
      endpointLabel: "API \u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8",
      endpointPlaceholder: "http://localhost:11434/api/chat",
      modelLabel: "\u30E2\u30C7\u30EB\u540D",
      modelPlaceholder: "llama3.1",
      taxonomyLabel: "\u5206\u985E\u4F53\u7CFB",
      taxonomyHint: "JSON \u5F62\u5F0F\u3067\u5206\u985E\u4F53\u7CFB\u3092\u5B9A\u7FA9",
      // Buttons
      saveButton: "\u{1F4BE} \u8A2D\u5B9A\u3092\u4FDD\u5B58",
      diagnoseButton: "\u{1F50D} \u8A2D\u5B9A\u3092\u8A3A\u65AD",
      fixButton: "\u{1F527} \u8A2D\u5B9A\u3092\u4FEE\u5FA9",
      reloadButton: "\u{1F504} \u518D\u8AAD\u307F\u8FBC\u307F",
      // Messages
      saveSuccess: "\u2705 \u8A2D\u5B9A\u304C\u4FDD\u5B58\u3055\u308C\u307E\u3057\u305F",
      saveFailed: "\u274C \u4FDD\u5B58\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      configFixed: "\u2705 \u8A2D\u5B9A\u304C\u4FEE\u5FA9\u3055\u308C\u4FDD\u5B58\u3055\u308C\u307E\u3057\u305F",
      fixFailed: "\u274C \u4FEE\u5FA9\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      reloadPrompt: "\u4FEE\u5FA9\u3055\u308C\u305F\u8A2D\u5B9A\u3092\u78BA\u8A8D\u3059\u308B\u306B\u306F\u30DA\u30FC\u30B8\u3092\u518D\u8AAD\u307F\u8FBC\u307F\u3057\u3066\u304F\u3060\u3055\u3044",
      // Diagnosis
      diagnosisTitle: "\u8A2D\u5B9A\u8A3A\u65AD",
      // Notifications
      clipSuccess: "Obsidian \u306B\u4FDD\u5B58\u3055\u308C\u307E\u3057\u305F",
      clipFailed: "\u30AF\u30EA\u30C3\u30D7\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      extractionFailed: "\u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u62BD\u51FA\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      connectionFailed: "\u63A5\u7D9A\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      scriptInjectionFailed: "\u30B3\u30F3\u30C6\u30F3\u30C4\u30B9\u30AF\u30EA\u30D7\u30C8\u306E\u6CE8\u5165\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      // Context Menu
      clipFullPage: "\u30DA\u30FC\u30B8\u5168\u4F53\u3092 Obsidian \u306B\u30AF\u30EA\u30C3\u30D7",
      clipSelection: "\u2702\uFE0F \u9078\u629E\u7BC4\u56F2\u3092 Obsidian \u306B\u30AF\u30EA\u30C3\u30D7",
      // Dialog
      clipDialogTitle: "\u{1F4CE} \u9078\u629E\u7BC4\u56F2\u3092\u30AF\u30EA\u30C3\u30D7",
      commentLabel: "\u{1F4AD} \u30B3\u30E1\u30F3\u30C8\u3092\u8FFD\u52A0\uFF08\u30AA\u30D7\u30B7\u30E7\u30F3\uFF09\uFF1A",
      commentPlaceholder: "\u3053\u3053\u306B\u8003\u3048\u3001\u30E1\u30E2\u3001\u30B3\u30E1\u30F3\u30C8\u3092\u66F8\u3044\u3066\u304F\u3060\u3055\u3044...",
      cancelButton: "\u30AD\u30E3\u30F3\u30BB\u30EB",
      clipButton: "\u2702\uFE0F \u30AF\u30EA\u30C3\u30D7",
      // Multi-Vault
      additionalVaultsTitle: "\u8FFD\u52A0 Vault",
      additionalVaultsHint: "\u{1F4A1} \u3055\u3089\u306B Vault \u3092\u8FFD\u52A0\u3057\u3001\u30EB\u30FC\u30EB\u306B\u57FA\u3065\u3044\u3066\u81EA\u52D5\u7684\u306B\u30B3\u30F3\u30C6\u30F3\u30C4\u3092\u632F\u308A\u5206\u3051",
      addVaultButton: "+ Vault \u3092\u8FFD\u52A0",
      multiVaultNameLabel: "Vault \u540D",
      multiVaultNamePlaceholder: "\u30DE\u30A4\u30CE\u30FC\u30C8 Vault",
      deleteVaultButton: "\u524A\u9664",
      defaultVaultBadge: "\u30C7\u30D5\u30A9\u30EB\u30C8 Vault",
      // Routing Rules
      routingRulesTitle: "\u30EB\u30FC\u30C6\u30A3\u30F3\u30B0\u30EB\u30FC\u30EB",
      routingRulesHint: "\u{1F4A1} \u30C9\u30E1\u30A4\u30F3\u3001\u30AD\u30FC\u30EF\u30FC\u30C9\u3001\u307E\u305F\u306F URL \u30D1\u30BF\u30FC\u30F3\u306B\u57FA\u3065\u3044\u3066\u81EA\u52D5\u7684\u306B\u30BF\u30FC\u30B2\u30C3\u30C8 Vault \u3092\u9078\u629E",
      addRuleButton: "+ \u30EB\u30FC\u30EB\u3092\u8FFD\u52A0",
      ruleTypeLabel: "\u30EB\u30FC\u30EB\u30BF\u30A4\u30D7",
      ruleTypeDomain: "\u30C9\u30E1\u30A4\u30F3\u30DE\u30C3\u30C1",
      ruleTypeKeyword: "\u30AD\u30FC\u30EF\u30FC\u30C9\u30DE\u30C3\u30C1",
      ruleTypeUrlPattern: "URL \u30D1\u30BF\u30FC\u30F3",
      rulePatternLabel: "\u30DE\u30C3\u30C1\u30D1\u30BF\u30FC\u30F3",
      rulePatternPlaceholder: "\u4F8B\uFF1Aexample.com \u307E\u305F\u306F \u30AD\u30FC\u30EF\u30FC\u30C91,\u30AD\u30FC\u30EF\u30FC\u30C92",
      ruleTargetVaultLabel: "\u30BF\u30FC\u30B2\u30C3\u30C8 Vault",
      rulePriorityLabel: "\u512A\u5148\u5EA6",
      ruleDescriptionLabel: "\u8AAC\u660E",
      ruleDescriptionPlaceholder: "\u4F8B\uFF1A\u6280\u8853\u8A18\u4E8B\u3092\u4ED5\u4E8B\u7528 Vault \u306B\u4FDD\u5B58",
      ruleEnabledLabel: "\u6709\u52B9",
      deleteRuleButton: "\u524A\u9664",
      editRuleButton: "\u7DE8\u96C6"
    }
  };

  // src/i18n/index.ts
  var DEFAULT_LANGUAGE = "zh-CN";
  async function getCurrentLanguage() {
    try {
      const result = await chrome.storage.sync.get("language");
      return result.language || DEFAULT_LANGUAGE;
    } catch (error) {
      console.error("Failed to get language:", error);
      return DEFAULT_LANGUAGE;
    }
  }
  async function getMessages() {
    const language = await getCurrentLanguage();
    return messages[language];
  }

  // src/background/vault-router.ts
  var VaultRouter = class {
    constructor(config) {
      this.config = config;
    }
    /**
     * 根据上下文选择合适的仓库
     */
    selectVault(context) {
      const sortedRules = [...this.config.rules].filter((rule) => rule.enabled).sort((a, b) => b.priority - a.priority);
      for (const rule of sortedRules) {
        if (this.matchRule(rule, context)) {
          const vault = this.config.vaults.find((v) => v.id === rule.vaultId);
          if (vault) {
            console.log(`[VaultRouter] Matched rule: ${rule.description || rule.pattern} -> ${vault.name}`);
            return vault;
          }
        }
      }
      const defaultVault = this.getDefaultVault();
      if (defaultVault) {
        console.log(`[VaultRouter] Using default vault: ${defaultVault.name}`);
        return defaultVault;
      }
      if (this.config.vaults.length > 0) {
        console.log(`[VaultRouter] Using first vault: ${this.config.vaults[0].name}`);
        return this.config.vaults[0];
      }
      console.error("[VaultRouter] No vault available");
      return null;
    }
    /**
     * 匹配规则
     */
    matchRule(rule, context) {
      switch (rule.type) {
        case "domain":
          return this.matchDomain(rule.pattern, context.domain);
        case "keyword":
          return this.matchKeyword(rule.pattern, context);
        case "url-pattern":
          return this.matchUrlPattern(rule.pattern, context.url);
        default:
          return false;
      }
    }
    /**
     * 匹配域名
     * 支持精确匹配和通配符
     */
    matchDomain(pattern, domain) {
      if (pattern === domain) {
        return true;
      }
      if (pattern.startsWith("*.")) {
        const suffix = pattern.substring(2);
        return domain.endsWith(suffix) || domain === suffix;
      }
      return false;
    }
    /**
     * 匹配关键词
     * 在标题和内容中搜索关键词
     */
    matchKeyword(pattern, context) {
      const keywords = pattern.split(",").map((k) => k.trim().toLowerCase());
      const searchText = `${context.title} ${context.content}`.toLowerCase();
      return keywords.some((keyword) => searchText.includes(keyword));
    }
    /**
     * 匹配 URL 模式
     * 支持正则表达式
     */
    matchUrlPattern(pattern, url) {
      try {
        const regex = new RegExp(pattern, "i");
        return regex.test(url);
      } catch (error) {
        console.error(`[VaultRouter] Invalid regex pattern: ${pattern}`, error);
        return false;
      }
    }
    /**
     * 获取默认仓库
     */
    getDefaultVault() {
      if (this.config.defaultVaultId) {
        const vault = this.config.vaults.find((v) => v.id === this.config.defaultVaultId);
        if (vault) return vault;
      }
      const defaultVault = this.config.vaults.find((v) => v.isDefault);
      if (defaultVault) return defaultVault;
      return this.config.vaults[0] || null;
    }
    /**
     * 获取所有仓库
     */
    getAllVaults() {
      return this.config.vaults;
    }
    /**
     * 根据 ID 获取仓库
     */
    getVaultById(id) {
      return this.config.vaults.find((v) => v.id === id) || null;
    }
    /**
     * 获取所有规则
     */
    getAllRules() {
      return this.config.rules;
    }
    /**
     * 验证配置
     */
    validate() {
      const errors = [];
      if (this.config.vaults.length === 0) {
        errors.push("\u81F3\u5C11\u9700\u8981\u914D\u7F6E\u4E00\u4E2A\u4ED3\u5E93");
      }
      const vaultIds = this.config.vaults.map((v) => v.id);
      const duplicateVaultIds = vaultIds.filter((id, index) => vaultIds.indexOf(id) !== index);
      if (duplicateVaultIds.length > 0) {
        errors.push(`\u4ED3\u5E93 ID \u91CD\u590D: ${duplicateVaultIds.join(", ")}`);
      }
      for (const rule of this.config.rules) {
        if (!this.config.vaults.find((v) => v.id === rule.vaultId)) {
          errors.push(`\u89C4\u5219 "${rule.description || rule.id}" \u5F15\u7528\u4E86\u4E0D\u5B58\u5728\u7684\u4ED3\u5E93: ${rule.vaultId}`);
        }
      }
      if (this.config.defaultVaultId && !this.config.vaults.find((v) => v.id === this.config.defaultVaultId)) {
        errors.push(`\u9ED8\u8BA4\u4ED3\u5E93\u4E0D\u5B58\u5728: ${this.config.defaultVaultId}`);
      }
      return {
        valid: errors.length === 0,
        errors
      };
    }
  };

  // src/background/index.ts
  chrome.runtime.onInstalled.addListener(async () => {
    const msgs = await getMessages();
    chrome.contextMenus.create({
      id: "clip-current",
      title: msgs.clipFullPage,
      contexts: ["page"]
    });
    chrome.contextMenus.create({
      id: "clip-selection",
      title: msgs.clipSelection,
      contexts: ["selection"]
    });
  });
  chrome.action.onClicked.addListener(async (tab) => {
    if (!tab?.id) return;
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content/index.js"],
        world: "ISOLATED"
      });
    } catch (error) {
      console.error("Failed to inject content script:", error);
      const msgs = await getMessages();
      chrome.notifications.create({
        type: "basic",
        iconUrl: "assets/icon128.png",
        title: msgs.clipFailed,
        message: msgs.scriptInjectionFailed + ": " + error.message
      });
    }
  });
  chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (!tab?.id) return;
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content/index.js"],
        world: "ISOLATED"
      });
      if (info.menuItemId === "clip-selection") {
        await new Promise((resolve) => setTimeout(resolve, 100));
        await chrome.tabs.sendMessage(tab.id, { action: "clipSelection" });
      }
    } catch (error) {
      console.error("Failed to inject content script:", error);
      const msgs = await getMessages();
      chrome.notifications.create({
        type: "basic",
        iconUrl: "assets/icon128.png",
        title: msgs.clipFailed,
        message: msgs.scriptInjectionFailed + ": " + error.message
      });
    }
  });
  chrome.runtime.onMessage.addListener(async (msg, _sender, sendResponse) => {
    console.log("[Background v2] Received message:", msg?.type);
    if (msg?.type === "TEST_CONNECTION") {
      try {
        const opt = await getOptions();
        console.log("Testing connection with config:", {
          httpsUrl: opt.rest.httpsUrl,
          httpUrl: opt.rest.httpUrl,
          baseUrl: opt.rest.baseUrl
        });
        async function doTest(url, protocol) {
          const response = await fetch(url, {
            method: "GET",
            headers: {
              "Authorization": `Bearer ${opt.rest.apiKey}`
            }
          });
          const text = await response.text();
          return { response, text, protocol };
        }
        const urlsToTry = [];
        const isLocalAddress = (url) => /^https?:\/\/(127\.0\.0\.1|localhost)/.test(url);
        if (opt.rest.httpsUrl || opt.rest.httpUrl) {
          console.log("\u4F7F\u7528\u7528\u6237\u914D\u7F6E\u7684 HTTPS/HTTP URL");
          if (opt.rest.httpsUrl && opt.rest.httpsUrl.trim()) {
            const httpsUrl = opt.rest.httpsUrl.replace(/\/$/, "") + "/";
            urlsToTry.push({ url: httpsUrl, protocol: "HTTPS (\u7528\u6237\u914D\u7F6E)" });
          }
          if (opt.rest.httpUrl && opt.rest.httpUrl.trim()) {
            const httpUrl = opt.rest.httpUrl.replace(/\/$/, "") + "/";
            urlsToTry.push({ url: httpUrl, protocol: "HTTP (\u7528\u6237\u914D\u7F6E)" });
          }
        } else {
          console.log("\u4F7F\u7528 baseUrl \u914D\u7F6E\uFF08\u5411\u540E\u517C\u5BB9\u6A21\u5F0F\uFF09");
          const baseUrl = opt.rest.baseUrl.replace(/\/$/, "");
          if (isLocalAddress(baseUrl)) {
            const isHttps = baseUrl.startsWith("https://");
            if (isHttps) {
              urlsToTry.push({ url: baseUrl + "/", protocol: "HTTPS" });
              urlsToTry.push({ url: baseUrl.replace(/^https:/, "http:") + "/", protocol: "HTTP" });
            } else {
              urlsToTry.push({ url: baseUrl + "/", protocol: "HTTP" });
              urlsToTry.push({ url: baseUrl.replace(/^http:/, "https:") + "/", protocol: "HTTPS" });
            }
          } else {
            const protocol = baseUrl.startsWith("https://") ? "HTTPS" : "HTTP";
            urlsToTry.push({ url: baseUrl + "/", protocol });
          }
        }
        const errors = [];
        for (const { url, protocol } of urlsToTry) {
          try {
            console.log(`Testing ${protocol}:`, url);
            const { response, text } = await doTest(url, protocol);
            sendResponse({
              success: true,
              status: response.status,
              message: `\u2705 \u901A\u8FC7 ${protocol} \u8FDE\u63A5\u6210\u529F\uFF01\u72B6\u6001\u7801: ${response.status}`,
              response: text.substring(0, 200)
            });
            return true;
          } catch (err) {
            const errorMsg = `${protocol}: ${err.message}`;
            console.warn(`\u274C ${errorMsg}`);
            errors.push(errorMsg);
            if (!err.message.includes("Failed to fetch") && !err.message.includes("NetworkError")) {
              throw err;
            }
          }
        }
        sendResponse({
          success: false,
          error: errors.join("\n"),
          message: `\u8FDE\u63A5\u5931\u8D25\uFF0C\u5DF2\u5C1D\u8BD5\uFF1A
${errors.join("\n")}`
        });
      } catch (error) {
        console.error("Connection test failed:", error);
        sendResponse({
          success: false,
          error: error.message,
          message: `\u8FDE\u63A5\u5931\u8D25: ${error.message}`
        });
      }
      return true;
    }
    if (msg?.type === "CLIP_ERROR") {
      console.error("Content script error:", msg.error);
      const errorMsg = String(msg.error || "Unknown error");
      console.log("Error message to show:", errorMsg);
      const msgs = await getMessages();
      chrome.notifications.create({
        type: "basic",
        iconUrl: "assets/icon128.png",
        title: msgs.extractionFailed,
        message: errorMsg
      });
      return;
    }
    if (msg?.type !== "CLIP_RESULT") return;
    try {
      console.log("Received CLIP_RESULT:", msg.payload);
      const opt = await getOptions();
      console.log("Options loaded:", opt);
      console.log("REST config:", {
        baseUrl: opt.rest.baseUrl,
        httpsUrl: opt.rest.httpsUrl,
        httpUrl: opt.rest.httpUrl,
        vault: opt.rest.vault,
        apiKeyLength: opt.rest.apiKey?.length,
        apiKeyFirst8: opt.rest.apiKey?.slice(0, 8),
        apiKeyLast8: opt.rest.apiKey?.slice(-8)
      });
      if (!msg.payload || !msg.payload.markdown) {
        throw new Error("Invalid payload: missing markdown content");
      }
      let targetVault = null;
      let targetRestConfig = opt.rest;
      if (opt.vaultRouter && opt.vaultRouter.vaults.length > 0) {
        const router = new VaultRouter(opt.vaultRouter);
        const context = {
          url: msg.payload.meta?.url || "",
          domain: msg.payload.meta?.domain || "",
          title: msg.payload.title || "Untitled",
          content: msg.payload.markdown.slice(0, 2e3),
          // 使用前2000字符作为内容预览
          type: msg.payload.type || "article"
        };
        targetVault = router.selectVault(context);
        if (targetVault) {
          console.log(`[VaultRouter] Selected vault: ${targetVault.name}`);
          targetRestConfig = {
            baseUrl: targetVault.httpsUrl,
            httpsUrl: targetVault.httpsUrl,
            httpUrl: targetVault.httpUrl,
            vault: targetVault.vault,
            apiKey: targetVault.apiKey
          };
        } else {
          console.warn("[VaultRouter] No vault selected, using default config");
        }
      }
      const preview = msg.payload.markdown.slice(0, 4e3);
      const cls = opt.classifier?.enabled ? await classify(opt.classifier, {
        typeHint: msg.payload.type || "article",
        platform: msg.payload.meta?.platform || "unknown",
        url: msg.payload.meta?.url || "",
        title: msg.payload.title || "Untitled"
      }, preview) : { type: msg.payload.type, topics: [], ai_platform: msg.payload.meta?.platform, tags: [] };
      console.log("Classification result:", cls);
      const filePath = resolvePath(opt.templates, msg.payload, cls, opt.domainMappings);
      console.log("Resolved file path:", filePath);
      await writeFile(targetRestConfig, filePath, msg.payload.markdown);
      console.log("File written successfully");
      const msgs = await getMessages();
      const vaultInfo = targetVault ? ` (${targetVault.name})` : "";
      chrome.notifications.create({
        type: "basic",
        iconUrl: "assets/icon128.png",
        title: msgs.clipSuccess + vaultInfo,
        message: String(filePath)
      });
    } catch (error) {
      console.error("Clip failed:", error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      const msgs = await getMessages();
      chrome.notifications.create({
        type: "basic",
        iconUrl: "assets/icon128.png",
        title: msgs.clipFailed,
        message: errorMessage
      });
    }
  });
})();
//# sourceMappingURL=index.js.map
